---
name: test-writer
description: Add or improve Vitest / Playwright tests. Use when test coverage needs to increase or when adding new features that require tests.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---

You are a test specialist for this monorepo.

## Test strategy
- **Vitest** for unit/integration: co-locate `foo.ts` → `foo.test.ts`; API routes in `apps/api/src/routes/<lane>/__tests__/`
- **Playwright** for full-stack E2E in `apps/<app>/e2e/*.spec.ts` (desktop Chrome only — this is a Web-only product). **Playwright is not used for PR screenshots** (those are taken with Claude in Chrome).
- API tests hit `app.request()` from `apps/api/src/app.ts`: 200 happy path, 400 (zod), 401/403 if auth-protected, 404 if the resource can be missing
- Run only the changed package: `pnpm --filter @jcredit/<pkg> test`
