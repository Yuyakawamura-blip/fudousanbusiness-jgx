---
name: add-db-migration
description: Drizzle スキーマを変更し migration を生成する。schema を編集 → pnpm db:generate --name <意味名> → 生成 SQL を確認 → db:migrate(ユーザー確認後)。migration の手書き禁止。
---

# /add-db-migration — スキーマ変更

1. `packages/db/schema/<cluster>.ts` を編集(ドメインクラスタ単位に 1 ファイル。`schema/index.ts` から re-export)。
   - 物理名(snake_case)は書かない(`casing: "snake_case"` で解決)
   - `_helpers.ts` の `idPk()` / `timestamps` / `enumCheck()` を使う。列挙値の正は `@jcredit/shared/enums`
   - 文字列は `varchar(n)` を使わず `text`(長さの上限は API の zod で持つ)
2. 生成: `pnpm db:generate --name <意味のある snake_case 名>`(`--name` 省略禁止 — ランダム名になる)
3. `packages/db/migrations/` の SQL を読んで意図どおりか確認。違えば schema を直して再生成(SQL を手で直さない)
4. 適用: `pnpm db:migrate`(**ユーザー確認後**。ローカル docker compose の DB に対して)
5. 設計書 `docs/design/detailed/db/<cluster>.md` を同じ PR で更新(新規クラスタは `docs/design/detailed/db/_template.md` から作る)
   - 手書きブロック: テーブルの業務的な意味・行の寿命・状態遷移・制約の理由・ER 図。カラム表は書かない
   - 生成ブロック(`<!-- generated:start table=<table_name> -->` 〜 `<!-- generated:end -->`): `pnpm db:docs` で更新。論理名の列以外は手で編集しない。
     新しいテーブルはマーカー 2 行を先に置く。足したカラムの論理名は `db:docs` の実行後に空いたセルへ書く(空のままだと失敗する)。CI が `pnpm db:docs --check` で古さを検出する(ADR-0004)

**画面設計からのデータ項目の追加の申請**(ADR-0008): 画面設計・画面の実装で DB に無い項目が要ると分かったときは、この手順で列を足す PR を単独で出す
(画面の PR に混ぜない)。PR のレビュー観点に、どの画面のどの項目に要るか・なぜ要るか・ほかの画面やレーンへの影響を書く。
マージされたら、画面設計の画面項目定義に足し、Open questions から消す(画面設計の側の PR で)。

schema にカラムの説明コメントを付けない。書くのは制約の理由や、型から読めない業務ルールだけ(`docs/code-comments.md`)。
