---
name: create-pr
description: 作業ブランチから develop への PR を作る。品質ゲート(biome / typecheck / vitest)→ 画面変更があれば /pr-screenshots → PR 作成の順。PR は develop 向け(stacked PR は親ブランチ)。
---

# /create-pr — develop への PR 作成

## 前提
- 作業ブランチは `develop` から切った feature ブランチ(`feat/...` / `fix/...` / `chore/...` / `docs/...`)。
  `main` / `staging` / `develop` 上では作業しない(`git switch -c feat/xxx develop`)。
- PR の base は **develop**。作業ブランチの上に積む stacked PR だけ親ブランチを base にできる(docs/branching.md。
  本文 Summary の 1 行目に `Stack:` 行が必要。`stacked` ラベルは CI が付ける)。`staging` / `main` への PR は promotion 専用。

## 手順
1. 品質ゲート(M1 16GB のため **変更したパッケージだけ**を対象にし、逐次実行する)
   ```bash
   pnpm check                                  # biome(format + lint)
   pnpm --filter @jcredit/<changed-pkg> typecheck
   pnpm --filter @jcredit/<changed-pkg> test
   ```
2. 画面変更の有無を確認
   ```bash
   node scripts/screenshots/cli.mjs plan            # stacked PR は --base <親ブランチ>
   ```
   `NO_SCREENS` 以外なら **`/pr-screenshots` を実行**して `## Screenshots` セクションを得る(Claude in Chrome で撮影。Playwright 不可)。
3. コミット & push(ユーザー確認のうえ)
   ```bash
   git push -u origin HEAD
   ```
4. PR 作成。本文は `.github/PULL_REQUEST_TEMPLATE.md` の 5 セクションに従う(分量の上限は
   [docs/pr-and-issues.md](../../../docs/pr-and-issues.md))。画面変更があれば `upload` が出力した
   `## Screenshots` セクションを **そのまま** 含める。`## Screenshots` は最後に置かず、後ろに `## 動作確認` を置く。
   ラベルは `type:` を 1 つ、`area:` を変更したアプリ / パッケージの分だけ付ける(定義は `.github/labels.yml`)。
   ```bash
   gh pr create --base develop --title "<type>: <日本語の要約>" \
     --label "type: feature" --label "area: api" \
     --body "$(cat <<'BODY'
   ## Summary
   <2〜3行。何を・なぜ。関連 Issue は Closes #123>

   ## 変更点
   - <3〜7項目。ファイル名の羅列にしない>

   ## レビュー観点
   <1〜3行。判断が割れうる所 / 確信が持てなかった所 / 見送ったこと。無ければ「特になし」>

   ## Screenshots
   | Screen | Before | After |
   |--------|--------|-------|
   | <app> `<route>` | ![before](...) | ![after](...) |

   ## 動作確認
   - [x] `pnpm check`
   - [ ] 手動: <確認した操作>
   BODY
   )"
   ```
   stacked PR は `--base feat/<topic>` にし、Summary の 1 行目に `Stack: #10 → **#11**` を置く。
   `.claude/hooks/pr-guard.sh` が base とスクリーンショットを検査し、不足していればブロックする。
   stacked PR は作成後に GitHub のスタックへつなぐ(`gh extension install github/gh-stack` が前提。docs/branching.md):
   ```bash
   PARENT=$(gh pr list --head <親ブランチ> --state open --json number --jq '.[0].number')
   gh stack link "$PARENT" <作った PR 番号>
   ```
   下の PR の `Stack:` 行も、新しい PR を足した形に更新する(`gh pr edit <下の PR> --body-file ...`)。
5. PR URL をユーザーに報告する。**マージはしない**(`gh pr merge` は deny)。
