---
name: add-page
description: Next.js の画面(page)を追加する。対象アプリの確認 → RSC の page.tsx + _components/_hooks の分離 → API 呼び出しは lib/api.ts 経由 → screenshots.config.json の更新。
---

# /add-page — 画面の追加

1. **どのアプリか**を先に確定する: `apps/admin-console`(運営者)/ `apps/partner-console`(創出PT)/ `apps/member-portal`(会員)。相互に import しない。
2. `app/<route>/page.tsx` は RSC。データ取得は `lib/api.ts` の `getApiClient()`(サーバー側のみ)。
3. クライアント機能は `_components/<Name>.client.tsx`(PascalCase)、ロジックは `_hooks/useXxx.ts`(camelCase)へ。
4. UI は `packages/ui` の shadcn を先に確認。無ければ `packages/ui/src/components/` に追加(kebab-case)。
5. Server Action は同ディレクトリの `actions.ts`("use server")。`loading.tsx` を添える。
6. 動的ルート(`[id]`)を作ったら `apps/<app>/screenshots.config.json` の `routeParams` にサンプル URL を登録する(PR スクリーンショットで必要)。
7. E2E は `apps/<app>/e2e/<name>.spec.ts`(Playwright はテスト用。スクリーンショット撮影には使わない)。
8. 設計書 `docs/design/detailed/<app>/<feature>/`(入口の `README.md` と画面ごとの `<screen>.md`)を同じ PR で更新(新規機能は `docs/design/detailed/_screen-template/` をコピーして作る。1 機能 1 ディレクトリ・1 画面 1 ファイル)。
   書くのは利用者と権限・画面遷移・業務ルール・空 / エラー / 権限なし時の振る舞い・画面項目定義・呼ぶ API 名。コンポーネント名は書かない(ADR-0004)。
   画面項目定義は DB の項目を正にする(ADR-0008)。実装で DB に無いデータ項目が要ると分かったら、この PR で列を足さずに、データ項目の追加を別の PR(`/add-db-migration`)で申請する
9. PR 前に `/pr-screenshots`。

コメントは書かないのが既定。書くのは既定値やマジックナンバーの根拠、落とし穴、ファイル先頭 1 行の役割宣言だけ(`docs/code-comments.md`)。
