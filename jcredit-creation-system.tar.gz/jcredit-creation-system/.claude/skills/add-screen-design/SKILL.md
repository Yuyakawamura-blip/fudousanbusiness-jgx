---
name: add-screen-design
description: 画面詳細設計(docs/design/detailed/<app>/<feature>/ — 入口の README.md と 1 画面 1 ファイル)を Issue から書く。Issue → 基本設計・DB 設計を読む → Figma のページから対象のフレームを全部洗い出して webp を置く → 突き合わせ(デザインの項目と DB の列を含む)→ テンプレートで書く(画面項目定義は DB の項目を正にする)→ 画面をまたぐ決まりを基本設計へ → 自己点検 → コミットせずに報告。
---

# /add-screen-design — 画面詳細設計を書く

書き方の規約は [docs/design/README.md](../../../docs/design/README.md) の「画面設計」、ひな形は `docs/design/detailed/_screen-template/`(入口の `README.md` と画面の `screen.md`)。
見本は `docs/design/detailed/member-portal/signup/`(1 本目)。同じアプリに書いたものがあれば、それにも書きぶりを揃える。

Issue の作業では、ルールやハーネス(`.claude/hooks/`・`.claude/settings.json`・`.claude/skills/`・CLAUDE.md・AGENTS.md・`docs/code-comments.md`)を変えない。
手順やルールを直したほうがよいと思ったら、報告に書いて別の PR にする。

## 1. 準備
- `gh issue view <番号>` で、書くファイル名・「やること」(画面)を控える
- 自分をアサインし、Project(課題管理表)の Status を `In Progress` にする

  ```bash
  gh issue edit <番号> --add-assignee @me
  # Project の item id と project id
  gh api graphql -f query='query{repository(owner:"japan-gx-group",name:"jcredit-creation-system"){issue(number:<番号>){projectItems(first:5){nodes{id project{id number}}}}}}'
  gh project field-list 7 --owner japan-gx-group --format json -q '.fields[] | select(.name=="Status")'  # field の id と In Progress の option id
  gh project item-edit --project-id <project id> --id <item id> --field-id <field id> --single-select-option-id <In Progress の option id>
  ```

- develop からブランチを切る: `git switch -c docs/screen-<app>-<feature> develop`(`<app>` は `member` / `partner` / `admin`)
- `PLAN.md` をこの Issue の内容に書き換える(チェックボックス)

## 2. 基本設計・DB 設計を読む(こちらが正)
| 資料 | 拾うもの |
| --- | --- |
| `docs/design/basic/screen-flow/<app>.md` | 画面のパスと遷移。パスはここが正で、変えるならここも直す |
| `docs/design/basic/auth.md` | 権限。画面設計には表を参照したうえで、画面固有の条件だけを書く |
| `docs/design/basic/api-usecases/<lane>.md` | 呼ぶユースケース、「このレーンの決まり」、Open questions |
| `docs/design/basic/error-handling.md` | 未ログイン・権限なし・エラーの共通の行き先。違うときだけ画面設計に書く |
| `docs/design/basic/domain.md` | 用語(画面名・状態の呼び方) |
| `docs/design/detailed/db/<cluster>.md` | 状態遷移と制約(何が必須か、いつ状態が変わるか)。画面に出す項目の列(画面項目定義の正。ADR-0008) |

## 3. Figma のフレームを洗い出し、画像を置く
画面のパス(`screen-flow` の表)は 1 画面 = 1 行だが、Figma には同じパスの状態違い(完了・送信済み・入力エラー・空・期限切れ)と
分岐違い(個人 / 法人、招待あり / なし 等)が別フレームで並ぶ。パスごとにリンクを 1 つ聞くと、それ以外のフレームが抜ける。
**リンクは聞かずに、ページからフレームを全部洗い出してから確かめてもらう。**

1. Figma のファイル(どのページでもよい)のリンクを 1 つだけユーザーに聞く。fileKey が分かればよい
2. `get_metadata`(nodeId なし)でページの一覧を取り、対象のアプリのページ(例: `mvp scope｜会員`)の id で `get_metadata` を呼ぶ。
   結果は大きいのでファイルに保存される。それを一覧にする:

   ```bash
   node scripts/figma/frames.mjs <保存されたファイル> --grep <セクション名・画面名の語,語> --url "<Figma の URL>"
   ```

3. 一覧から、この Issue の画面に当たるフレームを**全部**拾う。拾い方:
   - 機能のセクション(例: `01｜会員登録`)の中のフレームは全部候補にする。ほかの Issue に属するもの(例: 二段階認証は認証の Issue)は、その旨を設計書に 1 行書いて外す
   - 共通のセクション(`エラー・システム` 等)から、この機能で出る状態(リンクの期限切れ・ロック等)を拾う
   - 「旧版」「Archive」「調整用」は拾わない
4. 拾ったフレームと、どの画面・状態に当てるかの対応表を AskUserQuestion で見せ、足りないもの・違うものが無いかを 1 回で確かめる。
   一覧に見当たらない画面(デザインが無い状態)だけを、作成者に聞く
5. 画像は Figma MCP で撮って webp にし、`docs/design/detailed/<app>/<feature>/images/<screen>-<状態>.webp` に置く(状態が 1 つだけの画面は `<screen>.webp`)(要るもの: `brew install webp` の `cwebp`)。
   一覧に出ている「長辺」(幅と高さの大きいほう)を `get_screenshot` の `maxDimension` に渡す(デスクトップ幅 1440px のまま撮るため。既定の 1024 だと横幅が潰れる。高さを渡すと、横長の画面は 1440px より小さくなる)。
   返ってきた URL を落として変換する: `curl -sfL -o /tmp/x.png "<image_url>" && cwebp -quiet -q 80 /tmp/x.png -o <置き場所>.webp`
6. 撮った画像を全部見て、フレーム名どおりの画面かを確かめる。業務ルールの手がかり(必須・任意、注記、選択肢、分岐、どの画面で同意を取るか、エラーの出し方)を拾い、次の突き合わせに入れる
7. フレーム名に要件定義の画面 ID が入っていても、設計書には写さない(リンクと画像だけを置く)

## 4. 突き合わせる
- デザインと設計が食い違う → 業務ルールに関わるもの(どの画面で同意を取るか等)はデザインに合わせて設計を直す。基本設計で決めたことと食い違うときは基本設計を優先し、デザインに足してほしいことを Open questions に挙げる
- どちらにも無い → 一般的なやり方で決めて書き、Open questions に先方に確かめることとして残す。決める前に先方へ聞かない
- 複数の画面・複数のアプリに効く決まり → 基本設計(`auth.md` / `error-handling.md` / `api-usecases/<lane>.md` / `screen-flow/<app>.md`)に書き、画面設計からはリンクする。同じ PR で直す
- この画面で決めたことで基本設計の Open questions が解けたら、基本設計の側から消す
- デザインの項目と DB の列を突き合わせる(DB の項目一覧が正。ADR-0008)
  - DB に列がある → 画面項目定義の「対象のデータ」に論理名(物理名)、「テーブル」に表を書く。DB にあってデザインに無い項目は、画面に出すかを業務ルールとして決める
  - DB に列が無いデータ項目 → **画面設計で足さない**(項目定義に載せず、業務ルールの前提にもしない)。要る項目と理由を Open questions に挙げ、
    報告で「データ項目の追加の申請」が要ると伝える。申請は画面設計とは別の PR(DB 設計・schema・migration。`/add-db-migration`)で出し、
    マージされてから画面項目定義に足す。画面設計の PR の中で DB 設計・schema を変えない
  - データを持たない画面だけの項目(見出し・固定の文言・ボタン・リンク・ダイアログ・トースト・DB に持たない固定の選択肢)→ DB と突き合わせない。「対象のデータ」は「—(画面項目)」、「テーブル」は「—」

## 5. 書く
`docs/design/detailed/_screen-template/` をディレクトリごとコピーして `docs/design/detailed/<app>/<feature>/` に置き、`screen.md` を画面の数だけ複製して名前を付ける。

- 分け方: 1 機能 = 1 ディレクトリ。画面は 1 パス 1 ファイル(名前は画面の役割を英語の kebab-case で。例: `email-registration.md`)。
  状態違い(完了・入力エラー・個人 / 法人・招待あり / なし)はファイルを分けず、画面のファイルの画像の表と各節に並べる。
  同じ画面でパスだけが違うもの(ブランド違い等)は 1 ファイルにまとめる。複数の画面で出る共通の表示(リンクの期限切れ等)は 1 ファイルにして各画面からリンクする
- 入口の `README.md` に置くもの: 概要・利用者と権限・画面遷移・画面の一覧(パスと設計書)・画面をまたぐ決まり(2 つ以上の画面に効くもの)・Open questions(画面のものも全部ここに集める)
- 画面のファイルに置くもの: Figma のリンクと画像・その画面だけの業務ルール・空 / エラー / 権限なし・画面項目定義・呼ぶ API。画面をまたぐ決まりは書き写さず、README の節を名前で指す
- 書く: 利用者と権限 / 画面遷移(Mermaid)/ 画面ごとの業務ルールとその理由・空 / エラー / 権限なしのときの動き・画面項目定義・呼ぶ API
- 画面項目定義: 列は No / 表示エリア / 画面の項目 / 区分 / 条件 / 対象のデータ / データの内容 / テーブル / 備考(各列に書くことは docs/design/README.md の「画面設計」)。
  対象のデータは DB 設計の論理名(物理名)、テーブルは表の物理名で書き、型・NULL・桁は書かない(DB 設計が正)。列から計算する値は元の列と計算を書く
- 書かない: DB に無いデータ項目・コンポーネント名・型・見た目・変更履歴・要件定義資料の ID(機能要件・通知・画面・状態の番号。Stop フックが止める)
- 理由を添える: 「なぜその条件か」「なぜ断るのか」を 1 文で。理由の無い決まりは、実装した人が変えてよいのか判断できない
- 数値(期限・回数): 根拠があれば添える。非機能要件で決める値は「非機能要件で決める」と書き、仮の数字を書かない
- 呼ぶ API: エンドポイントが未実装のうちは `api-usecases/<lane>.md` のユースケース名(設計書の名前)で書く(例: `member-registration` の仮登録)。パスを先に作らない。実装したらエンドポイント名に置き換える
- Figma: リンクと画像(`![<状態>](images/<screen>-<状態>.webp)`)を画面のファイルの頭に置く。フレームが無い状態は `<状態>: 未作成` とし、できたら足す

## 6. 自己点検
- Issue の「やること」の画面が、すべて README の「画面」の表と画面のファイルにあるか。画像のパスが開けるか
- 手順 3 で拾ったフレームが、すべて設計書のどこか(画像・状態の説明)に当たっているか。外したものは理由を書いたか
- 各画面について、次の状態を考えたか(デザインに無ければ Open questions へ): 完了・送信済み / 入力エラー / 空 / リンク・招待の期限切れ / 権限なし・ログイン済みで開いた / 分岐(個人・法人、招待あり・なし 等)
- 画面遷移の図とパスが `screen-flow/<app>.md` と合っているか(図を変えたら両方を直す)
- 利用者と権限が `auth.md` の表と食い違っていないか
- Open questions に、未決のまま進めたことがすべてあるか
- 画面項目定義のデータ項目が、すべて DB 設計にある列か(`docs/design/detailed/db/` の生成ブロックで引ける)。DB に無い項目を書いていないか。DB に無くて要る項目を Open questions に挙げたか

## 7. 報告
- コミットせず、作業ツリーに置いたまま報告して指示を待つ。報告には、決めたこと(基本設計を直したものを含む)と Open questions を並べる。
  DB に無くて要るデータ項目があれば、項目・理由・使う画面を並べ、データ項目の追加の申請(別の PR)を出すかを聞く
- OK が出たらコミット → `/create-pr`(docs だけなのでスクリーンショットは要らない)。PR の Summary に `Closes #<Issue 番号>`
