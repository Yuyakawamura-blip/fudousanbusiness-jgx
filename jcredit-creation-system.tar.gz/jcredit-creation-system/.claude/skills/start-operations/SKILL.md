---
name: start-operations
description: 運用設計・業務マニュアル(docs/operations/)の作業を始める。operations ブランチに最新の develop を取り込む → 必読と対応する開発の設計書を読む → docs/operations/ の中だけを書く → operations に push → 区切りで operations → develop の PR。
---

# /start-operations — 運用設計の作業を始める

規約は [docs/operations/README.md](../../../docs/operations/README.md)、ブランチの運用は [docs/branching.md](../../../docs/branching.md) の「運用設計(`operations`)」。

## 1. 最新の develop を取り込む
作業ツリーに変更があれば止めて、ユーザーに確認する(別の作業が残っている)。

```bash
git status --short                      # 空であること
git fetch origin
git switch operations                          # 初回でローカルに無ければ: git switch -c operations --track origin/operations
git pull --ff-only
git merge --no-edit origin/develop
git push
```

- merge で衝突したら自分で解決せず、衝突したファイルを報告して止める(`docs/operations/` の外なら開発側の判断が要る)
- force push はしない

## 2. 読む
1. `docs/operations/README.md`(必読・守ること・構成)
2. 書く章の「参照する開発の設計書」の行にあるファイル
3. 書く章の既存ファイル(`## Open questions` を含む)

## 3. 書く
- 変更してよいのは `docs/operations/` の中だけ。外を編集しようとするとフックが警告し、push すると CI(Operations Scope)が落ちる
- 開発の設計書と食い違っていたら、その章の `## Open questions` に書き、Issue(`type: docs` + `area: operations`)で開発へ渡す
- 書き終えたら、ユーザーの確認を取ってから `operations` にコミット・push する(コミットは日本語で「何をしたか」を 50 文字以内)

## 4. 区切りで develop へ PR
章の初稿・レビュー依頼のときだけ。テンプレートは通常どおりで、`## Screenshots` は画面変更が無いので削除する。

```bash
gh pr create --base develop --head operations --title "docs: <日本語の要約>" \
  --label "type: docs" --label "area: operations" --body "..."
```

マージは **Create a merge commit** で行う(squash だと次の PR で同じ差分がもう一度出て、`operations` で衝突しやすい)。
