---
name: add-api-route
description: Hono API にエンドポイントを追加する。レーン(admin / partner / member)を決め、schemas → repositories → services → routes の順に同レーン内で完結させる。
---

# /add-api-route — API エンドポイントの追加

1. **レーン**を確定する(admin / partner / member)。他レーンのファイルは import しない(`lane-isolation.test.ts` が弾く)。同じ処理でも複製する。**共通化のために `lib/` に業務ロジックを置かない**(`lib/` はレーン層とテーブル定義を import できない — ADR-0006)。
2. `src/schemas/<lane>/<resource>.ts` に zod schema(request / response)。
3. `src/repositories/<lane>/<resource>.ts` に DB アクセス(`lib/db.ts` の `db`、Drizzle)。
4. `src/services/<lane>/<resource>.ts` に業務ロジック。エラーは `lib/errors.ts` の `AppError` を throw。
5. `src/routes/<lane>/<resource>.ts` に `createRoute({ method, path, tags: ["<lane>"], summary, request, responses: { 200: ..., ...errorResponses } })` を定義し、`openApiApp().openapi(route, handler)` で実装(`new OpenAPIHono()` 直書き禁止)。`routes/<lane>/index.ts` の `.route()` チェーンに追加(RPC 型に乗せるためチェーンを切らない)。追加したエンドポイントは自動で `/openapi.json` と Scalar `/docs` に載る。
6. テスト: `src/routes/<lane>/__tests__/<resource>.test.ts`(200 / 400 / 404、認証があれば 401・403)。`app.request()` で叩く。
7. Web 側は `@jcredit/api/app` の `<Lane>Router` 型(`lib/api.ts` で type import)経由で自動的に型が流れる。
8. 複数エンドポイント・複数テーブル・外部連携をまたぐ処理なら、設計書 `docs/design/detailed/api/<lane>/<usecase>.md` を同じ PR で更新
   (`docs/design/detailed/api/_template.md` から作る。ユースケース単位)。単一エンドポイントで完結するなら作らない — 仕様は Scalar が持つ(ADR-0004)

レーンを複製する際、各ファイル先頭の役割宣言(W-6)以外のコメントは持ち込まない。zod schema や route 定義に説明コメントを付けない — `summary` / `description` が同じ役割を持つ(`docs/code-comments.md`)。
