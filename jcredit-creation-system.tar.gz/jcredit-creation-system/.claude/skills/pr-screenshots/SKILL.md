---
name: pr-screenshots
description: 画面(apps/*/app/** または packages/ui/**)を変更した PR 用に、変更前・変更後のスクリーンショットを Claude in Chrome で撮り、GitHub Release に上げて PR 本文の「## Screenshots」セクションを生成する。PR 作成前に必須(pr-guard フックと CI が検証する)。
---

# /pr-screenshots — 変更前後スクリーンショットの取得

画面を変更した PR は、該当画面の **変更前(base 断面。通常は develop、stacked PR は親ブランチ)** と **変更後(現在の作業ツリー)** の
スクリーンショットを PR 本文に載せなければならない。`.claude/hooks/pr-guard.sh`(PR 作成コマンド実行時)と
CI(`.github/workflows/pr-screenshots.yml`)が本文を検証し、不足していれば PR を作れない / チェックが落ちる。

## 絶対に守ること

- **スクリーンショットは Claude in Chrome(`mcp__claude-in-chrome__*`)で撮る。Playwright やヘッドレスブラウザで撮らない。**
  Playwright はこのリポジトリでは E2E テスト専用。
- Web のみ。**デスクトップ幅(1440×900)だけ**撮る。スマホ幅は撮らない。
- 撮影対象は `plan` の出力が正。恣意的に減らさない。動的ルートは `screenshots.config.json` にサンプル URL を登録してから撮る。
- 認証が必要な画面が出てきたら(将来)、ログイン済みのタブで撮る。ログイン操作の資格情報は自分で入力しない(ユーザーに依頼)。

## 手順

### 0. 準備
```bash
git fetch origin develop
node scripts/screenshots/cli.mjs plan            # 撮影対象を導出 → .screenshots/<branch>/plan.json(stacked PR は --base <親ブランチ>)
```
- `NO_SCREENS` と出たらスクリーンショット不要。ここで終了(PR 作成へ)。
- `NEEDS_PARAMS` が出た target は `apps/<app>/screenshots.config.json` の `routeParams` に
  `"/projects/[id]": "/projects/<存在するサンプルID>"` の形で登録し、`plan` をやり直す。
- 変更ファイルから導けない画面(例: layout 変更で影響が広い、共通コンポーネント差し替え)は
  `extraRoutes` に追加して `plan` をやり直す。

### 1. 変更前(before)
```bash
node scripts/screenshots/cli.mjs baseline start   # develop 断面の worktree + dev サーバ(ポート = 本来のポート + 1000)
```
API は現在の作業ツリーのもの(`pnpm --filter @jcredit/api dev`、8787)を共用する。起動していなければ先に起動する。

Claude in Chrome で各 target を撮る:
1. `mcp__claude-in-chrome__tabs_context_mcp`(createIfEmpty: true)→ 新規タブ `tabs_create_mcp`
2. `resize_window` で **1440×900**
3. `navigate` で baseline URL(`baseline start` の末尾に表示。例 `http://localhost:4001/`)
4. 描画が落ち着くまで `computer` の `wait`(1〜2 秒)。エラー画面・ローディングのままなら撮らずに原因を直す
5. `computer` の `screenshot` を **`save_to_disk: true`** で実行 → 返ってきた保存パスを控える
6. 取り込み:
   ```bash
   node scripts/screenshots/cli.mjs add --phase before --target <id> <保存パス>
   ```
全 target を撮り終えたら:
```bash
node scripts/screenshots/cli.mjs baseline stop
```

### 2. 変更後(after)
現在の作業ツリーの dev サーバ(`pnpm --filter @jcredit/<app> dev`、本来のポート)で同じ手順を繰り返し、
`--phase after` で取り込む。**before と同じ URL パス・同じウィンドウサイズ・同じスクロール位置**で撮る。

### 3. 確認と upload
```bash
node scripts/screenshots/cli.mjs status          # ALL_CAPTURED になるまで戻る
node scripts/screenshots/cli.mjs upload          # GitHub Release "screenshots-bucket" へ upload → SECTION.md
```
`upload` が出力した `## Screenshots` セクションを **そのまま PR 本文に含める**(`/create-pr`)。
表の各行は `<app> \`<route>\` | ![before](URL) | ![after](URL)` の形で、CI はこの形を検査する。

### 4. 目視レビュー
`screenshot-reviewer` サブエージェントに `.screenshots/<branch>/` を渡し、崩れ・未描画・エラー表示が無いか確認する。
NG があれば直して after を撮り直す。

## 後片付け
- 開いたタブは `tabs_close_mcp` で閉じる
- `.screenshots/` と `.claude/worktrees/` は gitignore 済み。コミットしない
