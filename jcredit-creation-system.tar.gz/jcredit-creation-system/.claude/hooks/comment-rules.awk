# 入力: "行番号<TAB>行の内容"。docs/code-comments.md の C-n に当たる行だけを出す。
# 変数 F にファイルパスを渡す。検出できるのは形の決まった違反だけ(ADR-0003)。requirement-id.awk と一緒に読み込む。
BEGIN { FS = "\t" }
{
  ln = $1
  src = $0
  sub(/^[^\t]*\t/, "", src)
  gsub(/:\/\//, ":__SS__", src)   # URL の // をコメント開始と誤認しない

  c = ""
  if (src ~ /^[ \t]*(\/\/|\/\*|\*)/) c = src
  else {
    i = index(src, "//")
    if (i > 0) c = substr(src, i)
    else { i = index(src, "/*"); if (i > 0) c = substr(src, i) }
  }
  if (c == "") next

  g = c
  # CSS の色(#rgb / #rrggbb)は W-2 として正当なので番号検出から外す
  gsub(/#[0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f]([0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f])?/, "__HEX__", g)

  id = ""
  if (g ~ /#[0-9]+/ || g ~ /[Ii]ssue *#?[0-9]+/ || g ~ /(^|[^A-Za-z])PR *#?[0-9]+/ \
      || g ~ /github\.com\/[^ )]*\/(pull|issues)\/[0-9]+/ || has_requirement_id(g)) id = "C-2"
  else if (g ~ /^[ \t]*(\/\/|\*|\/\*)[ \t]*\(?20[0-9][0-9][-\/.]/) id = "C-3"
  else if (g ~ /^[ \t]*\/\/[ \t]*(const|let|var|function|return|import|export|await|if|for|while|switch|throw|new)[ (].*[;{)\x27"]$/) id = "C-4"
  else if (g ~ /^[ \t]*(\/\/|\*)[ \t]*[=*_-][=*_-][=*_-][=*_-]/) id = "C-5"
  else if (g ~ /@param/ || g ~ /@returns?([^A-Za-z]|$)/ || g ~ /@type([^A-Za-z]|$)/) id = "C-6"
  else if (index(g, "とりあえず") || index(g, "暫定的") || index(g, "暫定対応") || index(g, "一時的に")) id = "C-7"
  else if (index(g, "しました") || index(g, "要望により") || index(g, "指示により")) id = "C-8"
  if (id == "") next

  t = c
  sub(/^[ \t]+/, "", t)
  gsub(/:__SS__/, "://", t)
  printf "  %s:%s  [%s] %s\n", F, ln, id, t
}
