# 要件定義資料の ID(機能要件・通知・業務ルール・画面・状態)を含むかを返す。comment-rules.awk(コードのコメント)と
# requirement-id-rules.awk(設計書)の両方から -f で読み込み、パターンを 1 か所に置く。
# 前の文字に英数字を許さない(「10MB-20MB」のような大きさの範囲を ID と取り違えないため)。
function has_requirement_id(s) {
  return s ~ /(^|[^A-Za-z0-9])(FR|NT|BR|LK|MB)-[0-9][0-9]/ || s ~ /(^|[^A-Za-z0-9])SCR-[A-Z]-[0-9]/
}
