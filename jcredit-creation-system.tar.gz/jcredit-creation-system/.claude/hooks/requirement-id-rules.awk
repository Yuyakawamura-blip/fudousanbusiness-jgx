# 入力: "行番号<TAB>行の内容"。要件定義資料の ID を含む行だけを出す。requirement-id.awk と一緒に読み込む。
# 変数 F にファイルパスを渡す。設計書(docs/**/*.md)用。コードのコメントは comment-rules.awk の C-2 が同じ関数で見る。
# 資料の版が上がると ID が振り直され、資料を開かないと意味が分からないので、言葉で書く(docs/code-comments.md)。
BEGIN { FS = "\t" }
{
  ln = $1
  src = $0
  sub(/^[^\t]*\t/, "", src)
  if (has_requirement_id(src)) {
    t = src
    sub(/^[ \t]+/, "", t)
    printf "  %s:%s  [要件定義の ID] %s\n", F, ln, t
  }
}
