# _node-path.sh — フックから source される共有スニペット。
# 非対話 bash は ~/.zshrc を読まないため、nvm / fnm / volta / Homebrew の Node を PATH 前置する。
# 制約: 呼び出し側は `set -euo pipefail`。絶対に非0で抜けない/未定義変数を踏まないこと。
__candidates=(
  "${NVM_DIR:-${HOME:-}/.nvm}/versions/node"
  "${FNM_DIR:-${HOME:-}/.local/share/fnm}/aliases/default/bin"
  "${VOLTA_HOME:-${HOME:-}/.volta}/bin"
  "/opt/homebrew/bin"
)
for __c in "${__candidates[@]}"; do
  if [[ "$__c" == */.nvm/versions/node ]]; then
    # nvm: 最新の v24 系を選ぶ(.node-version = 24)
    __latest=$(ls -d "$__c"/v24.* 2>/dev/null | sort -V | tail -1 || true)
    [ -n "${__latest:-}" ] && __c="$__latest/bin"
  fi
  if [ -x "$__c/node" ]; then
    case ":$PATH:" in
      *":$__c:"*) ;;
      *) PATH="$__c:$PATH"; export PATH ;;
    esac
    break
  fi
done
unset __candidates __c __latest
true
