#!/usr/bin/env bash
# PreToolUse(Bash): PR 作成コマンド(gh pr create)をガードする。
#   1. PR の base は develop、または open な PR を持つ作業ブランチ(stacked PR)。
#      staging / main へは develop→staging / staging→main の promotion PR だけ許可
#   2. 画面(apps/*/app/** / packages/ui/**)を変更した PR は、本文の `## Screenshots` に
#      各画面の Before / After 画像が揃っていないと作成できない(scripts/screenshots/cli.mjs check)
# コマンドの解析(heredoc 本文の除外・--base / --body-file の抽出)は cli.mjs pr-command が行う。
# ブロック時は exit 2 で理由を stderr に出す(Claude が読んで対処する)。
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/_node-path.sh" 2>/dev/null || true

INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // ""')
[ -n "$CMD" ] || exit 0

ROOT="${CLAUDE_PROJECT_DIR:-$(git rev-parse --show-toplevel)}"
cd "$ROOT"
[ -f scripts/screenshots/cli.mjs ] || exit 0

PARSED=$(printf '%s' "$CMD" | node scripts/screenshots/cli.mjs pr-command --stdin 2>/dev/null || echo '{"invokes":false}')
INVOKES=$(echo "$PARSED" | jq -r '.invokes')
[ "$INVOKES" = "true" ] || exit 0

BASE=$(echo "$PARSED" | jq -r '.base // "develop"')
BODY_FILE=$(echo "$PARSED" | jq -r '.bodyFile // empty')

# --- 1. base ブランチの検査 ---------------------------------------------------
HEAD_BRANCH=$(git rev-parse --abbrev-ref HEAD)
WARN=""
PARENT=""
case "$BASE" in
  develop) ;;
  staging)
    if [ "$HEAD_BRANCH" != "develop" ]; then
      echo "Blocked: staging への PR は develop ブランチからの promotion PR のみ許可(現在: $HEAD_BRANCH)。通常の PR は --base develop。" >&2
      exit 2
    fi ;;
  main)
    if [ "$HEAD_BRANCH" != "staging" ]; then
      echo "Blocked: main への PR は staging ブランチからの promotion PR のみ許可(現在: $HEAD_BRANCH)。通常の PR は --base develop。" >&2
      exit 2
    fi ;;
  *)
    # stacked PR: base に open な PR があれば許可(docs/branching.md)。
    if [ "$BASE" = "$HEAD_BRANCH" ]; then
      echo "Blocked: base と head が同じブランチです($BASE)。" >&2
      exit 2
    fi
    # gh が無い・確認に失敗したときは警告だけにして通す。フックの gh はセッションの GH_TOKEN を受け取らず、
    # keyring の active アカウントに org の権限が無いと必ず失敗するため。base の検査は CI(pr-base-branch.yml)が必ず行う
    # stderr は $PARENT に混ぜない(gh が成功時にも notice を出すことがあり、空判定が狂う)
    GH_ERR=$(mktemp)
    if ! command -v gh >/dev/null 2>&1; then
      WARN="gh CLI が無いため、base '$BASE' に open な PR があるかを確認していません(CI の pr-base-branch で検査されます)。"
    elif ! PARENT=$(gh pr list --head "$BASE" --state open --json number --jq '.[0].number // empty' 2>"$GH_ERR"); then
      WARN="gh で base '$BASE' の PR を確認できなかったため、確認せずに通しました(CI の pr-base-branch で検査されます): $(head -n 1 "$GH_ERR")"
    fi
    rm -f "$GH_ERR"
    if [ -z "$WARN" ] && [ -z "$PARENT" ]; then
      echo "Blocked: PR の base は develop / staging / main、または open な PR を持つ作業ブランチ(stacked PR)のみ。'$BASE' に open な PR がありません。先に '$BASE' の PR を作るか、--base develop にする。" >&2
      exit 2
    fi ;;
esac

# --- 2. スクリーンショットの検査 ----------------------------------------------
# 本文は --body-file があればそのファイル、無ければコマンド文字列全体(heredoc の本文を含む)を渡す
if [ -n "$BODY_FILE" ] && [ -f "$BODY_FILE" ]; then
  RESULT=$(node scripts/screenshots/cli.mjs check --base "$BASE" --body-file "$BODY_FILE" 2>&1) && STATUS=0 || STATUS=$?
else
  RESULT=$(printf '%s' "$CMD" | node scripts/screenshots/cli.mjs check --base "$BASE" --stdin 2>&1) && STATUS=0 || STATUS=$?
fi
if [ "$STATUS" -ne 0 ]; then
  {
    echo "Blocked: PR にスクリーンショットが不足しています(または検証に失敗)。"
    echo "$RESULT"
    echo
    echo "スクリーンショットは Claude in Chrome で撮る(Playwright は使わない)。手順は /pr-screenshots スキル。"
  } >&2
  exit 2
fi
if [ -n "$WARN" ]; then
  jq -n --arg msg "pr-guard: $WARN" '{systemMessage: $msg}'
fi
exit 0
