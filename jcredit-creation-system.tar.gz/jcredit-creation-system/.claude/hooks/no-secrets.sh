#!/usr/bin/env bash
# PreToolUse(Bash): 危険なコマンド(秘密の漏洩、リモートスクリプトのシェル実行など)をブロックする。
set -euo pipefail

INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // ""')

if echo "$CMD" | grep -qE '(curl|wget)[^|]*\|\s*(sh|bash)\b'; then
  echo "Blocked: piping remote content into a shell is forbidden." >&2
  exit 2
fi
if echo "$CMD" | grep -qE '(\bcat\b|\bmv\b|\bcp\b|>)\s+[^|]*\.env(\.|$|\s)' && ! echo "$CMD" | grep -qE '\.env\.example'; then
  echo "Blocked: do not read or move .env files via shell." >&2
  exit 2
fi
if echo "$CMD" | grep -qE '/secrets/'; then
  echo "Blocked: secrets/ access via shell is forbidden." >&2
  exit 2
fi
exit 0
