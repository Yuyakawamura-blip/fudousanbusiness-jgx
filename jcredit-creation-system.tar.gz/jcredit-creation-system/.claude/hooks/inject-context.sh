#!/usr/bin/env bash
# SessionStart: 作業の文脈(git status / PROGRESS.md / PLAN.md / ブランチ規約の注意)を投入する。
set -euo pipefail
OUT=""
if git rev-parse --git-dir >/dev/null 2>&1; then
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "?")
  OUT="$OUT\n## Branch\n\`$BRANCH\`"
  case "$BRANCH" in
    main|staging|develop) OUT="$OUT — **保護ブランチ。直接コミットしない。** feature ブランチを develop から切ること(docs/branching.md)";;
    operations)
      OUT="$OUT — 運用設計のブランチ。変えてよいのは docs/operations/ の中だけ(docs/operations/README.md)"
      # fetch はしない(SessionStart を遅くしないため)。最新の取り込みは /start-operations が行う
      BEHIND=$(git rev-list --count HEAD..origin/develop 2>/dev/null || echo 0)
      [ "$BEHIND" -gt 0 ] && OUT="$OUT\n**origin/develop より $BEHIND コミット遅れています。** 作業の前に /start-operations で取り込むこと";;
  esac
  OUT="$OUT\n"
  STATUS=$(git status --short 2>/dev/null | head -20 || true)
  [ -n "$STATUS" ] && OUT="$OUT\n## Git status (modified files)\n\`\`\`\n$STATUS\n\`\`\`\n"
fi
if [ -f PROGRESS.md ]; then
  TAIL=$(tail -20 PROGRESS.md)
  [ -n "$TAIL" ] && OUT="$OUT\n## Last entries in PROGRESS.md\n$TAIL\n"
fi
if [ -f PLAN.md ]; then
  HEAD=$(head -30 PLAN.md)
  [ -n "$HEAD" ] && OUT="$OUT\n## Current PLAN.md\n$HEAD\n"
fi
[ -z "$OUT" ] && exit 0
jq -n --arg ctx "$(printf "$OUT")" '{ "hookSpecificOutput": { "hookEventName": "SessionStart", "additionalContext": $ctx } }'
