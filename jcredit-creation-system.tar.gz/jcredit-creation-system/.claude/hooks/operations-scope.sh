#!/usr/bin/env bash
# PreToolUse(Write|Edit): operations ブランチで docs/operations/ の外を編集しようとしたら警告する(止めない。止めるのは CI の Operations Scope)。
set -euo pipefail

BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
[ "$BRANCH" = "operations" ] || exit 0

INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')
[ -n "$FILE" ] || exit 0
ROOT="${CLAUDE_PROJECT_DIR:-$(git rev-parse --show-toplevel)}"
REL="${FILE#"$ROOT"/}"

case "$REL" in
  docs/operations/*) exit 0 ;;
  /*) exit 0 ;;
esac

MSG="operations ブランチで docs/operations/ の外($REL)を編集しようとしています。運用設計の作業では docs/operations/ の中だけを変えます(このまま push すると CI の Operations Scope が落ちる)。開発の範囲の変更が必要なら Issue で開発へ渡してください。"
jq -n --arg m "$MSG" '{ "systemMessage": $m, "hookSpecificOutput": { "hookEventName": "PreToolUse", "additionalContext": $m } }'
exit 0
