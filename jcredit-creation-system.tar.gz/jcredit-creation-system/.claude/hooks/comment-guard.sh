#!/usr/bin/env bash
# Stop: 変更ファイルの追加行のコメントを docs/code-comments.md のアンチリスト(C-n)に照らす。
# 設計書(docs/**/*.md)は追加行に要件定義資料の ID が無いかだけを見る。
# 検出できるのは形の決まった違反だけ。言い換えコメント(C-1)はレビューが見る(ADR-0003)。
set -euo pipefail

HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${CLAUDE_PROJECT_DIR:-$(git rev-parse --show-toplevel)}"
cd "$ROOT"
command -v jq >/dev/null 2>&1 || exit 0

CHANGED=$( { git diff --name-only HEAD; git ls-files --others --exclude-standard; } | sort -u || true)
[ -z "$CHANGED" ] && exit 0

FILES=$(echo "$CHANGED" | grep -E '\.(ts|tsx|js|jsx|mjs|cjs)$' || true)
DOCS=$(echo "$CHANGED" | grep -E '^docs/.*\.md$' || true)
[ -z "$FILES$DOCS" ] && exit 0

HITS=$(mktemp)
trap 'rm -f "$HITS"' EXIT

# 追加行だけを "行番号<TAB>内容" で出す(既存コードは遡及修正しない)
added_lines() {
  local f="$1"
  if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
    git diff -U0 HEAD -- "$f" | awk '
      /^\+\+\+/ { next }
      /^@@/     { if (match($0, /\+[0-9]+/)) n = substr($0, RSTART + 1, RLENGTH - 1) + 0; next }
      /^\+/     { print n "\t" substr($0, 2); n++ }
    '
  else
    awk '{ print NR "\t" $0 }' "$f"
  fi
}

for f in $FILES; do
  [ -f "$f" ] || continue
  added_lines "$f" | awk -v F="$f" -f "$HOOK_DIR/requirement-id.awk" -f "$HOOK_DIR/comment-rules.awk" >>"$HITS"
done
for f in $DOCS; do
  [ -f "$f" ] || continue
  added_lines "$f" | awk -v F="$f" -f "$HOOK_DIR/requirement-id.awk" -f "$HOOK_DIR/requirement-id-rules.awk" >>"$HITS"
done

[ -s "$HITS" ] || exit 0

REASON=$(printf 'Blocked: 変更行のコメント・設計書が規約(docs/code-comments.md)に反しています。該当行を直してから完了してください(要件定義の ID は言葉に書き直す)。\n\n%s\nC-2 PR / Issue 番号(ADR 番号のみ可)・要件定義資料の ID / C-3 日付・変更履歴 / C-4 コメントアウトされたコード /\nC-5 区切りバナー / C-6 JSDoc タグ / C-7 暫定表現 / C-8 作業ログ\n方針は ADR-0003。' "$(cat "$HITS")")
jq -n --arg r "$REASON" '{ "decision": "block", "reason": $r }'
exit 0
