#!/usr/bin/env bash
# PostToolUse(Write|Edit): 編集されたファイルを Biome で整形・lint する。Biome が無ければ no-op。
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/_node-path.sh" 2>/dev/null || true

INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

case "$FILE" in
  *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs|*.json|*.css) ;;
  *) exit 0 ;;
esac

command -v pnpm >/dev/null 2>&1 || exit 0
pnpm -s biome --version >/dev/null 2>&1 || exit 0

pnpm -s biome format --write "$FILE" >/dev/null 2>&1 || true
pnpm -s biome lint --write "$FILE" >/dev/null 2>&1 || true
exit 0
