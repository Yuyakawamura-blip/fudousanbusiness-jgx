#!/usr/bin/env node
/**
 * PR スクリーンショット・ハーネスの CLI。
 *
 *   node scripts/screenshots/cli.mjs <command> [options]
 *
 * 画面(apps/<app>/app/** / packages/ui/**)を変更した PR には、該当画面の「変更前」「変更後」の
 * スクリーンショットを PR 本文に載せることを必須にしている。このスクリプトは
 *   1. 変更ファイル → 撮影対象ルートの導出(plan)
 *   2. 変更前(base ブランチ断面)の dev サーバ起動(baseline start / stop)
 *   3. 撮影した画像(jpg / png)の取り込み(add)と進捗表示(status)
 *   4. GitHub Release への upload と PR 本文セクションの生成(upload / section)
 *   5. PR 本文の検証(check — Claude Code の PreToolUse フックと CI の両方から呼ぶ)
 * を担う。撮影そのものは Claude in Chrome(手順は .claude/skills/pr-screenshots)が行う。
 *
 * 依存ゼロ(node 組み込みのみ)。git / gh は子プロセスで呼ぶ。
 */
import { execFileSync, spawn } from "node:child_process";
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  openSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const WORK_ROOT = join(ROOT, ".screenshots");
const BASELINE_WORKTREE = join(ROOT, ".claude/worktrees/screenshot-baseline");
const RELEASE_TAG = "screenshots-bucket";
const BASELINE_PORT_OFFSET = 1000;
const DEFAULT_BASE = "develop";
/** 画面に影響するパス。ここに当たるファイルが変更されたらスクリーンショット必須 */
const SCREEN_FILE_RE = /^(apps\/([^/]+)\/app\/(.*)|packages\/ui\/src\/(.*))$/;
/** ルート導出の対象にならない特別ファイル(ルート自体は親ディレクトリで決まる) */
const NON_ROUTE_SEGMENT_RE = /^(_components|_hooks|_lib|_utils|__tests__)$/;

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
const git = (...args) => execFileSync("git", args, { cwd: ROOT, encoding: "utf8" }).trim();
const tryGit = (...args) => {
  try {
    return git(...args);
  } catch {
    return null;
  }
};
/**
 * gh CLI の唯一の呼び出し口。stdout を返し、失敗時は stderr を含む Error を throw する
 * (stderr は継承せず捕捉するので、呼び出し側でメッセージを判定できる)。
 */
const gh = (...args) => {
  try {
    return execFileSync("gh", args, {
      cwd: ROOT,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    }).trim();
  } catch (err) {
    const stderr = (err.stderr ?? "").toString().trim();
    const e = new Error(`gh ${args.slice(0, 2).join(" ")} failed${stderr ? `: ${stderr}` : ""}`);
    e.stderr = stderr;
    throw e;
  }
};

function parseArgs(argv) {
  const opts = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next !== undefined && !next.startsWith("--")) {
        opts[key] = next;
        i++;
      } else {
        opts[key] = true;
      }
    } else {
      opts._.push(a);
    }
  }
  return opts;
}

function currentBranch() {
  return tryGit("rev-parse", "--abbrev-ref", "HEAD") ?? "detached";
}

function slug(s) {
  return (
    s
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .toLowerCase() || "root"
  );
}

function workDir(branch = currentBranch()) {
  const dir = join(WORK_ROOT, slug(branch));
  mkdirSync(dir, { recursive: true });
  return dir;
}

function resolveBaseRef(base) {
  // 指定 > develop > main の順に探す(リポジトリ初期化直後など develop が無いときは main に落とす)
  const candidates = base ? [base] : [DEFAULT_BASE, "main"];
  for (const name of candidates) {
    for (const ref of [`origin/${name}`, name]) {
      if (tryGit("rev-parse", "--verify", "--quiet", ref) !== null) return ref;
    }
  }
  throw new Error(`base branch not found: ${candidates.join(" / ")} (fetch origin or pass --base)`);
}

/**
 * シェルコマンド文字列から heredoc 本文(`<<EOF` … `EOF`)を取り除く。
 * PR 作成コマンドの検出で、本文やスキル文書に書かれたコマンド例を誤検知しないため。
 */
function stripHeredocs(cmd) {
  const lines = cmd.split("\n");
  const out = [];
  let terminator = null;
  for (const line of lines) {
    if (terminator !== null) {
      if (line.trim() === terminator) terminator = null;
      continue;
    }
    const m = /<<-?\s*['"]?([A-Za-z_][A-Za-z0-9_]*)['"]?/.exec(line);
    out.push(line);
    if (m) terminator = m[1];
  }
  return out.join("\n");
}

/**
 * Bash ツールのコマンド文字列を解析し、PR 作成コマンドの呼び出しかどうかと
 * `--base` / `--body-file` を返す(pr-guard フック用)。
 */
function parsePrCommand(cmd) {
  const stripped = stripHeredocs(cmd);
  const invokeRe = /(^|[;&|(]\s*|\$\(\s*)gh\s+pr\s+create\b/m;
  if (!invokeRe.test(stripped)) return { invokes: false };
  const base = /(?:--base|-B)(?:[= ]+)("?)([^\s"']+)\1/.exec(stripped)?.[2] ?? "develop";
  const bodyFile = /(?:--body-file|-F)(?:[= ]+)("?)([^\s"']+)\1/.exec(stripped)?.[2] ?? null;
  return { invokes: true, base, bodyFile };
}

/** base との merge-base から HEAD + 作業ツリー(未コミット含む)までの変更ファイル */
function changedFiles(baseRef) {
  const mergeBase = git("merge-base", baseRef, "HEAD");
  const committed = git("diff", "--name-only", `${mergeBase}..HEAD`);
  const working = git("diff", "--name-only", "HEAD");
  const untracked = git("ls-files", "--others", "--exclude-standard");
  const all = new Set(
    [committed, working, untracked]
      .flatMap((s) => s.split("\n"))
      .map((s) => s.trim())
      .filter(Boolean),
  );
  return { mergeBase, files: [...all].sort() };
}

function listApps() {
  const appsDir = join(ROOT, "apps");
  return readdirSync(appsDir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && existsSync(join(appsDir, e.name, "app")))
    .map((e) => e.name);
}

function loadAppConfig(app) {
  const p = join(ROOT, "apps", app, "screenshots.config.json");
  if (!existsSync(p)) return { port: undefined, routeParams: {}, extraRoutes: [] };
  return JSON.parse(readFileSync(p, "utf8"));
}

/** `app/(console)/projects/[id]/_components/Form.client.tsx` → `/projects/[id]` */
function routeFromAppPath(rel) {
  const parts = rel.split("/");
  parts.pop(); // file name
  const segments = [];
  for (const seg of parts) {
    if (NON_ROUTE_SEGMENT_RE.test(seg)) break;
    if (seg.startsWith("(") && seg.endsWith(")")) continue; // route group
    if (seg.startsWith("@")) continue; // parallel route slot
    if (seg === "api") return null; // Route Handler は画面ではない
    segments.push(seg);
  }
  return `/${segments.join("/")}`.replace(/\/+$/, "") || "/";
}

/**
 * 変更ファイルから撮影対象を導く。
 * 戻り値: [{ app, route, reasons }] — id / url は expandTargets で config を当ててから決める。
 * 同一判定は app + 元の route で行う(slug は `/projects/new` と `/projects-new` を区別できない)
 */
function deriveTargets(files) {
  const targets = new Map();
  const add = (app, route, reason) => {
    const key = `${app} ${route}`;
    const existing = targets.get(key);
    if (existing) {
      if (!existing.reasons.includes(reason)) existing.reasons.push(reason);
      return;
    }
    targets.set(key, { app, route, reasons: [reason] });
  };
  let uiChanged = false;
  for (const f of files) {
    const m = SCREEN_FILE_RE.exec(f);
    if (!m) continue;
    if (m[2]) {
      const app = m[2];
      const rel = m[3];
      const route = routeFromAppPath(rel);
      if (route === null) continue;
      if (rel === "layout.tsx" || rel === "globals.css") {
        add(app, "/", `${f}(全画面に影響。代表として / を撮影。他の画面は extraRoutes で追加)`);
      } else {
        add(app, route, f);
      }
    } else {
      uiChanged = true;
    }
  }
  if (uiChanged) {
    for (const app of listApps()) {
      add(app, "/", "packages/ui 変更(全アプリに影響。代表として / を撮影)");
    }
  }
  return [...targets.values()];
}

function resolveUrl(target, config, port) {
  const paramsUrl = config.routeParams?.[target.route];
  const isDynamic = /\[.+?\]/.test(target.route);
  if (isDynamic && !paramsUrl) return { url: null, needsParams: true };
  const path = paramsUrl ?? target.route;
  return { url: `http://localhost:${port}${path}`, needsParams: false };
}

/**
 * 変更ファイル由来の対象に、各アプリの `screenshots.config.json` の `extraRoutes` を足し、
 * ポート・URL・id を確定する。plan / check / targets はすべてこれを通す —
 * plan だけが extraRoutes を見ると、check(フック / CI)がその画面の不足を見逃す。
 * 変更ファイル由来の対象を先に置くので、extraRoutes と重なる route は前者の reasons が残る。
 */
function expandTargets(raw) {
  const configs = new Map();
  const configOf = (app) => {
    if (!configs.has(app)) configs.set(app, loadAppConfig(app));
    return configs.get(app);
  };
  const seen = new Set();
  const targets = [];
  const push = (t) => {
    const key = `${t.app} ${t.route}`;
    if (seen.has(key)) return;
    seen.add(key);
    const config = configOf(t.app);
    const port = config.port ?? 3000;
    targets.push({ ...t, port, ...resolveUrl(t, config, port) });
  };
  for (const t of raw) push(t);
  for (const app of new Set(raw.map((t) => t.app))) {
    for (const route of configOf(app).extraRoutes ?? []) {
      push({ app, route, reasons: ["screenshots.config.json extraRoutes"] });
    }
  }
  return assignIds(targets);
}

/** id はファイル名・Release の asset 名に使う slug。衝突したら後の対象に連番を付ける */
function assignIds(targets) {
  const used = new Set();
  return targets.map((t) => {
    const base = `${t.app}__${slug(t.route)}`;
    let id = base;
    for (let n = 2; used.has(id); n++) id = `${base}-${n}`;
    used.add(id);
    return { id, ...t };
  });
}

function readJson(p, fallback) {
  return existsSync(p) ? JSON.parse(readFileSync(p, "utf8")) : fallback;
}
function writeJson(p, data) {
  writeFileSync(p, `${JSON.stringify(data, null, 2)}\n`);
}

// ---------------------------------------------------------------------------
// commands
// ---------------------------------------------------------------------------
function cmdPlan(opts) {
  const baseRef = resolveBaseRef(opts.base);
  const { mergeBase, files } = changedFiles(baseRef);
  const targets = expandTargets(deriveTargets(files));
  const plan = {
    branch: currentBranch(),
    base: baseRef,
    mergeBase,
    generatedAt: new Date().toISOString(),
    changedScreenFiles: files.filter((f) => SCREEN_FILE_RE.test(f)),
    targets,
  };
  const dir = workDir();
  writeJson(join(dir, "plan.json"), plan);
  if (opts.json) {
    console.log(JSON.stringify(plan, null, 2));
    return;
  }
  if (targets.length === 0) {
    console.log("NO_SCREENS: 画面に影響する変更はありません(スクリーンショット不要)");
    return;
  }
  console.log(`plan: ${targets.length} target(s)  base=${baseRef}  -> ${join(dir, "plan.json")}`);
  for (const t of targets) {
    const status = t.needsParams
      ? `NEEDS_PARAMS(apps/${t.app}/screenshots.config.json の routeParams["${t.route}"] にサンプル URL パスを登録)`
      : t.url;
    console.log(
      `  - ${t.id}\n      app=${t.app} route=${t.route}\n      url=${status}\n      why=${t.reasons.join(", ")}`,
    );
  }
}

function waitForHttp(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolveP, reject) => {
    const tick = async () => {
      try {
        const res = await fetch(url, { redirect: "manual" });
        if (res.status < 500) return resolveP();
      } catch {}
      if (Date.now() > deadline) return reject(new Error(`timeout waiting for ${url}`));
      setTimeout(tick, 1000);
    };
    tick();
  });
}

async function cmdBaselineStart() {
  const dir = workDir();
  const plan = readJson(join(dir, "plan.json"), null);
  if (!plan) throw new Error("plan.json がありません。先に `plan` を実行してください");
  const apps = [...new Set(plan.targets.map((t) => t.app))];
  if (apps.length === 0) {
    console.log("NO_SCREENS: baseline は不要です");
    return;
  }
  if (!existsSync(BASELINE_WORKTREE)) {
    mkdirSync(dirname(BASELINE_WORKTREE), { recursive: true });
    git("worktree", "add", "--detach", BASELINE_WORKTREE, plan.mergeBase);
  } else {
    execFileSync("git", ["checkout", "--detach", plan.mergeBase], {
      cwd: BASELINE_WORKTREE,
      stdio: "inherit",
    });
  }
  // 依存は store からのハードリンクなので二重ダウンロードにはならない
  execFileSync("pnpm", ["install", "--frozen-lockfile", "--prefer-offline"], {
    cwd: BASELINE_WORKTREE,
    stdio: "inherit",
    env: { ...process.env, CI: "1" },
  });
  const state = readJson(join(dir, "baseline.json"), { servers: [] });
  for (const app of apps) {
    const port = (plan.targets.find((t) => t.app === app)?.port ?? 3000) + BASELINE_PORT_OFFSET;
    if (state.servers.some((s) => s.app === app && isAlive(s.pid))) {
      console.log(`baseline ${app}: already running on :${port}`);
      continue;
    }
    const logPath = join(dir, `baseline-${app}.log`);
    const out = openLog(logPath);
    // メモリ節約のため 1 アプリずつ順に起動する(M1 16GB 想定)
    const child = spawn(
      "pnpm",
      ["--filter", `@jcredit/${app}`, "exec", "next", "dev", "--turbopack", "-p", String(port)],
      {
        cwd: BASELINE_WORKTREE,
        detached: true,
        stdio: ["ignore", out, out],
        env: { ...process.env, PORT: String(port) },
      },
    );
    child.unref();
    state.servers = state.servers.filter((s) => s.app !== app);
    state.servers.push({ app, port, pid: child.pid, log: logPath });
    writeJson(join(dir, "baseline.json"), state);
    process.stdout.write(`baseline ${app}: starting on :${port} (pid ${child.pid}) ...`);
    await waitForHttp(`http://localhost:${port}/`, 180_000);
    console.log(" ready");
  }
  console.log("\nbaseline URLs:");
  for (const t of plan.targets) {
    if (!t.url) continue;
    console.log(`  ${t.id}: ${t.url.replace(`:${t.port}`, `:${t.port + BASELINE_PORT_OFFSET}`)}`);
  }
}

function openLog(path) {
  return openSync(path, "a");
}
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function cmdBaselineStop() {
  const dir = workDir();
  const state = readJson(join(dir, "baseline.json"), { servers: [] });
  for (const s of state.servers) {
    try {
      process.kill(-s.pid, "SIGTERM");
    } catch {
      try {
        process.kill(s.pid, "SIGTERM");
      } catch {}
    }
    console.log(`baseline ${s.app}: stopped (pid ${s.pid})`);
  }
  writeJson(join(dir, "baseline.json"), { servers: [] });
  if (existsSync(BASELINE_WORKTREE)) {
    git("worktree", "remove", "--force", BASELINE_WORKTREE);
    console.log("baseline worktree removed");
  }
}

function cmdAdd(opts) {
  const phase = opts.phase;
  const target = opts.target;
  const file = opts._[0];
  if (!["before", "after"].includes(phase) || !target || !file) {
    throw new Error("usage: add --phase before|after --target <id> <image>");
  }
  const dir = workDir();
  const plan = readJson(join(dir, "plan.json"), null);
  if (!plan) throw new Error("plan.json がありません。先に `plan` を実行してください");
  if (!plan.targets.some((t) => t.id === target)) {
    throw new Error(
      `unknown target: ${target}\nknown: ${plan.targets.map((t) => t.id).join(", ")}`,
    );
  }
  // Claude in Chrome の保存形式(jpg / png)をそのまま保持する。同じ target の旧ファイルは消す
  const ext = imageExt(file);
  mkdirSync(join(dir, phase), { recursive: true });
  for (const old of findImages(join(dir, phase), target)) rmSync(old);
  const dest = join(dir, phase, `${target}.${ext}`);
  copyFileSync(resolve(file), dest);
  console.log(`added ${phase}/${target}.${ext}`);
}

const IMAGE_EXTS = ["png", "jpg", "jpeg", "webp"];
function imageExt(file) {
  const ext = (file.split(".").pop() ?? "").toLowerCase();
  if (!IMAGE_EXTS.includes(ext)) {
    throw new Error(`unsupported image: ${file}(${IMAGE_EXTS.join(" / ")} のみ)`);
  }
  return ext === "jpeg" ? "jpg" : ext;
}
/** `<dir>/<target>.<ext>` を拡張子違いも含めて探す */
function findImages(dir, target) {
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => IMAGE_EXTS.some((e) => f === `${target}.${e}`))
    .map((f) => join(dir, f));
}

function collect(dir, plan) {
  return plan.targets.map((t) => ({
    ...t,
    before: findImages(join(dir, "before"), t.id)[0] ?? null,
    after: findImages(join(dir, "after"), t.id)[0] ?? null,
  }));
}

function cmdStatus() {
  const dir = workDir();
  const plan = readJson(join(dir, "plan.json"), null);
  if (!plan) throw new Error("plan.json がありません。先に `plan` を実行してください");
  const rows = collect(dir, plan);
  let missing = 0;
  for (const r of rows) {
    const b = r.before ? "✓" : "✗";
    const a = r.after ? "✓" : "✗";
    if (!r.before || !r.after) missing++;
    console.log(`${b} before  ${a} after   ${r.id}  (${r.app} ${r.route})`);
  }
  console.log(missing === 0 ? "\nALL_CAPTURED" : `\nMISSING: ${missing} target(s)`);
  process.exitCode = missing === 0 ? 0 : 1;
}

function cmdUpload() {
  const dir = workDir();
  const plan = readJson(join(dir, "plan.json"), null);
  if (!plan) throw new Error("plan.json がありません。先に `plan` を実行してください");
  const rows = collect(dir, plan);
  const missing = rows.filter((r) => !r.before || !r.after);
  if (missing.length > 0) {
    throw new Error(`未撮影の target があります: ${missing.map((m) => m.id).join(", ")}`);
  }
  if (!releaseExists(RELEASE_TAG)) {
    gh(
      "release",
      "create",
      RELEASE_TAG,
      "--title",
      "Screenshots Bucket",
      "--notes",
      "PR レビュー用スクリーンショット置き場(自動運用)。直接編集しないでください。",
      "--prerelease",
    );
  }
  const repo = gh("repo", "view", "--json", "nameWithOwner", "-q", ".nameWithOwner");
  const baseUrl = `https://github.com/${repo}/releases/download/${RELEASE_TAG}`;
  const sha = git("rev-parse", "--short", "HEAD");
  const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
  const manifest = { branch: plan.branch, uploadedAt: new Date().toISOString(), items: [] };
  const tmp = join(dir, "upload-tmp");
  mkdirSync(tmp, { recursive: true });
  for (const r of rows) {
    const item = { id: r.id, app: r.app, route: r.route };
    for (const phase of ["before", "after"]) {
      const remoteName = `${stamp}-${sha}-${r.id}-${phase}.${imageExt(r[phase])}`;
      const tmpPath = join(tmp, remoteName);
      copyFileSync(r[phase], tmpPath);
      gh("release", "upload", RELEASE_TAG, tmpPath, "--clobber");
      item[phase] = `${baseUrl}/${remoteName}`;
      console.log(`uploaded ${remoteName}`);
    }
    manifest.items.push(item);
  }
  writeJson(join(dir, "manifest.json"), manifest);
  const section = renderSection(manifest);
  writeFileSync(join(dir, "SECTION.md"), section);
  console.log(`\n--- PR 本文に貼るセクション (${join(dir, "SECTION.md")}) ---\n`);
  console.log(section);
}

/**
 * Release の有無。「無い」以外の失敗(認証切れ・ネットワーク断など)は握りつぶさず throw する —
 * 黙って `release create` に進むと、本当の原因が後続のエラーに隠れて切り分けが遠回りになるため。
 */
function releaseExists(tag) {
  try {
    gh("release", "view", tag);
    return true;
  } catch (err) {
    if (/not found/i.test(err.stderr ?? "")) return false;
    throw err;
  }
}

function renderSection(manifest) {
  const lines = [
    "## Screenshots",
    "",
    "| Screen | Before | After |",
    "|--------|--------|-------|",
  ];
  for (const it of manifest.items) {
    lines.push(
      `| ${it.app} \`${it.route}\` | ![before ${it.id}](${it.before}) | ![after ${it.id}](${it.after}) |`,
    );
  }
  lines.push("");
  return lines.join("\n");
}

function cmdSection() {
  const dir = workDir();
  const manifest = readJson(join(dir, "manifest.json"), null);
  if (!manifest) throw new Error("manifest.json がありません。先に `upload` を実行してください");
  process.stdout.write(renderSection(manifest));
}

/**
 * PR 本文の検証。画面に影響する変更があるなら、`## Screenshots` セクションに
 * 各 target(app + route)の Before / After 画像が揃っていることを要求する。
 * 終了コード 0 = OK / 1 = NG(理由を stdout に出す)。
 */
function cmdCheck(opts) {
  let body = "";
  if (opts["body-file"]) body = readFileSync(resolve(opts["body-file"]), "utf8");
  else if (typeof opts.body === "string") body = opts.body;
  else if (opts.stdin) body = readFileSync(0, "utf8");

  let files;
  if (opts["files-from"]) {
    files = readFileSync(resolve(opts["files-from"]), "utf8")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  } else {
    files = changedFiles(resolveBaseRef(opts.base)).files;
  }
  const targets = expandTargets(deriveTargets(files));
  if (targets.length === 0) {
    console.log("OK: 画面に影響する変更はありません(スクリーンショット不要)");
    return;
  }
  const problems = [];
  // 次の `## ` 見出しか文字列末尾までをセクションとする(JS の正規表現に \Z は無い)
  const sectionMatch = /^##\s+Screenshots\s*$([\s\S]*?)(?=^##\s|(?![\s\S]))/m.exec(`${body}\n`);
  const section = sectionMatch ? sectionMatch[1] : null;
  if (!section) {
    problems.push("PR 本文に `## Screenshots` セクションがありません");
  } else {
    const rows = section
      .split("\n")
      .filter((l) => l.trim().startsWith("|"))
      .map((l) => l.split("|").map((c) => c.trim()));
    const img = /!\[[^\]]*\]\((https?:\/\/[^)\s]+)\)/;
    for (const t of targets) {
      const row = rows.find((cells) =>
        cells.some((c) => c.includes(t.app) && c.includes(`\`${t.route}\``)),
      );
      if (!row) {
        problems.push(`${t.app} \`${t.route}\` の行がありません`);
        continue;
      }
      const images = row.filter((c) => img.test(c));
      if (images.length < 2) {
        problems.push(
          `${t.app} \`${t.route}\`: Before / After の両方の画像が必要です(検出 ${images.length})`,
        );
      }
    }
  }
  if (problems.length === 0) {
    console.log(`OK: ${targets.length} 画面すべてに Before / After があります`);
    return;
  }
  console.log("NG: 画面の変更に対してスクリーンショットが不足しています");
  for (const p of problems) console.log(`  - ${p}`);
  console.log("\n対象:");
  for (const t of targets) console.log(`  - ${t.app} ${t.route}  (${t.reasons.join(", ")})`);
  console.log(
    "\n手順: Claude Code で `/pr-screenshots` を実行し、生成された `## Screenshots` セクションを PR 本文に含める",
  );
  process.exitCode = 1;
}

function cmdTargets(opts) {
  // CI 等でルート導出だけしたいとき(plan と違い作業ディレクトリに書かない)
  const files = opts["files-from"]
    ? readFileSync(resolve(opts["files-from"]), "utf8")
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean)
    : changedFiles(resolveBaseRef(opts.base)).files;
  console.log(JSON.stringify(expandTargets(deriveTargets(files)), null, 2));
}

const USAGE = `usage: node scripts/screenshots/cli.mjs <command>

  plan [--base develop] [--json]    変更ファイルから撮影対象を導き .screenshots/<branch>/plan.json に書く
  baseline start                    base 断面の worktree を作り、対象アプリの dev サーバをポート+1000 で起動
  baseline stop                     baseline サーバを止め worktree を削除
  add --phase before|after --target <id> <image>
                                    撮影した画像(jpg / png)を取り込む
  status                            before / after の揃い具合(全部揃えば exit 0)
  upload                            GitHub Release(${RELEASE_TAG})へ upload し、PR 本文セクションを生成
  section                           生成済みセクション(SECTION.md)を出力
  check [--body-file f | --body s | --stdin] [--base develop] [--files-from f]
                                    PR 本文を検証(フック / CI 用。NG なら exit 1)
  targets [--base develop] [--files-from f]
                                    撮影対象を JSON で出力(作業ディレクトリに書かない)
`;

async function main() {
  const [cmd, ...rest] = process.argv.slice(2);
  const opts = parseArgs(rest);
  switch (cmd) {
    case "plan":
      return cmdPlan(opts);
    case "baseline":
      if (opts._[0] === "start") return cmdBaselineStart();
      if (opts._[0] === "stop") return cmdBaselineStop();
      throw new Error("usage: baseline start|stop");
    case "add":
      return cmdAdd(opts);
    case "status":
      return cmdStatus();
    case "upload":
      return cmdUpload();
    case "section":
      return cmdSection();
    case "check":
      return cmdCheck(opts);
    case "targets":
      return cmdTargets(opts);
    case "pr-command": {
      const cmd = opts.stdin ? readFileSync(0, "utf8") : (opts._[0] ?? "");
      console.log(JSON.stringify(parsePrCommand(cmd)));
      return;
    }
    default:
      process.stdout.write(USAGE);
      process.exitCode = cmd ? 1 : 0;
  }
}

main().catch((err) => {
  console.error(`error: ${err.message}`);
  process.exitCode = 1;
});
