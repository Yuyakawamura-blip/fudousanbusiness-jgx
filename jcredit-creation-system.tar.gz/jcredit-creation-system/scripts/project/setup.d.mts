/** setup.mjs の公開シグネチャ。テストから型付きで import するためだけに置く(実装は .mjs) */
export interface SingleSelectOption {
  name: string;
  color: string;
  description: string;
}

export interface BoardField {
  name: string;
  dataType: "NUMBER" | "SINGLE_SELECT";
  options?: SingleSelectOption[];
}

export interface Board {
  title: string;
  shortDescription: string;
  sprint: { name: string; durationDays: number; initialCount: number };
  fields: BoardField[];
}

export interface Iteration {
  title: string;
  startDate: string;
  duration: number;
}

export declare const BOARD: Board;
export declare const nextMonday: (from: Date) => string;
export declare const buildIterations: (
  startDate: string,
  durationDays: number,
  count: number,
) => Iteration[];
