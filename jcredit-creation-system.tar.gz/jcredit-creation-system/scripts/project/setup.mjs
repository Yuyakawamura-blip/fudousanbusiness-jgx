#!/usr/bin/env node
/**
 * GitHub Project(ボード)のフィールドを冪等に作る CLI。手順と定義は docs/project-board.md、値の正は BOARD。
 * 依存ゼロ(node 組み込みのみ)。gh は子プロセスで呼ぶ。
 */
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ORG = "japan-gx-group";
const REPO = "jcredit-creation-system";

export const BOARD = {
  title: "J-Credit 創出システム",
  shortDescription:
    "機能 / Phase / 工程で分けて、スプリントで回すボード。運用は docs/project-board.md",
  sprint: {
    name: "Sprint",
    // 2 週間 — 1 週間だとレビュー・promotion の往復が収まらず、3 週間以上だと見積の誤差が大きい
    durationDays: 14,
    // 先の分を作りすぎると空の Sprint が並ぶ。足りなくなれば UI が自動で次を足す
    initialCount: 3,
  },
  fields: [
    {
      name: "Storypoint",
      dataType: "NUMBER",
      // Number 型はフィボナッチを強制できないが、Insights / group-by で合計が出るので single-select にしない
    },
    {
      name: "Size",
      dataType: "SINGLE_SELECT",
      options: [
        { name: "S", color: "GREEN", description: "半日以内" },
        { name: "M", color: "YELLOW", description: "1〜2 日" },
        { name: "L", color: "ORANGE", description: "3〜5 日" },
        { name: "XL", color: "RED", description: "6 日以上。分割する" },
      ],
    },
    {
      name: "Priority",
      dataType: "SINGLE_SELECT",
      options: [
        { name: "High", color: "RED", description: "今スプリントで終える" },
        { name: "Medium", color: "YELLOW", description: "次スプリントまで" },
        { name: "Low", color: "GRAY", description: "空いたら" },
      ],
    },
    { name: "Start", dataType: "DATE" },
    { name: "end", dataType: "DATE" },
    {
      name: "機能",
      dataType: "SINGLE_SELECT",
      options: [
        { name: "全体", color: "GRAY", description: "アプリをまたぐ設計・作業" },
        { name: "会員マイページ", color: "BLUE", description: "" },
        { name: "創出PTマイページ", color: "GREEN", description: "" },
        { name: "運営者コンソール", color: "PURPLE", description: "" },
        { name: "API", color: "ORANGE", description: "" },
        { name: "DB", color: "YELLOW", description: "" },
        { name: "dev環境構築", color: "GRAY", description: "" },
        { name: "stg環境構築", color: "GRAY", description: "" },
        { name: "本番環境構築", color: "GRAY", description: "" },
        { name: "テスト計画", color: "PINK", description: "" },
        { name: "脆弱性診断準備", color: "RED", description: "" },
        { name: "総合テスト", color: "PINK", description: "" },
        { name: "UAT", color: "PINK", description: "" },
      ],
    },
    {
      name: "Phase",
      dataType: "SINGLE_SELECT",
      options: [
        { name: "Phase1", color: "BLUE", description: "" },
        { name: "Phase2", color: "GREEN", description: "" },
        { name: "Phase3", color: "PURPLE", description: "" },
      ],
    },
    {
      name: "工程",
      dataType: "SINGLE_SELECT",
      options: [
        { name: "基本設計", color: "BLUE", description: "" },
        { name: "画面設計", color: "GREEN", description: "" },
        { name: "詳細設計", color: "PURPLE", description: "" },
        { name: "開発", color: "ORANGE", description: "" },
        { name: "フロントエンド開発", color: "ORANGE", description: "" },
        { name: "バックエンド開発", color: "RED", description: "" },
        { name: "内部結合テスト", color: "PINK", description: "" },
        { name: "テスト", color: "PINK", description: "" },
      ],
    },
  ],
};

/** 「今日」は Asia/Tokyo で判定する。UTC だと JST の朝 9 時前に実行したとき前日扱いになる */
const todayInTokyo = (from) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(from);

/** 次の月曜(今日が月曜なら今日)。スプリントは月曜始まりに固定する */
export const nextMonday = (from) => {
  const d = new Date(`${todayInTokyo(from)}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + ((8 - d.getUTCDay()) % 7));
  return d.toISOString().slice(0, 10);
};

export const buildIterations = (startDate, durationDays, count) =>
  Array.from({ length: count }, (_, i) => {
    const d = new Date(`${startDate}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + i * durationDays);
    return {
      title: `Sprint ${i + 1}`,
      startDate: d.toISOString().slice(0, 10),
      duration: durationDays,
    };
  });

const parseArgs = (argv) => {
  const opts = { dryRun: false, sprintStart: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--dry-run") opts.dryRun = true;
    else if (a === "--sprint-start") opts.sprintStart = argv[++i];
    else throw new Error(`unknown option: ${a}`);
  }
  if (opts.sprintStart && !/^\d{4}-\d{2}-\d{2}$/.test(opts.sprintStart)) {
    throw new Error("--sprint-start は YYYY-MM-DD");
  }
  return opts;
};

/** gh CLI の唯一の呼び出し口。失敗時は stderr を含む Error を throw する */
const gh = (...args) => {
  try {
    return execFileSync("gh", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
  } catch (e) {
    throw new Error(`gh ${args.slice(0, 2).join(" ")} failed: ${e.stderr?.trim() || e.message}`);
  }
};

/** query も mutation も --input(JSON body)で送る。-F はネストした input を扱えない */
const graphql = (query, variables = {}) => {
  const body = JSON.stringify({ query, variables });
  try {
    const out = execFileSync("gh", ["api", "graphql", "--input", "-"], {
      input: body,
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
    });
    const json = JSON.parse(out);
    if (json.errors) throw new Error(json.errors.map((e) => e.message).join("; "));
    return json.data;
  } catch (e) {
    throw new Error(`graphql failed: ${e.stderr?.trim() || e.message}`);
  }
};

const log = (msg) => console.log(msg);

const ensureScopes = () => {
  const headers = gh("api", "-i", "/user");
  const line = headers.split("\n").find((l) => /^x-oauth-scopes:/i.test(l)) ?? "";
  const scopes = line
    .replace(/^[^:]+:/, "")
    .split(",")
    .map((s) => s.trim());
  if (!scopes.includes("project")) {
    throw new Error(
      "gh のトークンに project スコープが無い。`gh auth refresh -h github.com -s project` を実行してから再実行する",
    );
  }
  return scopes;
};

const findProject = () => {
  const data = graphql(
    `query($org: String!) { organization(login: $org) { projectsV2(first: 50, query: "is:open") { nodes { id number title url } } } }`,
    { org: ORG },
  );
  return data.organization.projectsV2.nodes.find((p) => p.title === BOARD.title) ?? null;
};

const ensureProject = (orgId, dry) => {
  const found = findProject();
  if (found) {
    log(`  = project #${found.number} ${found.url}(既存)`);
    return found;
  }
  log(`  + project ${BOARD.title}`);
  if (dry) return null;
  const data = graphql(
    `mutation($input: CreateProjectV2Input!) { createProjectV2(input: $input) { projectV2 { id number url } } }`,
    { input: { ownerId: orgId, title: BOARD.title } },
  );
  const p = data.createProjectV2.projectV2;
  graphql(
    `mutation($input: UpdateProjectV2Input!) { updateProjectV2(input: $input) { projectV2 { id } } }`,
    // public は触らない(既定で private。org のポリシーで visibility 変更が拒否されることがある)
    { input: { projectId: p.id, shortDescription: BOARD.shortDescription } },
  );
  log(`    ${p.url}`);
  return p;
};

const listFields = (projectId) =>
  graphql(
    `query($id: ID!) { node(id: $id) { ... on ProjectV2 { fields(first: 50) { nodes { ... on ProjectV2FieldCommon { name dataType } } } } } }`,
    { id: projectId },
  ).node.fields.nodes.map((f) => f.name);

const ensureFields = (project, sprintStart, dry) => {
  const existing = project ? listFields(project.id) : [];
  const create = (input) =>
    graphql(
      `mutation($input: CreateProjectV2FieldInput!) { createProjectV2Field(input: $input) { projectV2Field { ... on ProjectV2FieldCommon { id } } } }`,
      { input: { projectId: project.id, ...input } },
    );

  const { sprint } = BOARD;
  if (existing.includes(sprint.name)) {
    log(`  = field ${sprint.name}(既存)`);
  } else {
    const iterations = buildIterations(sprintStart, sprint.durationDays, sprint.initialCount);
    log(
      `  + field ${sprint.name}(ITERATION, ${sprintStart} から ${sprint.durationDays} 日 × ${sprint.initialCount})`,
    );
    if (!dry) {
      create({
        name: sprint.name,
        dataType: "ITERATION",
        iterationConfiguration: {
          startDate: sprintStart,
          duration: sprint.durationDays,
          iterations,
        },
      });
    }
  }

  for (const f of BOARD.fields) {
    if (existing.includes(f.name)) {
      log(`  = field ${f.name}(既存。選択肢は触らない)`);
      continue;
    }
    log(
      `  + field ${f.name}(${f.dataType}${f.options ? `: ${f.options.map((o) => o.name).join(" / ")}` : ""})`,
    );
    if (dry) continue;
    create({
      name: f.name,
      dataType: f.dataType,
      ...(f.options ? { singleSelectOptions: f.options } : {}),
    });
  }
};

const ensureRepoLink = (project, dry) => {
  const repoId = graphql(
    `query($org: String!, $repo: String!) { repository(owner: $org, name: $repo) { id } }`,
    { org: ORG, repo: REPO },
  ).repository.id;
  const linked = project
    ? graphql(
        `query($id: ID!) { node(id: $id) { ... on ProjectV2 { repositories(first: 20) { nodes { nameWithOwner } } } } }`,
        { id: project.id },
      ).node.repositories.nodes.some((r) => r.nameWithOwner === `${ORG}/${REPO}`)
    : false;
  if (linked) {
    log(`  = link ${ORG}/${REPO}(既存)`);
    return;
  }
  log(`  + link ${ORG}/${REPO}`);
  if (dry) return;
  graphql(
    `mutation($input: LinkProjectV2ToRepositoryInput!) { linkProjectV2ToRepository(input: $input) { repository { id } } }`,
    { input: { projectId: project.id, repositoryId: repoId } },
  );
};

const printManualSteps = (project) => {
  const base = project?.url ?? `https://github.com/orgs/${ORG}/projects/<number>`;
  log(`
残りは UI で行う(API が無い):
  1. ${base}/workflows — 組み込み workflow を ON にする
     - Auto-add to project(対象: このリポジトリ、is:issue is:open)
     - Item closed → Status: Done
     - Pull request merged → Status: Done
     - Auto-archive items(is:closed updated:<2w)
  2. ${base}/views — ビューを作る(docs/project-board.md「ビュー」)
  3. Sprint の開始日をずらしたければフィールド設定から変更する(このスクリプトは既存フィールドを変更しない)
`);
};

const main = () => {
  const opts = parseArgs(process.argv.slice(2));
  const sprintStart = opts.sprintStart ?? nextMonday(new Date());
  if (opts.dryRun) log("(dry-run: 変更しない)");
  ensureScopes();
  const orgId = graphql(`query($org: String!) { organization(login: $org) { id } }`, { org: ORG })
    .organization.id;

  log("Project");
  const project = ensureProject(orgId, opts.dryRun);
  log("Fields");
  if (project) ensureFields(project, sprintStart, opts.dryRun);
  else
    log(
      `  (dry-run: Project 作成後に ${BOARD.sprint.name} / ${BOARD.fields.map((f) => f.name).join(" / ")} を作る)`,
    );
  log("Repository");
  ensureRepoLink(project, opts.dryRun);
  printManualSteps(project);
};

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    main();
  } catch (e) {
    console.error(`error: ${e.message}`);
    process.exit(1);
  }
}
