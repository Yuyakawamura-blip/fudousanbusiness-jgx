/** frames.mjs の公開シグネチャ。テストから型付きで import するためだけに置く(実装は .mjs) */
export interface ScreenFrame {
  id: string;
  name: string;
  width: number;
  height: number;
}
export function extractXml(raw: string): string;
export function listFrames(
  xml: string,
): { section: { tag: string; id: string; name: string } | null; frames: ScreenFrame[] }[];
