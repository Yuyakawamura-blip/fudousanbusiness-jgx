#!/usr/bin/env node
/**
 * Figma MCP の get_metadata の結果(ページ全体の XML)から、セクションと画面のフレームだけを一覧にする CLI。
 * 画面設計で「どのフレームがその機能の画面・状態か」を漏れなく洗い出すために使う。依存ゼロ。手順は /add-screen-design。
 *
 *   node scripts/figma/frames.mjs <get_metadata の結果を保存したファイル> [--grep 語,語] [--url <Figma ファイルの URL>]
 *
 * 結果が大きいと MCP がファイルに保存する(JSON 配列 [{type, text}])。XML をそのまま保存したファイルも読める。
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

// 画面のフレームとみなす最小の幅。部品(ヘッダー・吹き出し等)を一覧から外すため。デスクトップ幅 1440px の画面だけを撮る
const MIN_SCREEN_WIDTH = 1000;

/** 保存されたファイルの中身から XML の部分を取り出す */
export const extractXml = (raw) => {
  let text = raw;
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) text = parsed.map((p) => p?.text ?? "").join("\n");
  } catch {
    // JSON でなければ XML そのものとして読む
  }
  const start = text.search(/<(canvas|section|frame)\s/);
  return start < 0 ? "" : text.slice(start);
};

const attr = (tag, name) => tag.match(new RegExp(`\\s${name}="([^"]*)"`))?.[1] ?? "";

/**
 * セクションと、その中の画面フレームを返す。グループや幅の狭いフレームで包まれていても拾う。
 * 画面フレームの中の幅の広いフレーム(本文・ヘッダー等)は画面の部品なので外す。
 * セクションに入っていない画面フレームは section: null で返す
 */
export const listFrames = (xml) => {
  const result = [];
  const stack = [];
  // 属性の値は引用符の中に ">" を含みうる(レイヤー名 "Step 1 > 2" 等)ので、引用符の中を飛ばしてタグの終わりを探す
  for (const m of xml.matchAll(/<(\/?)([a-z-]+)((?:\s+[^\s=/>]+="[^"]*")*)\s*(\/?)>/g)) {
    const [, closing, tag, attrs, selfClosing] = m;
    if (closing) {
      stack.pop();
      continue;
    }
    const node = { tag, id: attr(attrs, "id"), name: attr(attrs, "name"), isScreen: false };
    if (tag === "section") {
      result.push({ section: { tag, id: node.id, name: node.name }, frames: [] });
    } else if (
      tag === "frame" &&
      Number(attr(attrs, "width")) >= MIN_SCREEN_WIDTH &&
      !stack.some((a) => a.isScreen)
    ) {
      node.isScreen = true;
      const frame = {
        id: node.id,
        name: node.name,
        width: Number(attr(attrs, "width")),
        height: Number(attr(attrs, "height")),
      };
      const section = stack.findLast((a) => a.tag === "section");
      if (section) result.findLast((r) => r.section?.id === section.id)?.frames.push(frame);
      else result.push({ section: null, frames: [frame] });
    }
    if (!selfClosing) stack.push(node);
  }
  return result;
};

const nodeUrl = (base, id) => `${base.split("?")[0]}?node-id=${id.replace(":", "-")}`;

const main = (argv) => {
  const [file, ...rest] = argv;
  if (!file)
    throw new Error(
      "使い方: frames.mjs <get_metadata の結果のファイル> [--grep 語,語] [--url <Figma の URL>]",
    );
  let grep = [];
  let url = "";
  for (let i = 0; i < rest.length; i += 2) {
    if (rest[i] === "--grep") grep = (rest[i + 1] ?? "").split(",").filter(Boolean);
    else if (rest[i] === "--url") url = rest[i + 1] ?? "";
    else throw new Error(`不明なオプション: ${rest[i]}`);
  }
  const xml = extractXml(readFileSync(file, "utf8"));
  if (!xml) throw new Error("get_metadata の XML が見つからない(ページの id を渡して取り直す)");
  for (const { section, frames } of listFrames(xml)) {
    const sectionHit = section && grep.some((g) => section.name.includes(g));
    const shown =
      grep.length === 0 || sectionHit
        ? frames
        : frames.filter((f) => grep.some((g) => f.name.includes(g)));
    if (shown.length === 0) continue;
    console.log(section ? `## ${section.name}(${section.id})` : "## (セクション外)");
    for (const f of shown) {
      console.log(
        `- ${f.id}  ${f.name}  [${f.width}×${f.height}、長辺 ${Math.max(f.width, f.height)}]${url ? `  ${nodeUrl(url, f.id)}` : ""}`,
      );
    }
  }
};

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try {
    main(process.argv.slice(2));
  } catch (e) {
    console.error(e instanceof Error ? e.message : e);
    process.exit(1);
  }
}
