/** DB 設計書の生成ブロックの描画と差し替え。drizzle に依存しない純粋関数だけを置く(drizzle からの変換は build.mjs) */

const START = /<!-- generated:start table=([a-z0-9_]+) -->/g;
const END = "<!-- generated:end -->";

const cell = (value) => String(value ?? "").replaceAll("|", "\\|");

const row = (values) => `|${values.map((v) => (cell(v) === "" ? " " : ` ${cell(v)} `)).join("|")}|`;

const headerLines = (labels) => [
  `| ${labels.join(" | ")} |`,
  `|${labels.map(() => " --- ").join("|")}|`,
];

const [LOGICAL_HEADER, LOGICAL_SEPARATOR] = headerLines([
  "論理名",
  "カラム",
  "型",
  "NULL",
  "既定値",
  "制約",
]);

// cell() が | を \| にエスケープして書くので、読むときは \| を区切りとみなさず | に戻す
const splitRow = (line) =>
  line
    .slice(1, -1)
    .split(/(?<!\\)\|/)
    .map((v) => v.trim().replaceAll("\\|", "|"));

export function renderTable(table, logicalNames = new Map()) {
  const lines = [
    LOGICAL_HEADER,
    LOGICAL_SEPARATOR,
    ...table.columns.map((c) =>
      row([
        logicalNames.get(c.name),
        c.name,
        c.type,
        c.notNull ? "NOT NULL" : "NULL",
        c.default,
        c.constraint,
      ]),
    ),
  ];
  if (table.constraints.length > 0) {
    lines.push(
      "",
      ...headerLines(["名前", "種別", "カラム", "定義"]),
      ...table.constraints.map((c) => row([c.name, c.kind, c.columns.join(", "), c.definition])),
    );
  }
  return lines.join("\n");
}

/**
 * 論理名は schema に持たない(ADR-0004)ので、この列だけは設計書に手で書いたものを正として作り直しても残す。
 * 見出し行が見つからなければ null(見出しを手で崩すと論理名を 1 つも拾えないため、呼び出し側で区別する)
 */
export function readLogicalNames(body) {
  const lines = body.split("\n");
  const header = lines.indexOf(LOGICAL_HEADER);
  if (header === -1) return null;
  const names = new Map();
  for (const line of lines.slice(header + 2)) {
    if (!line.startsWith("|")) break;
    const [logicalName, column] = splitRow(line);
    if (logicalName) names.set(column, logicalName);
  }
  return names;
}

/**
 * markdown の生成ブロックを tables の内容で差し替える。
 * ブロックが無いテーブル・テーブルが無いブロックは errors に積む(どちらも手で直す必要がある)。
 */
export function replaceBlocks(markdown, tables) {
  const byName = new Map(tables.map((t) => [t.name, t]));
  const seen = new Set();
  const errors = [];
  let out = "";
  let cursor = 0;
  for (const match of markdown.matchAll(START)) {
    const name = match[1];
    const bodyStart = match.index + match[0].length;
    const endAt = markdown.indexOf(END, bodyStart);
    const nextStart = markdown.indexOf("<!-- generated:start", bodyStart);
    // 次のブロックの開始より後にある end は次のブロックのもの。拾うと次のブロックの開始マーカーごと上書きする
    if (endAt === -1 || (nextStart !== -1 && nextStart < endAt)) {
      errors.push(`table=${name} の ${END} がありません`);
      continue;
    }
    out += markdown.slice(cursor, bodyStart);
    const table = byName.get(name);
    if (table) {
      seen.add(name);
      const body = markdown.slice(bodyStart, endAt);
      const logicalNames = readLogicalNames(body);
      if (logicalNames === null && body.trim() !== "") {
        errors.push(`table=${name} のカラム表に見出し行「${LOGICAL_HEADER}」がありません`);
      } else {
        for (const c of table.columns) {
          if (!logicalNames?.has(c.name)) errors.push(`${name}.${c.name} の論理名がありません`);
        }
      }
      out += `\n${renderTable(table, logicalNames ?? new Map())}\n`;
    } else {
      errors.push(`table=${name} は schema にありません`);
      out += markdown.slice(bodyStart, endAt);
    }
    cursor = endAt;
  }
  out += markdown.slice(cursor);
  for (const t of tables) {
    if (!seen.has(t.name)) {
      errors.push(
        `${t.name} の生成ブロックがありません(<!-- generated:start table=${t.name} --> 〜 ${END} を置く)`,
      );
    }
  }
  return { markdown: out, errors };
}
