/** render.mjs の公開シグネチャ。テストから型付きで import するためだけに置く(実装は .mjs) */
export interface ColumnDoc {
  name: string;
  type: string;
  notNull: boolean;
  default: string;
  constraint: string;
}

export interface ConstraintDoc {
  name: string;
  kind: string;
  columns: string[];
  definition: string;
}

export interface TableDoc {
  name: string;
  columns: ColumnDoc[];
  constraints: ConstraintDoc[];
}

export function renderTable(table: TableDoc, logicalNames?: Map<string, string>): string;
export function readLogicalNames(body: string): Map<string, string> | null;
export function replaceBlocks(
  markdown: string,
  tables: TableDoc[],
): { markdown: string; errors: string[] };
