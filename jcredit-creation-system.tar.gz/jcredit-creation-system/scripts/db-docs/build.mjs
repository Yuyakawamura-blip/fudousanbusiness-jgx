/**
 * `pnpm db:docs [--check]`: packages/db/schema/<cluster>.ts から docs/design/detailed/db/<cluster>.md の生成ブロックを書き換える。
 * --check は書き換えずに、古いブロック・足りないブロックがあれば exit 1(CI 用)。
 */
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { basename, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { replaceBlocks } from "./render.mjs";

const root = fileURLToPath(new URL("../../", import.meta.url));
const schemaDir = join(root, "packages/db/schema");
const docsDir = join(root, "docs/design/detailed/db");

// drizzle-orm は @jcredit/db の依存で、このパッケージからは解決できない。schema と同じ drizzle を使うため db から解決する
const requireFromDb = createRequire(join(root, "packages/db/package.json"));
const { getTableConfig, PgDialect, PgTable } = requireFromDb("drizzle-orm/pg-core");
const { is, SQL } = requireFromDb("drizzle-orm");
const { toSnakeCase } = requireFromDb("drizzle-orm/casing");
const { newId } = await import(pathToFileURL(join(root, "packages/db/src/id.ts")).href);

const dialect = new PgDialect({ casing: "snake_case" });

const TYPE_ALIASES = { "timestamp with time zone": "timestamptz" };

const literal = (p) => (typeof p === "string" ? `'${p.replaceAll("'", "''")}'` : String(p));

function sqlText(tableName, value) {
  const { sql, params } = dialect.sqlToQuery(value);
  return sql
    .replace(/\$(\d+)/g, (_, n) => literal(params[Number(n) - 1]))
    .replaceAll(`"${tableName}".`, "")
    .replace(/"([a-z0-9_]+)"/g, "$1");
}

function defaultText(tableName, column) {
  if (column.defaultFn) return column.defaultFn === newId ? "(app: UUIDv7)" : "(app)";
  if (!column.hasDefault || column.default === undefined) return "";
  if (is(column.default, SQL)) return sqlText(tableName, column.default);
  return typeof column.default === "string" ? `'${column.default}'` : String(column.default);
}

function describeTable(table) {
  const config = getTableConfig(table);
  const name = config.name;
  const col = (c) => (c.keyAsName ? toSnakeCase(c.name) : c.name);
  const columns = config.columns.map((c) => ({
    name: col(c),
    type: TYPE_ALIASES[c.getSQLType()] ?? c.getSQLType(),
    notNull: c.notNull,
    default: defaultText(name, c),
    constraint: c.primary ? "PK" : c.isUnique ? "UNIQUE" : "",
  }));
  const constraints = [
    ...config.uniqueConstraints.map((u) => ({
      name: u.getName(),
      kind: "UNIQUE",
      columns: u.columns.map(col),
      definition: u.nullsNotDistinct ? "NULLS NOT DISTINCT" : "",
    })),
    ...config.indexes.map((i) => {
      const cols = i.config.columns.map((c) => (is(c, SQL) ? sqlText(name, c) : col(c)));
      return {
        name: i.config.name ?? `${name}_${cols.join("_")}_index`,
        kind: i.config.unique ? "UNIQUE INDEX" : "INDEX",
        columns: cols,
        definition: i.config.where ? `WHERE ${sqlText(name, i.config.where)}` : "",
      };
    }),
    ...config.checks.map((c) => ({
      name: c.name,
      kind: "CHECK",
      columns: [],
      definition: sqlText(name, c.value),
    })),
    ...config.foreignKeys.map((fk) => {
      const ref = fk.reference();
      const cols = ref.columns.map(col);
      const foreignTable = getTableConfig(ref.foreignTable).name;
      const foreignCols = ref.foreignColumns.map(col);
      return {
        // fk.getName() は casing を通さない camelCase の名前を返す。DB に付く名前は drizzle-kit が snake_case で組み立てる
        name: ref.name ?? `${name}_${cols.join("_")}_${foreignTable}_${foreignCols.join("_")}_fk`,
        kind: "FK",
        columns: cols,
        definition: `${foreignTable}(${foreignCols.join(", ")})`,
      };
    }),
  ];
  return { name, columns, constraints };
}

const check = process.argv.includes("--check");
const clusters = readdirSync(schemaDir)
  .filter((f) => f.endsWith(".ts") && !f.startsWith("_") && f !== "index.ts")
  .map((f) => basename(f, ".ts"));

const problems = [];
for (const cluster of clusters) {
  const mod = await import(pathToFileURL(join(schemaDir, `${cluster}.ts`)).href);
  const tables = Object.values(mod)
    .filter((v) => is(v, PgTable))
    .map(describeTable);
  const docPath = join(docsDir, `${cluster}.md`);
  let current;
  try {
    current = readFileSync(docPath, "utf8");
  } catch {
    problems.push(`${cluster}: ${docPath} がありません(_template.md から作る)`);
    continue;
  }
  const { markdown, errors } = replaceBlocks(current, tables);
  problems.push(...errors.map((e) => `${cluster}: ${e}`));
  if (markdown === current) continue;
  if (check) {
    problems.push(
      `${cluster}: 生成ブロックが schema と一致しません。pnpm db:docs で更新してください`,
    );
  } else {
    writeFileSync(docPath, markdown);
    console.log(`updated ${docPath}`);
  }
}

if (problems.length > 0) {
  for (const p of problems) console.error(p);
  process.exit(1);
}
