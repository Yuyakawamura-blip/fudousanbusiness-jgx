import { describe, expect, it } from "vitest";

import { readLogicalNames, renderTable, replaceBlocks, type TableDoc } from "../db-docs/render.mjs";

const logicalNames = new Map([
  ["id", "ID"],
  ["description", "説明"],
]);

const roles: TableDoc = {
  name: "roles",
  columns: [
    { name: "id", type: "text", notNull: true, default: "(app: UUIDv7)", constraint: "PK" },
    { name: "description", type: "text", notNull: false, default: "", constraint: "" },
  ],
  constraints: [
    {
      name: "roles_role_name_check",
      kind: "CHECK",
      columns: [],
      definition: "role_name in ('MANAGER', 'STAFF')",
    },
  ],
};

describe("renderTable", () => {
  it("_template.md の形式で、空のセルは「| |」にする", () => {
    expect(renderTable(roles, logicalNames)).toBe(
      [
        "| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |",
        "| --- | --- | --- | --- | --- | --- |",
        "| ID | id | text | NOT NULL | (app: UUIDv7) | PK |",
        "| 説明 | description | text | NULL | | |",
        "",
        "| 名前 | 種別 | カラム | 定義 |",
        "| --- | --- | --- | --- |",
        "| roles_role_name_check | CHECK | | role_name in ('MANAGER', 'STAFF') |",
      ].join("\n"),
    );
  });

  it("値の末尾の空白はそのまま残す", () => {
    const table = {
      ...roles,
      constraints: [{ name: "c", kind: "CHECK", columns: [], definition: "x  " }],
    };
    expect(renderTable(table)).toContain("| c | CHECK | | x   |");
  });

  it("制約が無ければ 2 つ目の表を出さない", () => {
    expect(renderTable({ ...roles, constraints: [] })).not.toContain("| 名前 |");
  });

  it("定義の | はエスケープする(表が崩れるため)", () => {
    const table = {
      ...roles,
      constraints: [{ name: "c", kind: "CHECK", columns: [], definition: "a || b" }],
    };
    expect(renderTable(table)).toContain("a \\|\\| b");
  });
});

describe("readLogicalNames", () => {
  it("カラム表の論理名をカラム名で引けるようにし、空の論理名は拾わない", () => {
    const body = `\n${renderTable(roles, new Map([["id", "ID"]]))}\n`;
    expect(readLogicalNames(body)).toEqual(new Map([["id", "ID"]]));
  });

  it("見出し行が見つからなければ null", () => {
    expect(readLogicalNames("| カラム | 型 | NULL | 既定値 | 制約 |\n")).toBeNull();
  });

  it("論理名の | はエスケープしたまま書き、読むときに戻す", () => {
    const names = new Map([
      ["id", "ID|識別子"],
      ["description", "説明"],
    ]);
    const body = renderTable(roles, names);
    expect(body).toContain("| ID\\|識別子 | id |");
    expect(readLogicalNames(body)).toEqual(names);
  });
});

describe("replaceBlocks", () => {
  const doc = (body: string) =>
    `# x\n\n手書き\n\n<!-- generated:start table=roles -->\n${body}<!-- generated:end -->\n\n末尾\n`;
  const current = `${renderTable(roles, logicalNames)}\n`;

  it("生成ブロックの中だけを書き換え、手書き部分と論理名は残す", () => {
    const stale = current.replace("| PK |", "| |");
    const { markdown, errors } = replaceBlocks(doc(stale), [roles]);
    expect(errors).toEqual([]);
    expect(markdown).toBe(doc(current));
  });

  it("書き換え後にもう一度通しても変わらない", () => {
    const once = replaceBlocks(doc(current), [roles]).markdown;
    expect(replaceBlocks(once, [roles]).markdown).toBe(once);
  });

  it("論理名の無いカラムは空のセルで出し、errors に積む", () => {
    const { markdown, errors } = replaceBlocks(doc(""), [roles]);
    expect(errors).toEqual([
      "roles.id の論理名がありません",
      "roles.description の論理名がありません",
    ]);
    expect(markdown).toContain("| | id | text |");
  });

  it("見出し行が崩れていたら、カラムごとではなく見出しのエラーを 1 つだけ積む", () => {
    const broken = current.replace("| 論理名 | カラム |", "| 論理名 |  カラム |");
    const { errors } = replaceBlocks(doc(broken), [roles]);
    expect(errors).toEqual([expect.stringContaining("table=roles のカラム表に見出し行")]);
  });

  it("end の無いブロックは触らず、後ろのブロックだけを書き換える", () => {
    const members = { ...roles, name: "members" };
    const markdown = `<!-- generated:start table=members -->\n手書き\n${doc(current)}`;
    const { markdown: out, errors } = replaceBlocks(markdown, [members, roles]);
    expect(errors).toEqual([
      "table=members の <!-- generated:end --> がありません",
      expect.stringContaining("members の生成ブロックがありません"),
    ]);
    expect(out).toBe(`<!-- generated:start table=members -->\n手書き\n${doc(current)}`);
  });

  it("ブロックの無いテーブルと、schema に無いブロックを errors に積む", () => {
    const { errors } = replaceBlocks(doc(""), [{ ...roles, name: "members" }]);
    expect(errors).toHaveLength(2);
    expect(errors[0]).toContain("table=roles");
    expect(errors[1]).toContain("members");
  });
});
