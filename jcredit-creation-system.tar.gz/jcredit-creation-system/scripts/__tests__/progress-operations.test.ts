import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

import { chartRange, type OperationsSchedule, pos, renderHtml } from "../progress/operations.mjs";

const schedule = JSON.parse(
  readFileSync(new URL("../../docs/operations/schedule.json", import.meta.url), "utf8"),
) as OperationsSchedule;

const small: OperationsSchedule = {
  title: "予定",
  kinds: { design: "設計・作成" },
  milestones: [{ title: "リリース", date: "2026-11-20" }],
  tasks: [{ label: "章立て", kind: "design", start: "2026-11-02", end: "2026-11-13" }],
};

describe("progress operations", () => {
  it("範囲は予定の最初の週の 2 週前の月曜から、最後の週の 2 週後まで", () => {
    expect(chartRange(small, "2026-11-04")).toEqual({ from: "2026-10-19", weeks: 7, days: 49 });
  });

  it("今日が予定より前でも、今日の週から描く", () => {
    expect(chartRange(small, "2026-10-14").from).toBe("2026-09-28");
  });

  it("日付を範囲の左端からの割合にする", () => {
    const range = chartRange(small, "2026-11-04");
    expect(pos(range, "2026-10-19")).toBe(0);
    expect(pos(range, "2026-12-07")).toBe(100);
  });

  it("今日の赤線と節目を出す", () => {
    const html = renderHtml(small, "2026-11-04");
    expect(html).toContain("今日 11/4");
    expect(html).toContain("▼リリース 11/20");
    expect(html).toContain('class="vline today"');
  });

  it("画面で動かすための予定を埋め込み、</script> で閉じられない", () => {
    const html = renderHtml({ ...small, title: "</script>" }, "2026-11-04");
    expect(html).toContain('<script type="application/json" id="schedule">');
    expect(html).toContain("\\u003c/script>");
    expect(html).toContain('data-action="export"');
  });

  it("schedule.json の kind はすべて kinds にある", () => {
    for (const t of schedule.tasks) expect(Object.keys(schedule.kinds)).toContain(t.kind);
  });
});
