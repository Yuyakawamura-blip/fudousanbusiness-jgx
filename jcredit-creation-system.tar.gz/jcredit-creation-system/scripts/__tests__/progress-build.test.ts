import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

import {
  bandState,
  buildTimeline,
  buildTree,
  cleanBody,
  escapeHtml,
  excludeInfra,
  flattenTree,
  groupByStage,
  holdAhead,
  layoutBands,
  layoutMarks,
  normalizeItem,
  type ProgressIssue,
  renderHtml,
  resolveConfig,
  summarize,
  type TimelineLayout,
  todayInTokyo,
} from "../progress/build.mjs";

const fixture = JSON.parse(
  readFileSync(new URL("./fixtures/progress-data.json", import.meta.url), "utf8"),
) as { project: { url: string; issues: ProgressIssue[] } };
const issues = fixture.project.issues;
const issue = (n: number): ProgressIssue => {
  const found = issues.find((i) => i.number === n);
  if (!found) throw new Error(`fixture に #${n} が無い`);
  return found;
};

describe("progress resolveConfig", () => {
  const detect = () => "japan-gx-group/jcredit-creation-system";

  it("リポジトリは自動判定、Project の owner は既定でリポジトリの owner", () => {
    expect(resolveConfig({ PROGRESS_PROJECT_NUMBER: "7" }, detect)).toEqual({
      repo: "japan-gx-group/jcredit-creation-system",
      projectOwner: "japan-gx-group",
      projectNumber: 7,
    });
  });

  it("環境変数があれば自動判定より優先する(fork の Project が個人所有の場合)", () => {
    const config = resolveConfig(
      {
        PROGRESS_REPO: "someone/fork",
        PROGRESS_PROJECT_OWNER: "someone",
        PROGRESS_PROJECT_NUMBER: "3",
      },
      () => {
        throw new Error("呼ばれない");
      },
    );
    expect(config).toEqual({ repo: "someone/fork", projectOwner: "someone", projectNumber: 3 });
  });

  it("Project 番号が無い・不正ならエラー(元の Project を黙って読まない)", () => {
    expect(() => resolveConfig({}, detect)).toThrow("PROGRESS_PROJECT_NUMBER");
    expect(() => resolveConfig({ PROGRESS_PROJECT_NUMBER: "7a" }, detect)).toThrow();
    expect(() => resolveConfig({ PROGRESS_PROJECT_NUMBER: "0" }, detect)).toThrow();
  });

  it("PROGRESS_REPO が owner/name でなければエラー", () => {
    expect(() =>
      resolveConfig({ PROGRESS_REPO: "jcredit", PROGRESS_PROJECT_NUMBER: "7" }, detect),
    ).toThrow("owner/name");
  });
});

describe("progress normalizeItem", () => {
  it("Issue 以外(PR / Draft)は捨てる", () => {
    expect(normalizeItem({ content: { __typename: "PullRequest" } })).toBeNull();
    expect(normalizeItem({ content: null })).toBeNull();
  });

  it("対応しない(not planned / duplicate)で閉じた Issue は捨てる", () => {
    const closed = (stateReason: string) =>
      normalizeItem({
        content: {
          __typename: "Issue",
          number: 1,
          title: "t",
          url: "u",
          state: "CLOSED",
          stateReason,
          issueType: null,
          assignees: { nodes: [] },
          parent: null,
          subIssues: { nodes: [] },
        },
      });
    expect(closed("NOT_PLANNED")).toBeNull();
    expect(closed("DUPLICATE")).toBeNull();
    expect(closed("COMPLETED")).not.toBeNull();
  });

  it("対応しない理由で閉じた子課題も subIssues から外す(親から補って数えないように)", () => {
    const item = normalizeItem({
      content: {
        __typename: "Issue",
        number: 1,
        title: "t",
        url: "u",
        state: "OPEN",
        issueType: null,
        assignees: { nodes: [] },
        parent: null,
        subIssues: {
          nodes: [
            { number: 2, title: "a", url: "", state: "CLOSED", stateReason: "COMPLETED" },
            { number: 3, title: "b", url: "", state: "CLOSED", stateReason: "NOT_PLANNED" },
            { number: 4, title: "c", url: "", state: "OPEN", stateReason: null },
          ],
        },
      },
    });
    expect(item?.subIssues.map((c) => c.number)).toEqual([2, 4]);
  });

  it("Project のフィールド値を平たくする", () => {
    const item = normalizeItem({
      content: {
        __typename: "Issue",
        number: 1,
        title: "t",
        url: "u",
        state: "OPEN",
        issueType: null,
        assignees: { nodes: [{ login: "a" }] },
        parent: { number: 9 },
        subIssues: { nodes: [] },
      },
      status: { name: "In Progress" },
      feature: { name: "会員マイページ" },
      end: { date: "2026-10-09" },
      sprint: { title: "Sprint 1", startDate: "2026-09-21", duration: 14 },
    });
    expect(item).toMatchObject({
      parent: 9,
      status: "In Progress",
      feature: "会員マイページ",
      start: null,
      end: "2026-10-09",
      assignees: ["a"],
      sprint: { title: "Sprint 1" },
    });
  });
});

describe("progress cleanBody", () => {
  it("未記入欄とコメントを落とし、中身の無い見出しは出さない", () => {
    expect(
      cleanBody(
        "### 目的\r\nログインを書く\r\n\r\n### 補足\r\n\r\n_No response_\r\n\r\n<!-- 書き方 -->\n### やること\n- [ ] 設計書",
      ),
    ).toBe("### 目的\nログインを書く\n\n### やること\n- [ ] 設計書");
    expect(cleanBody(null)).toBe("");
  });
});

describe("progress buildTree", () => {
  it("子課題は親の下にだけ出る", () => {
    const tree = buildTree(issues);
    expect(tree.map((t) => t.number)).toEqual([11, 15, 16]);
    expect(tree[0]?.children.map((c) => c.number)).toEqual([12, 13, 14]);
  });

  it("Project に無い子課題は親の subIssues から補う", () => {
    const child = buildTree(issues)[0]?.children.find((c) => c.number === 14);
    expect(child).toMatchObject({ title: "添付ファイル保存", status: null });
  });

  it("親が Project に無い子はトップレベルに出す", () => {
    const orphan = { ...issue(12), parent: 999 };
    expect(buildTree([orphan]).map((t) => t.number)).toEqual([12]);
  });
});

describe("progress buildTree(3 階層)", () => {
  const sub = (n: number) => ({ number: n, title: `#${n}`, url: `u${n}`, state: "OPEN" as const });
  const grandchild: ProgressIssue = { ...issue(12), number: 20, title: "孫課題", parent: 12 };
  const child: ProgressIssue = { ...issue(12), subIssues: [sub(20)] };
  const list = [issue(11), child, issue(13), grandchild];

  it("孫課題も子の下に出る(表から消えない)", () => {
    const rows = flattenTree(buildTree(list)).map(({ node, depth }) => [node.number, depth]);
    expect(rows).toEqual([
      [11, 0],
      [12, 1],
      [20, 2],
      [13, 1],
      [14, 1],
    ]);
  });

  it("集計対象の課題はすべて表にも出る", () => {
    const shown = new Set(flattenTree(buildTree(list)).map(({ node }) => node.number));
    for (const i of list) expect(shown).toContain(i.number);
  });

  it("親子が循環していても止まる", () => {
    const a: ProgressIssue = { ...issue(15), number: 1, parent: null, subIssues: [sub(2)] };
    const b: ProgressIssue = { ...issue(15), number: 2, parent: 1, subIssues: [sub(1)] };
    expect(flattenTree(buildTree([a, b])).map(({ node }) => node.number)).toEqual([1, 2]);
  });

  it("孫課題の行は子よりも深く字下げする", () => {
    const html = renderHtml({
      today: "2026-10-02",
      summary: summarize(list),
      tree: buildTree(list),
      projectUrl: null,
    });
    expect(html).toContain('padding-left:8px">└</span>申請フォーム画面');
    expect(html).toContain('padding-left:24px">└</span>孫課題');
  });
});

describe("progress summarize", () => {
  it("Done または closed を完了として数える", () => {
    const { all } = summarize(issues);
    expect(all).toMatchObject({
      total: 6,
      done: 2,
      inProgress: 2,
      rate: 33,
    });
  });

  it("課題ゼロでも 0% になる(NaN にしない)", () => {
    expect(summarize([]).all.rate).toBe(0);
  });
});

describe("progress buildTimeline", () => {
  const base = issue(17);
  const make = (patch: Partial<ProgressIssue>): ProgressIssue => ({
    ...base,
    subIssues: [],
    parent: null,
    status: "Todo",
    state: "OPEN",
    feature: "会員マイページ",
    process: "基本設計",
    ...patch,
  });
  const groups: TimelineLayout["groups"] = [
    {
      name: "会員マイページ",
      tone: "app",
      bands: [
        { label: "基本設計", feature: "会員マイページ", processes: ["基本設計"] },
        { label: "詳細設計", feature: "会員マイページ", processes: ["画面設計", "詳細設計"] },
        { label: "内部結合テスト", feature: "会員マイページ", processes: ["内部結合テスト"] },
      ],
    },
    { name: "テスト", bands: [{ label: "総合テスト", feature: "総合テスト" }] },
  ];
  const layout = (milestones: TimelineLayout["milestones"] = []): TimelineLayout => ({
    milestones,
    groups,
  });
  const bandsOf = (t: ReturnType<typeof buildTimeline>, group = 0) => t.groups[group]?.bands ?? [];

  it("帯は layout の順で並び、機能 × 工程の合う課題の Start の最小〜end の最大を取る", () => {
    const t = buildTimeline(
      [
        make({ number: 1, start: "2026-10-01", end: "2026-10-05" }),
        make({ number: 2, start: "2026-10-03", end: "2026-10-20" }),
        make({ number: 3, process: "画面設計", start: "2026-10-21", end: "2026-10-31" }),
        make({ number: 4, process: "詳細設計", start: "2026-11-01", end: "2026-11-10" }),
        make({ number: 5, feature: "DB", start: "2026-09-01", end: "2026-12-31" }),
      ],
      layout(),
      "2026-10-07",
    );
    expect(bandsOf(t).map((b) => [b.label, b.start, b.end, b.total, b.state])).toEqual([
      ["基本設計", "2026-10-01", "2026-10-20", 2, "current"],
      ["詳細設計", "2026-10-21", "2026-11-10", 2, "upcoming"],
      ["内部結合テスト", null, null, 0, "unscheduled"],
    ]);
  });

  it("layout に日付を書いた帯は課題を拾わず、その日付で置く", () => {
    const t = buildTimeline(
      [make({ number: 1, feature: "脆弱性診断", start: "2026-10-01", end: "2026-10-05" })],
      {
        milestones: [],
        groups: [
          {
            name: "脆弱性診断",
            bands: [{ label: "脆弱性診断", start: "2027-02-01", end: "2027-02-19" }],
          },
        ],
      },
      "2026-10-07",
    );
    expect(bandsOf(t).map((b) => [b.label, b.start, b.end, b.total, b.state])).toEqual([
      ["脆弱性診断", "2027-02-01", "2027-02-19", 0, "upcoming"],
    ]);
  });

  it("processes の無い帯は工程を問わず機能だけで拾う", () => {
    const t = buildTimeline(
      [make({ feature: "総合テスト", process: null, start: "2027-02-22", end: "2027-03-12" })],
      layout(),
      "2026-10-07",
    );
    expect(bandsOf(t, 1).map((b) => [b.start, b.end])).toEqual([["2027-02-22", "2027-03-12"]]);
  });

  it("全件完了なら完了、end を過ぎて残っていれば予定超過", () => {
    const t = buildTimeline(
      [
        make({ number: 1, status: "Done", start: "2026-09-01", end: "2026-09-10" }),
        make({ number: 2, process: "詳細設計", start: "2026-09-11", end: "2026-09-20" }),
      ],
      layout(),
      "2026-10-07",
    );
    expect(bandsOf(t).map((b) => b.state)).toEqual(["done", "late", "unscheduled"]);
  });

  it("期間は月曜始まりで、今日と ▼ を含め、末尾に余白の週を足す", () => {
    const t = buildTimeline(
      [make({ start: "2026-10-08", end: "2026-10-09" })],
      layout([{ title: "テスト終了", date: "2027-03-28" }]),
      "2026-10-07",
    );
    expect(t.start).toBe("2026-10-05");
    expect(t.weeks).toBe(25 + 2);
  });

  it("until があれば、帯・▼ より先でもその日を含む週まで描く", () => {
    const t = buildTimeline(
      [make({ start: "2026-10-08", end: "2026-10-09" })],
      { ...layout([{ title: "テスト終了", date: "2027-02-28" }]), until: "2027-04-30" },
      "2026-10-07",
    );
    expect(t.start).toBe("2026-10-05");
    expect(t.weeks).toBe(30);
  });

  it("帯が少なくても最低 13 週の幅で描く", () => {
    expect(buildTimeline([], layout(), "2026-10-07").weeks).toBe(13);
  });

  it("▼ の進捗は前の ▼ の翌日からその ▼ までに終わる帯の課題で数える", () => {
    const t = buildTimeline(
      [
        make({ number: 1, status: "Done", start: "2026-10-19", end: "2026-10-23" }),
        make({ number: 2, start: "2026-10-19", end: "2026-10-20" }),
        make({ number: 3, process: "詳細設計", start: "2026-10-26", end: "2026-11-06" }),
      ],
      layout([
        { title: "詳細設計完了", date: "2026-11-06" },
        { title: "開始", date: "2026-10-19" },
        { title: "基本設計完了", date: "2026-10-23" },
      ]),
      "2026-10-07",
    );
    expect(t.milestones.map((m) => [m.title, m.done, m.total])).toEqual([
      ["開始", 0, 0],
      ["基本設計完了", 1, 2],
      ["詳細設計完了", 0, 1],
    ]);
    expect(t.currentMilestone?.title).toBe("基本設計完了");
  });

  it("期日を過ぎても課題が残る ▼ は現在のマイルストーンに残し、終われば次へ進む", () => {
    const issuesFor = (status: string) => [
      make({ number: 1, status, start: "2026-10-01", end: "2026-10-05" }),
      make({ number: 2, process: "詳細設計", start: "2026-10-06", end: "2026-10-20" }),
    ];
    const marks = [
      { title: "基本設計完了", date: "2026-10-05" },
      { title: "詳細設計完了", date: "2026-10-20" },
    ];
    expect(
      buildTimeline(issuesFor("Todo"), layout(marks), "2026-10-07").currentMilestone?.title,
    ).toBe("基本設計完了");
    expect(
      buildTimeline(issuesFor("Done"), layout(marks), "2026-10-07").currentMilestone?.title,
    ).toBe("詳細設計完了");
  });

  it("リポジトリの layout.json は描画できる形をしている", () => {
    const real = JSON.parse(
      readFileSync(new URL("../progress/layout.json", import.meta.url), "utf8"),
    ) as TimelineLayout;
    const t = buildTimeline(issues, real, "2026-10-07");
    expect(t.groups.map((g) => g.name)).toEqual([
      "全体",
      "会員マイページ",
      "創出PTマイページ",
      "運営者コンソール",
      "API",
      "DB",
      "環境構築",
      "テスト",
      "脆弱性診断",
      "リリース",
    ]);
    expect(t.milestones.length).toBeGreaterThan(0);
  });
});

describe("progress layoutMarks", () => {
  const opts = { start: "2026-10-05", dayPx: 8, rowPx: 20, charPx: 13 };

  it("日付の順に置き、見出しが前の ▼ と重なるときだけ下の段に出す", () => {
    const { marks, rows } = layoutMarks(
      [
        { title: "詳細設計完了", date: "2026-11-06" },
        { title: "設計開始", date: "2026-10-05" },
        { title: "基本設計完了", date: "2026-10-09" },
      ],
      opts,
    );
    expect(marks.map((m) => [m.title, m.left, m.top])).toEqual([
      ["設計開始", -2, 4],
      ["基本設計完了", 30, 24],
      ["詳細設計完了", 254, 4],
    ]);
    expect(rows).toBe(2);
  });

  it("見出しに日付を付け、日付の幅も重なりの判定に入れる", () => {
    const { marks } = layoutMarks(
      [
        { title: "開発完了", date: "2027-01-04" },
        { title: "総合テスト開始", date: "2027-01-11" },
      ],
      { ...opts, start: "2027-01-04" },
    );
    expect(marks.map((m) => [m.text, m.top])).toEqual([
      ["▼開発完了 1月4日", 4],
      ["▼総合テスト開始 1月11日", 24],
    ]);
  });
});

describe("progress layoutBands", () => {
  // 1 日 8px(1 週 56px)。帯の幅 = 日数 × 8
  const opts = { start: "2026-10-05", dayPx: 8, rowPx: 26, padPx: 14 };
  const band = (key: string, start: string | null, end: string | null, label = key) => ({
    key,
    label,
    start,
    end,
    done: 1,
    total: 3,
  });

  it("期間が重なる帯だけ段を分け、日付の無い帯は置かない", () => {
    const { bands, rows } = layoutBands(
      [
        band("A", "2026-10-05", "2026-10-30"),
        band("B", "2026-10-12", "2026-10-30"),
        band("C", "2026-10-31", "2026-11-30"),
        band("D", null, null),
      ],
      opts,
    );
    expect(bands.map((b) => [b.key, b.row, b.left, b.width])).toEqual([
      ["A", 0, 0, 26 * 8],
      ["B", 1, 7 * 8, 19 * 8],
      ["C", 0, 26 * 8, 31 * 8],
    ]);
    expect(rows).toBe(2);
  });

  it("名前と件数が入れば帯の中、件数だけ入らなければ件数を外、名前も入らなければ全部を外に出す", () => {
    const { bands } = layoutBands(
      [
        band("full", "2026-10-05", "2026-10-30", "詳細設計"),
        band("label", "2026-11-02", "2026-11-09", "詳細設計"),
        band("out", "2026-11-16", "2026-11-18", "詳細設計"),
      ],
      opts,
    );
    expect(bands.map((b) => [b.key, b.inside, b.out?.text ?? null])).toEqual([
      ["full", "詳細設計 1/3", null],
      ["label", "詳細設計", "1/3"],
      ["out", "", "詳細設計 1/3"],
    ]);
  });

  it("外に出す文字は、右が空いていなければ下の段に置き、その分だけ段が増える", () => {
    const { bands, rows } = layoutBands(
      [
        band("short", "2026-10-05", "2026-10-06", "基本設計"),
        band("next", "2026-10-07", "2026-10-30"),
      ],
      opts,
    );
    expect(bands[0]?.out).toMatchObject({ left: 0, top: 26 + 6 });
    expect(rows).toBe(2);
  });
});

describe("progress holdAhead", () => {
  it("開始予定が先の帯の完了した課題だけ、子課題ごと対応中にする", () => {
    const layout: TimelineLayout = {
      milestones: [],
      groups: [
        {
          name: "会員マイページ",
          bands: [
            { label: "基本設計", feature: "会員マイページ", processes: ["基本設計"] },
            {
              label: "詳細設計",
              feature: "会員マイページ",
              processes: ["詳細設計"],
              start: "2026-10-26",
              end: "2026-11-15",
            },
          ],
        },
      ],
    };
    const child = { number: 9, title: "子", url: "", state: "CLOSED" as const };
    const done = (number: number, process: string): ProgressIssue => ({
      ...issue(17),
      number,
      feature: "会員マイページ",
      process,
      status: "Done",
      state: "CLOSED",
      subIssues: [],
    });
    const issues = [
      { ...done(1, "基本設計"), start: "2026-10-01", end: "2026-10-09" },
      { ...done(2, "詳細設計"), subIssues: [child] },
      { ...done(3, "詳細設計"), status: "Todo", state: "OPEN" as const },
    ];
    const held = holdAhead(issues, buildTimeline(issues, layout, "2026-10-13"), "2026-10-13");
    expect(held.map((i) => [i.number, i.status, i.state])).toEqual([
      [1, "Done", "CLOSED"],
      [2, "In Progress", "OPEN"],
      [3, "Todo", "OPEN"],
    ]);
    expect(held[1]?.subIssues[0]?.state).toBe("OPEN");
  });
});

describe("progress bandState", () => {
  it("全件完了なら完了、end を過ぎて残れば予定超過、期間中なら進行中、日付が無ければ未設定", () => {
    expect(bandState("2026-10-01", "2026-10-05", 2, 2, "2026-10-07")).toBe("done");
    expect(bandState("2026-10-01", "2026-10-05", 1, 2, "2026-10-07")).toBe("late");
    expect(bandState("2026-10-01", "2026-10-07", 1, 2, "2026-10-07")).toBe("current");
    expect(bandState("2026-10-08", "2026-10-09", 0, 2, "2026-10-07")).toBe("upcoming");
    expect(bandState(null, null, 0, 0, "2026-10-07")).toBe("unscheduled");
  });

  it("課題の無い帯は、end を過ぎたら完了、それまでは期間で進行中か予定", () => {
    expect(bandState("2026-10-01", "2026-10-05", 0, 0, "2026-10-07")).toBe("done");
    expect(bandState("2026-10-01", "2026-10-07", 0, 0, "2026-10-07")).toBe("current");
    expect(bandState("2026-10-08", "2026-10-09", 0, 0, "2026-10-07")).toBe("upcoming");
  });
});

describe("progress excludeInfra", () => {
  it("環境構築の課題と、親の subIssues に残るその番号を外す", () => {
    const make = (patch: Partial<ProgressIssue>): ProgressIssue => ({
      ...issue(17),
      subIssues: [],
      parent: null,
      feature: null,
      ...patch,
    });
    const out = excludeInfra([
      make({
        number: 1,
        feature: "dev環境構築",
        subIssues: [{ number: 2, title: "", url: "", state: "OPEN" }],
      }),
      make({ number: 2, parent: 1, feature: "dev環境構築" }),
      make({
        number: 3,
        feature: "API",
        subIssues: [
          { number: 4, title: "", url: "", state: "OPEN" },
          { number: 5, title: "", url: "", state: "OPEN" },
        ],
      }),
      make({ number: 4, parent: 3, feature: "本番環境構築" }),
      make({ number: 5, parent: 3, feature: "API" }),
    ]);
    expect(out.map((i) => [i.number, i.subIssues.map((s) => s.number)])).toEqual([
      [3, [5]],
      [5, []],
    ]);
  });
});

describe("progress groupByStage", () => {
  const node = (patch: Partial<ProgressIssue>): ProgressIssue => ({
    ...issue(17),
    subIssues: [],
    parent: null,
    status: "Todo",
    state: "OPEN",
    feature: null,
    process: null,
    ...patch,
  });

  it("工程の順(基本設計 → 詳細設計 → フロントエンド開発 → バックエンド開発 → テスト → その他)に並べ、画面設計は詳細設計に、工程「開発」はバックエンド開発に入れる", () => {
    const stages = groupByStage(
      buildTree([
        node({ number: 1, process: "テスト" }),
        node({ number: 2, process: "画面設計" }),
        node({ number: 3, process: "基本設計", status: "Done" }),
        node({ number: 4, process: "フロントエンド開発", status: "In Progress" }),
        node({ number: 5 }),
        node({ number: 8, process: "開発" }),
        node({ number: 7, feature: "UAT" }),
      ]),
    );
    expect(stages.map((s) => [s.name, s.tree.map((n) => n.number)])).toEqual([
      ["基本設計", [3]],
      ["詳細設計", [2]],
      ["フロントエンド開発", [4]],
      ["バックエンド開発", [8]],
      ["テスト", [1, 7]],
      ["その他", [5]],
    ]);
    expect(stages[0]).toMatchObject({ done: 1, total: 1 });
    expect(stages[2]).toMatchObject({ inProgress: 1 });
  });

  it("子課題は親と同じまとまりに入り、工程の無い親は子の工程で決める", () => {
    const parent = node({
      number: 10,
      subIssues: [{ number: 11, title: "c", url: "", state: "OPEN" }],
    });
    const child = node({ number: 11, parent: 10, process: "詳細設計" });
    const stages = groupByStage(buildTree([parent, child]));
    expect(stages.map((s) => [s.name, s.total])).toEqual([["詳細設計", 2]]);
  });

  it("予定期間は、まとまりの課題(子課題を含む)の Start の最小 〜 end の最大", () => {
    const parent = node({
      number: 10,
      process: "詳細設計",
      start: "2026-10-26",
      end: "2026-11-08",
      subIssues: [{ number: 11, title: "c", url: "", state: "OPEN" }],
    });
    const child = node({ number: 11, parent: 10, start: "2026-11-02", end: "2026-11-22" });
    const [stage] = groupByStage(buildTree([parent, child]));
    expect([stage?.start, stage?.end]).toEqual(["2026-10-26", "2026-11-22"]);
  });
});

describe("progress todayInTokyo", () => {
  it("UTC 15 時以降は JST の翌日", () => {
    expect(todayInTokyo(new Date("2026-10-01T15:00:00Z"))).toBe("2026-10-02");
  });
});

describe("progress renderHtml", () => {
  const render = (list: ProgressIssue[]) =>
    renderHtml({
      today: "2026-10-02",
      summary: summarize(list),
      tree: buildTree(list),
      projectUrl: null,
    });

  it("課題タイトルを HTML エスケープする", () => {
    expect(escapeHtml(`<a href="x">'&`)).toBe("&lt;a href=&quot;x&quot;&gt;&#39;&amp;");
    expect(render(issues)).toContain("審査一覧 &lt;画面&gt;");
  });

  it("システム名を差し替えられる(fork 先で使い回すため)", () => {
    const html = renderHtml({
      today: "2026-10-02",
      summary: summarize([]),
      tree: [],
      projectUrl: null,
      systemName: "別システム <β>",
    });
    expect(html).toContain("<h1>別システム &lt;β&gt; 進捗報告</h1>");
  });

  it("空の宿題行の除外は印刷イベントで行う(Cmd+P でも効く)", () => {
    const html = render(issues);
    expect(html).toContain('addEventListener("beforeprint"');
    expect(html).toContain('addEventListener("afterprint"');
    expect(html).not.toContain("data-print-opened");
    expect(html).toContain('id="save-html"');
    expect(html).toContain('<script type="application/json" id="saved-state">null</script>');
    expect(html).toContain('<ul class="stage-late print-only"></ul>');
  });

  it("入力のクリアは確認を挟み、PDF 出力ボタンの隣に置かない", () => {
    const html = render(issues);
    expect(html).toContain("window.confirm(");
    expect(html.indexOf('id="clear"')).toBeGreaterThan(html.indexOf('data-key="memo"'));
  });

  it("メモ・宿題・決定事項の入力欄と PDF 出力ボタンがある", () => {
    const html = render(issues);
    expect(html).toContain('data-key="memo"');
    expect(html).toContain('data-key="decisions"');
    expect(html).toContain('id="homework"');
    expect(html).toContain('id="pdf"');
  });

  it("帯ごとの予定表は図と同じ並びで、日付は入力欄にし、end を過ぎて残る帯に予定超過を付ける", () => {
    const html = renderHtml({
      today: "2026-10-07",
      summary: summarize([]),
      tree: [],
      projectUrl: null,
      timeline: buildTimeline(
        [
          {
            ...issue(17),
            status: "Todo",
            state: "OPEN",
            feature: "会員マイページ",
            process: "基本設計",
            start: "2026-09-21",
            end: "2026-10-01",
          },
        ],
        {
          milestones: [],
          groups: [
            {
              name: "会員マイページ",
              bands: [
                { label: "基本設計", feature: "会員マイページ", processes: ["基本設計"] },
                { label: "詳細設計", feature: "会員マイページ", processes: ["詳細設計"] },
              ],
            },
          ],
        },
        "2026-10-07",
      ),
    });
    expect(html).toContain(
      '<input type="date" class="band-date" data-band="会員マイページ/基本設計" data-edge="start" value="2026-09-21"',
    );
    expect(html).toContain('data-band="会員マイページ/詳細設計" data-edge="end" value=""');
    expect(html).toMatch(/data-band="会員マイページ\/基本設計">予定超過</);
    expect(html).toContain('class="tl-band unscheduled" data-key="会員マイページ/詳細設計"');
  });

  it("マイルストーン図に今日の縦線・▼・工程の帯を出し、メモ欄は右カラムに置く", () => {
    const html = renderHtml({
      today: "2026-10-07",
      summary: summarize(issues),
      tree: buildTree(issues),
      projectUrl: null,
      timeline: buildTimeline(
        [
          {
            ...issue(17),
            status: "Done",
            feature: "会員マイページ",
            process: "基本設計",
            start: "2026-10-01",
            end: "2026-10-10",
          },
          {
            ...issue(17),
            number: 999,
            status: "Todo",
            state: "OPEN",
            feature: "会員マイページ",
            process: "基本設計",
            start: "2026-10-01",
            end: "2026-10-15",
          },
        ],
        {
          milestones: [{ title: "要件定義完了報告", date: "2026-10-15" }],
          groups: [
            {
              name: "会員マイページ",
              tone: "app",
              bands: [{ label: "基本設計", feature: "会員マイページ", processes: ["基本設計"] }],
            },
          ],
        },
        "2026-10-07",
      ),
    });
    expect(html).toContain("今日 10/7");
    expect(html).toContain("▼要件定義完了報告 10月15日");
    expect(html).toContain('class="tl-mark-line" data-title="要件定義完了報告"');
    expect(html).not.toContain('<span class="badge doing">進行中</span>');
    expect(html).toContain("あと 8 日");
    expect(html).toContain(
      "現在のマイルストーン(▼要件定義完了報告 <span data-milestone-date>10/15</span>)",
    );
    expect(html).toContain('data-title="要件定義完了報告" data-date="2026-10-15"');
    expect(html).toMatch(
      /完了 <span data-tally="done" data-issues="17,999" data-milestone-kpi>1<\/span> \/ 全 <span data-tally="total" data-issues="17,999" data-milestone-kpi>2<\/span> 件/,
    );
    expect(html).not.toContain("今スプリント");
    expect(html).not.toContain("<th>Sprint</th>");
    expect(html).toContain('class="tl-band current"');
    expect(html).toContain('<div class="tl-group-name">会員マイページ</div>');
    expect(html.indexOf('<aside class="notes">')).toBeLessThan(html.indexOf('data-key="memo"'));
  });

  it("状態はプルダウンで、GitHub の状態を初期値に持ち、変えた分だけブラウザに保存する", () => {
    const html = render([{ ...issue(17), status: "In Progress", state: "OPEN" }]);
    expect(html).toContain('data-issue="17" data-github="doing"');
    expect(html).toContain('<option value="doing" selected>対応中</option>');
    expect(html).toContain("state.status[el.dataset.issue] = el.value");
    expect(html).not.toContain("graphql");
  });

  it("課題一覧は工程ごとの開閉式で、終わっていない最初の工程だけ開いておく", () => {
    const html = render([
      {
        ...issue(17),
        subIssues: [],
        parent: null,
        process: "基本設計",
        status: "Done",
        state: "CLOSED",
      },
      {
        ...issue(17),
        number: 1001,
        subIssues: [],
        parent: null,
        process: "詳細設計",
        status: "Todo",
        state: "OPEN",
      },
      {
        ...issue(17),
        number: 1002,
        subIssues: [],
        parent: null,
        process: "開発",
        status: "Todo",
        state: "OPEN",
      },
    ]);
    expect(html.match(/<details class="stage"/g)).toHaveLength(3);
    expect(html.match(/<details class="stage" open>/g)).toHaveLength(1);
    expect(html.indexOf('<details class="stage" open>')).toBeGreaterThan(
      html.indexOf("基本設計</span>"),
    );
    expect(html).not.toContain("d.open = true");
  });

  it("状態を変えたときに数え直す数字は、対象の課題番号と課題の状態を持たせて描く", () => {
    const html = render(issues);
    const data = JSON.parse(
      html.match(/<script type="application\/json" id="issue-data">(.*?)<\/script>/)?.[1] ?? "{}",
    ) as Record<string, { s: string; sp: number }>;
    expect(data["12"]?.s).toBe("done");
    expect(Object.keys(data)).toHaveLength(flattenTree(buildTree(issues)).length);
    expect(html).toContain('data-tally="rate"');
    expect(html).toContain('data-tally="doing-paren"');
  });

  it("課題データに < が入っても script を閉じない", () => {
    const html = render([{ ...issue(17), title: "</script><b>" }]);
    expect(html).toContain("\\u003c/script>\\u003cb>");
  });

  it("件数が帯に入らないときは、件数を帯の外に出す", () => {
    const html = renderHtml({
      today: "2026-10-07",
      summary: summarize([]),
      tree: [],
      projectUrl: null,
      timeline: buildTimeline(
        [
          {
            ...issue(17),
            status: "Done",
            feature: "UAT",
            process: null,
            start: "2027-02-22",
            end: "2027-02-28",
          },
        ],
        {
          milestones: [],
          groups: [
            {
              name: "テスト",
              bands: [{ label: "UAT", feature: "UAT" }],
            },
          ],
        },
        "2026-10-07",
      ),
    });
    expect(html).toMatch(/<div class="tl-band-out done" data-band-out [^>]*>1\/1<\/div>/);
  });

  it("時点の日付はクリックで変えられ、生成日時は出さない", () => {
    const html = render(issues);
    expect(html).toContain('<input type="date" id="as-of" value="2026-10-02"');
    expect(html).not.toContain("/ 生成 ");
    expect(html).toContain("state.asOf = asOf.value");
    expect(html).toContain("moveToday()");
  });

  it("課題一覧は状態の左に機能の列を出す", () => {
    const html = render([{ ...issue(17), feature: "会員マイページ" }]);
    expect(html).toContain("<th>課題</th><th>機能</th><th>状態</th>");
    expect(html).toContain('<td class="feature">会員マイページ</td>');
  });

  it("帯の配置と色は、ページ内のスクリプトでも同じ関数を使う", () => {
    const html = render(issues);
    expect(html).toContain(`const layoutBands = ${layoutBands.toString()};`);
    expect(html).toContain(`const layoutMarks = ${layoutMarks.toString()};`);
    expect(html).toContain(`const bandState = ${bandState.toString()};`);
  });

  it("直近の対応内容は出さず、議題は課題から選んで足し、議論したい内容・確定事項を書ける", () => {
    const html = render([{ ...issue(17), title: "審査 <一覧>", body: "### 目的\n</script>" }]);
    expect(html).not.toContain("直近の対応内容");
    expect(html).toContain("<h2>議題</h2>");
    expect(html).toContain('<option value="#17 審査 &lt;一覧&gt;"></option>');
    expect(html).toContain('"議論したい内容"');
    expect(html).toContain('"確定事項"');
    expect(html).toContain("state.topics = ");
    expect(html).toContain('"b":"### 目的\\n\\u003c/script>"');
    expect(html).toContain('"課題の内容"');
    expect(html).not.toContain("data-topic-status");
    expect(html.indexOf('id="topics"')).toBeLessThan(html.indexOf('<aside class="notes"'));
  });

  it("課題ゼロでも描画できる", () => {
    expect(render([])).toContain("課題管理表に課題がまだありません");
  });
});
