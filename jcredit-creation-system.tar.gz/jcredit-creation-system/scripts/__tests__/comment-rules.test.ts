import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const ROOT = fileURLToPath(new URL("../..", import.meta.url));
const RULES = fileURLToPath(new URL("../../.claude/hooks/comment-rules.awk", import.meta.url));
const ID_FN = fileURLToPath(new URL("../../.claude/hooks/requirement-id.awk", import.meta.url));
const FIXTURES = fileURLToPath(new URL("./fixtures/comment-lines.tsv", import.meta.url));

const runRules = (input: string, file: string): string =>
  execFileSync("awk", ["-v", `F=${file}`, "-f", ID_FN, "-f", RULES], {
    input,
    encoding: "utf8",
    cwd: ROOT,
  });

/** 1 行を通し、検出された C-n を返す(検出なしは null) */
const detect = (line: string): string | null => {
  const out = runRules(`1\t${line}\n`, "probe.ts");
  return out.trim() === "" ? null : (/\[(C-\d+)\]/.exec(out)?.[1] ?? null);
};

const cases = readFileSync(FIXTURES, "utf8")
  .split("\n")
  .filter((l) => l && !l.startsWith("#"))
  .map((l) => {
    const [expected, ...rest] = l.split("\t");
    return { expected: expected === "-" ? null : expected, line: rest.join("\t") };
  });

describe("comment-rules.awk", () => {
  it("フィクスチャが両方の向きを含んでいる", () => {
    expect(cases.filter((c) => c.expected !== null).length).toBeGreaterThan(5);
    expect(cases.filter((c) => c.expected === null).length).toBeGreaterThan(5);
  });

  it.each(cases)("$expected ← $line", ({ expected, line }) => {
    expect(detect(line)).toBe(expected);
  });

  it("ファイル名と行番号を報告する", () => {
    const sample = cases.find((c) => c.expected !== null);
    if (!sample) throw new Error("検出される側のフィクスチャが無い");
    expect(runRules(`42\t${sample.line}\n`, "apps/api/src/x.ts").trim()).toBe(
      `apps/api/src/x.ts:42  [${sample.expected}] ${sample.line}`,
    );
  });
});

describe("既存コードへの誤検知", () => {
  it("既知の cli.mjs の区切りバナー以外は検出しない", () => {
    const files = execFileSync("git", ["ls-files", "*.ts", "*.tsx", "*.mjs", "*.cjs", "*.js"], {
      cwd: ROOT,
      encoding: "utf8",
    })
      .split("\n")
      .filter(Boolean);

    const hits = files.flatMap((f) => {
      const numbered = execFileSync("awk", ['{ print NR "\t" $0 }', f], {
        cwd: ROOT,
        encoding: "utf8",
      });
      return runRules(numbered, f).split("\n").filter(Boolean);
    });

    // 遡及修正しない方針(ADR-0003)のため既存の 4 件は残している
    const unexpected = hits.filter((h) => !(h.includes("cli.mjs") && h.includes("[C-5]")));
    expect(unexpected).toEqual([]);
  });
});

describe("requirement-id-rules.awk", () => {
  const ID_RULES = fileURLToPath(
    new URL("../../.claude/hooks/requirement-id-rules.awk", import.meta.url),
  );
  const detectId = (line: string): boolean =>
    execFileSync("awk", ["-v", "F=docs/x.md", "-f", ID_FN, "-f", ID_RULES], {
      input: `3\t${line}\n`,
      encoding: "utf8",
    }).includes("[要件定義の ID]");

  it.each([
    "- 仮登録は FR-20-004 のとおり",
    "| 通知 | NT-001 |",
    "画面は SCR-U-104",
    "状態 MB-40 のとき",
  ])("検出する: %s", (line) => {
    expect(detectId(line)).toBe(true);
  });

  it.each([
    "- 機能要件 ID(`FR-xx-xxx`)は書かない",
    "TLS-1.2 以上",
    "ADR-0003 を参照",
    "SCR とだけ書く",
  ])("検出しない: %s", (line) => {
    expect(detectId(line)).toBe(false);
  });

  it("今の docs/ に要件定義の ID は無い", () => {
    const files = execFileSync("git", ["ls-files", "docs/**/*.md", "docs/*.md"], {
      cwd: ROOT,
      encoding: "utf8",
    })
      .split("\n")
      .filter(Boolean);
    const hits = files.flatMap((f) => {
      const numbered = readFileSync(`${ROOT}/${f}`, "utf8")
        .split("\n")
        .map((l, i) => `${i + 1}\t${l}`)
        .join("\n");
      return execFileSync("awk", ["-v", `F=${f}`, "-f", ID_FN, "-f", ID_RULES], {
        input: numbered,
        encoding: "utf8",
      })
        .split("\n")
        .filter(Boolean);
    });
    expect(hits).toEqual([]);
  });
});
