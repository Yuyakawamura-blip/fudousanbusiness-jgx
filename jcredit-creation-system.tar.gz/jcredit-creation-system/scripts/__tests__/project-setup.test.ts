import { describe, expect, it } from "vitest";

import { BOARD, buildIterations, nextMonday } from "../project/setup.mjs";

describe("setup.mjs nextMonday", () => {
  it("木曜なら次の月曜", () => {
    expect(nextMonday(new Date("2026-09-17T10:00:00Z"))).toBe("2026-09-21");
  });

  it("JST で月曜の間は当日(UTC ではまだ日曜の 0 時台でも)", () => {
    expect(nextMonday(new Date("2026-09-20T15:30:00Z"))).toBe("2026-09-21");
    expect(nextMonday(new Date("2026-09-21T14:59:00Z"))).toBe("2026-09-21");
  });

  it("JST で火曜になったら翌週(UTC では月曜 23 時でも)", () => {
    expect(nextMonday(new Date("2026-09-21T23:00:00Z"))).toBe("2026-09-28");
  });
});

describe("setup.mjs buildIterations", () => {
  it("開始日から duration ごとに連番で作る", () => {
    expect(buildIterations("2026-09-21", 14, 3)).toEqual([
      { title: "Sprint 1", startDate: "2026-09-21", duration: 14 },
      { title: "Sprint 2", startDate: "2026-10-05", duration: 14 },
      { title: "Sprint 3", startDate: "2026-10-19", duration: 14 },
    ]);
  });

  it("BOARD の既定で作れる", () => {
    const list = buildIterations(
      "2026-09-21",
      BOARD.sprint.durationDays,
      BOARD.sprint.initialCount,
    );
    expect(list).toHaveLength(BOARD.sprint.initialCount);
  });
});
