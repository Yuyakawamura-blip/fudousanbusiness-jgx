import { describe, expect, it } from "vitest";

import { extractXml, listFrames } from "../figma/frames.mjs";

const xml = `<canvas id="10:2" name="会員" x="0" y="0" width="0" height="0">
  <section id="1:1" name="01｜会員登録" x="0" y="0" width="9000" height="4000">
    <frame id="24:2" name="UI 02｜メールアドレス登録" x="0" y="0" width="1440" height="1530">
      <frame id="24:3" name="Body" x="0" y="0" width="1440" height="900" />
      <instance id="24:4" name="Header" x="0" y="0" width="1440" height="107" />
    </frame>
    <frame id="195:6831" name="Audience" x="0" y="0" width="377" height="40" />
    <instance id="9:9" name="Step 1 > 2" x="0" y="0" width="1440" height="10" />
    <frame id="170:3453" name="UI 02B｜確認メール送信完了" x="0" y="0" width="1440" height="1335" />
    <group id="5:1" name="個人" x="0" y="0" width="3000" height="2000">
      <frame id="626:6955" name="UI 03｜アカウント作成(個人)" x="0" y="0" width="1440" height="2400" />
    </group>
    <frame id="5:2" name="法人" x="0" y="0" width="400" height="2000">
      <frame id="29:2" name="UI 03｜アカウント作成(法人)" x="0" y="0" width="1440" height="2600">
        <frame id="29:3" name="Body" x="0" y="0" width="1440" height="2000" />
      </frame>
    </frame>
  </section>
  <frame id="374:14392" name="UI 21B｜確認事項" x="0" y="0" width="1440" height="1233">
    <frame id="374:14394" name="Member page body" x="0" y="0" width="1440" height="1009" />
  </frame>
</canvas>`;

describe("listFrames", () => {
  it("セクションの中の画面フレームを、グループ・幅の狭いフレームで包まれていても拾い、画面の中のフレーム・部品・幅の狭いものは外す", () => {
    expect(listFrames(xml)).toEqual([
      {
        section: { tag: "section", id: "1:1", name: "01｜会員登録" },
        frames: [
          { id: "24:2", name: "UI 02｜メールアドレス登録", width: 1440, height: 1530 },
          { id: "170:3453", name: "UI 02B｜確認メール送信完了", width: 1440, height: 1335 },
          { id: "626:6955", name: "UI 03｜アカウント作成(個人)", width: 1440, height: 2400 },
          { id: "29:2", name: "UI 03｜アカウント作成(法人)", width: 1440, height: 2600 },
        ],
      },
      {
        section: null,
        frames: [{ id: "374:14392", name: "UI 21B｜確認事項", width: 1440, height: 1233 }],
      },
    ]);
  });
});

describe("extractXml", () => {
  it("MCP が保存した JSON 配列から XML を取り出す(前置きの選択中ノードは落とす)", () => {
    const saved = JSON.stringify([
      { type: "text", text: `Currently selected nodes:\n- 24:172: x\n\n${xml}` },
    ]);
    expect(extractXml(saved).startsWith('<canvas id="10:2"')).toBe(true);
  });

  it("XML をそのまま保存したファイルも読める。XML が無ければ空", () => {
    expect(extractXml(xml)).toBe(xml);
    expect(extractXml("no xml")).toBe("");
  });
});
