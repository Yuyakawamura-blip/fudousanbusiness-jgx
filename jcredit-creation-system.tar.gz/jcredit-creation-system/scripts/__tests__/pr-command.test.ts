import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const ROOT = fileURLToPath(new URL("../..", import.meta.url));

const parse = (cmd: string): Record<string, unknown> =>
  JSON.parse(
    execFileSync("node", ["scripts/screenshots/cli.mjs", "pr-command", "--stdin"], {
      input: cmd,
      encoding: "utf8",
      cwd: ROOT,
    }),
  );

describe("cli.mjs pr-command", () => {
  it("gh pr create 以外は invokes=false", () => {
    expect(parse("gh pr list --head feat/x")).toEqual({ invokes: false });
  });

  it("--base 省略は develop", () => {
    expect(parse("gh pr create --title t")).toMatchObject({ invokes: true, base: "develop" });
  });

  it("作業ブランチを base に取れる(stacked PR)", () => {
    expect(parse("gh pr create -B feat/x-2 --body-file /tmp/b.md")).toMatchObject({
      base: "feat/x-2",
      bodyFile: "/tmp/b.md",
    });
  });

  it("heredoc 内のコマンド例は無視する", () => {
    expect(parse("cat <<'EOF'\ngh pr create --base main\nEOF")).toEqual({ invokes: false });
  });
});
