/** operations.mjs の公開シグネチャ。テストから型付きで import するためだけに置く(実装は .mjs) */
export interface OperationsSchedule {
  title: string;
  kinds: Record<string, string>;
  milestones: { title: string; date: string }[];
  tasks: { label: string; owner?: string; kind: string; start: string; end: string }[];
}

export interface ChartRange {
  from: string;
  weeks: number;
  days: number;
}

export declare const chartRange: (schedule: OperationsSchedule, today: string) => ChartRange;
export declare const pos: (range: ChartRange, date: string) => number;
export declare const renderHtml: (schedule: OperationsSchedule, today: string) => string;
