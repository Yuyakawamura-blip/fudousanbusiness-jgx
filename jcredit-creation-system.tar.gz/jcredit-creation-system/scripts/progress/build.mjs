#!/usr/bin/env node
/**
 * 先方向けの進捗レポート(1 枚の HTML)を作る CLI。課題は GitHub Project(課題管理表)から、進捗は GitHub から取る。
 * 依存ゼロ(node 組み込みのみ)。gh は子プロセスで呼ぶ。対象の Project は環境変数(PROGRESS_*)で切り替える。
 * 手順は docs/project-board.md「進捗レポート」。
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

/**
 * 環境変数から対象を決める。リポジトリは既定で今いる git リポジトリ(fork でも設定なしで fork 先を向く)。
 * Project 番号に既定値を持たせない — fork 先で設定し忘れたとき、元の Project の数字を黙って出さないため
 */
export const resolveConfig = (env, detectRepo) => {
  const repo = env.PROGRESS_REPO || detectRepo();
  if (!/^[^/\s]+\/[^/\s]+$/.test(repo)) {
    throw new Error(`PROGRESS_REPO は owner/name の形で指定する(値: ${repo})`);
  }
  const number = Number(env.PROGRESS_PROJECT_NUMBER);
  if (!Number.isInteger(number) || number <= 0) {
    throw new Error(
      "PROGRESS_PROJECT_NUMBER が未設定か不正。ルートの .env に課題管理表(GitHub Project)の番号を書く(.env.example 参照)",
    );
  }
  return {
    repo,
    projectOwner: env.PROGRESS_PROJECT_OWNER || repo.split("/")[0],
    projectNumber: number,
  };
};

/** 「今日」は Asia/Tokyo で判定する。UTC だと JST の朝 9 時前に実行したとき前日扱いになる */
export const todayInTokyo = (from) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(from);

const addDays = (date, days) => {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

const daysBetween = (from, to) =>
  Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000);

const mondayOf = (date) => addDays(date, -((new Date(`${date}T00:00:00Z`).getUTCDay() + 6) % 7));

export const isDone = (issue) => issue.status === "Done" || issue.state === "CLOSED";

const ratio = (done, total) => (total === 0 ? 0 : Math.round((done / total) * 100));

// 対応しないと決めて閉じた Issue。完了と数えると完了率が実態より上がるので、報告から外す
const DROPPED_REASONS = ["NOT_PLANNED", "DUPLICATE"];

/** PR / Draft Issue は親子関係を持たないので課題として扱わない */
/**
 * 議題に出す Issue の本文。Issue フォームの未記入欄(_No response_)とコメントは落とし、中身の無い見出しも出さない
 */
export const cleanBody = (body) =>
  (body ?? "")
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/\r\n/g, "\n")
    .split(/^(?=#{1,6} )/m)
    .map((section) => section.replace(/^_No response_$/gm, "").trim())
    .filter((section) => section !== "" && !/^#{1,6} [^\n]*$/.test(section))
    .join("\n\n");

export const normalizeItem = (node) => {
  const c = node.content;
  if (c?.__typename !== "Issue") return null;
  if (DROPPED_REASONS.includes(c.stateReason)) return null;
  return {
    number: c.number,
    title: c.title,
    url: c.url,
    body: cleanBody(c.body),
    state: c.state,
    type: c.issueType?.name ?? null,
    assignees: c.assignees.nodes.map((a) => a.login),
    parent: c.parent?.number ?? null,
    // 親から補って出す子課題も、対応しない理由で閉じたものは数えない
    subIssues: c.subIssues.nodes
      .filter((s) => !DROPPED_REASONS.includes(s.stateReason))
      .map((s) => ({
        number: s.number,
        title: s.title,
        url: s.url,
        state: s.state,
      })),
    status: node.status?.name ?? null,
    feature: node.feature?.name ?? null,
    process: node.process?.name ?? null,
    start: node.start?.date ?? null,
    end: node.end?.date ?? null,
    priority: node.priority?.name ?? null,
    sprint: node.sprint
      ? {
          title: node.sprint.title,
          startDate: node.sprint.startDate,
          duration: node.sprint.duration,
        }
      : null,
  };
};

/** 環境構築はインフラ側の作業なので、報告の件数・課題一覧に入れない(図の帯は layout.json の日付だけで置き、feature を書かない) */
const INFRA_FEATURES = ["dev環境構築", "stg環境構築", "本番環境構築"];

export const excludeInfra = (issues) => {
  const infra = new Set(
    issues.filter((i) => INFRA_FEATURES.includes(i.feature)).map((i) => i.number),
  );
  return issues
    .filter((i) => !infra.has(i.number))
    .map((i) => ({ ...i, subIssues: i.subIssues.filter((s) => !infra.has(s.number)) }));
};

/**
 * 親子の木にする(孫以下も再帰的にたどる)。Project に載っていない子課題も親の subIssues から補う
 * (Auto-add の対象外で作られた子があるため)。親が Project に載っていない子はトップレベルに出す。
 */
export const buildTree = (issues) => {
  const byNumber = new Map(issues.map((i) => [i.number, i]));
  // 親子の循環は GitHub 側で作れないはずだが、データ不整合で無限再帰しないよう訪問済みを持つ
  const build = (issue, seen) => {
    const next = new Set(seen).add(issue.number);
    const children = (issue.subIssues ?? [])
      .filter((s) => !next.has(s.number))
      .map((s) => {
        const known = byNumber.get(s.number);
        // Project に無い子はその先をたどらない — 孫を取るには Issue ごとに追加の問い合わせが要り、
        // Auto-add があるので Project に無い子(=その孫)は例外的にしか生じない
        return known ? build(known, next) : { ...s, status: null, children: [] };
      });
    return { ...issue, children };
  };
  return issues
    .filter((i) => i.parent === null || !byNumber.has(i.parent))
    .map((i) => build(i, new Set()));
};

export const flattenTree = (tree, depth = 0) =>
  tree.flatMap((node) => [{ node, depth }, ...flattenTree(node.children, depth + 1)]);

export const summarize = (issues) => {
  const tally = (list) => {
    const done = list.filter(isDone);
    return {
      total: list.length,
      done: done.length,
      inProgress: list.filter((i) => !isDone(i) && i.status === "In Progress").length,
      rate: ratio(done.length, list.length),
      issues: list.map((i) => i.number),
    };
  };

  return { all: tally(issues) };
};

/*
 * bandState と layoutBands と layoutMarks は、サーバーの描画とページ内のスクリプト(画面で状態・予定日を変えたときの描き直し)の
 * 両方で使う。ページには Function#toString でソースを埋め込むので、関数の外の変数・import を参照しない
 */

export const bandState = (start, end, done, total, today) =>
  !start || !end
    ? "unscheduled"
    : (total > 0 ? done === total : end < today)
      ? "done"
      : end < today
        ? "late"
        : start <= today
          ? "current"
          : "upcoming";

export const layoutMarks = (marks, { start, dayPx, rowPx, charPx }) => {
  const dayDiff = (from, to) =>
    (Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000;
  // 半角(数字・英字・空白)は全角のおよそ半分の幅
  const textPx = (text) =>
    [...text].reduce((sum, ch) => sum + (ch.charCodeAt(0) > 0xff ? charPx : charPx / 2), 0);
  const rowEnds = [];
  const placed = [...marks]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((m) => {
      const text = `▼${m.title} ${Number(m.date.slice(5, 7))}月${Number(m.date.slice(8, 10))}日`;
      const left = dayDiff(start, m.date) * dayPx + dayPx / 2 - 6;
      let row = rowEnds.findIndex((r) => r < left);
      if (row === -1) row = rowEnds.push(0) - 1;
      rowEnds[row] = left + textPx(text) + 8;
      return { title: m.title, text, left, top: row * rowPx + 4 };
    });
  return { marks: placed, rows: rowEnds.length };
};

/** 1 つの枠の帯の置き方。段は期間が重なるときだけ分け、帯に入らない文字は他の帯・文字と重ならない段に出す */
export const layoutBands = (bands, { start, dayPx, rowPx, padPx }) => {
  // 帯の中の文字(12px)の幅の目安。全角 12px・空白 4px・ほかの半角 7px
  const textPx = (text) =>
    [...text].reduce((sum, ch) => sum + (ch.charCodeAt(0) > 0xff ? 12 : ch === " " ? 4 : 7), 0);
  const dayDiff = (from, to) =>
    (Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000;
  const dated = bands
    .filter((b) => b.start && b.end)
    .sort((a, b) => a.start.localeCompare(b.start));
  const rowEnds = [];
  const used = [];
  const placed = dated.map((b) => {
    let row = rowEnds.findIndex((end) => end < b.start);
    if (row === -1) row = rowEnds.length;
    rowEnds[row] = b.end;
    const left = dayDiff(start, b.start) * dayPx;
    const width = (dayDiff(b.start, b.end) + 1) * dayPx;
    used[row] = [...(used[row] ?? []), [left, left + width]];
    return { key: b.key, row, left, width, top: row * rowPx + 6, inside: "", out: null };
  });
  const free = (row, from, to) => (used[row] ?? []).every(([l, r]) => to + 4 <= l || r + 4 <= from);
  for (const [i, b] of dated.entries()) {
    const p = placed[i];
    const full = b.total > 0 ? `${b.label} ${b.done}/${b.total}` : b.label;
    // 件数まで入らなければ名前だけ帯に入れて件数を外に、名前も入らなければ全部を外に出す
    p.inside =
      textPx(full) + padPx <= p.width ? full : textPx(b.label) + padPx <= p.width ? b.label : "";
    if (p.inside === full) continue;
    const text = p.inside === "" ? full : `${b.done}/${b.total}`;
    const w = textPx(text);
    const right = p.left + p.width + 4;
    let at = free(p.row, right, right + w) ? [right, p.row] : null;
    for (let row = p.row + 1; at === null; row++) {
      if (free(row, p.left, p.left + w)) at = [p.left, row];
    }
    used[at[1]] = [...(used[at[1]] ?? []), [at[0], at[0] + w]];
    p.out = { text, left: at[0], top: at[1] * rowPx + 6 };
  }
  return { bands: placed, rows: Math.max(1, used.length) };
};

// 帯が少ないうちも月の区切りが読めるよう、図は最低 3 か月分(13 週)の幅で描く
const MIN_WEEKS = 13;
// 最後の帯・▼ の右に出す名前が図の外にはみ出さないよう、末尾に 2 週空ける
const TAIL_WEEKS = 2;

/**
 * マイルストーン図の元データ。帯の並びと ▼ は layout(scripts/progress/layout.json)で固定し、帯の日付は帯に当たる課題
 * (機能が一致し、processes があれば工程も一致)の「Start / end の最小 〜 最大」。同じ枠の帯が期間で重なるときだけ段を分ける。
 * ▼ は GitHub の Milestone と照合しない(先方と合意した節目を、リポジトリの運用と切り離して持つため)
 */
export const buildTimeline = (issues, layout, today) => {
  const groups = layout.groups.map((g) => {
    const bands = g.bands.map((b) => {
      const items = b.feature
        ? issues.filter(
            (i) => i.feature === b.feature && (!b.processes || b.processes.includes(i.process)),
          )
        : [];
      const dates = items
        .flatMap((i) => [i.start, i.end])
        .filter(Boolean)
        .sort();
      const done = items.filter(isDone).length;
      // 先方と合意した予定は layout の日付を優先する。課題を作らない予定(外部に頼む診断など)も layout にだけ日付を持つ
      const start = b.start ?? dates[0] ?? null;
      const end = b.end ?? dates.at(-1) ?? null;
      return {
        label: b.label,
        start,
        end,
        total: items.length,
        done,
        state: bandState(start, end, done, items.length, today),
        issues: items.map((i) => i.number),
      };
    });
    return {
      name: g.name,
      tone: g.tone ?? "plain",
      spaceBefore: g.spaceBefore ?? false,
      bands,
    };
  });
  const bands = groups.flatMap((g) => g.bands).filter((b) => b.end !== null);
  // ▼ の進捗は、前の ▼ の翌日からその ▼ までに終わる予定の帯に入っている課題で数える
  const marks = [...layout.milestones]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((m, i, list) => {
      const prev = list[i - 1]?.date ?? "";
      const inRange = bands.filter((b) => prev < b.end && b.end <= m.date);
      return {
        title: m.title,
        date: m.date,
        done: inRange.reduce((sum, b) => sum + b.done, 0),
        total: inRange.reduce((sum, b) => sum + b.total, 0),
        issues: inRange.flatMap((b) => b.issues),
      };
    });
  const dates = [
    today,
    ...groups.flatMap((g) => g.bands.flatMap((b) => [b.start, b.end])).filter(Boolean),
    ...marks.map((m) => m.date),
  ].sort();
  const start = mondayOf(dates[0]);
  const weeksTo = (date) => Math.floor(daysBetween(start, date) / 7) + 1;
  return {
    start,
    // until は ▼ を先の日付へドラッグできるよう、帯・▼ より先まで図を広げておく日
    weeks: Math.max(
      MIN_WEEKS,
      weeksTo(dates.at(-1)) + TAIL_WEEKS,
      layout.until ? weeksTo(layout.until) : 0,
    ),
    groups,
    milestones: marks,
    // 期日を過ぎても課題が残る ▼ は、終わるまで現在のマイルストーンとして出す(遅れが見えるように)。課題の無い ▼(開始の節目など)は飛ばす
    currentMilestone:
      marks.find((m) => m.total > 0 && (m.date >= today || m.done < m.total)) ?? null,
  };
};

/**
 * 予定より先に終わった課題は、先方に見せる進捗では対応中として扱う(合意した予定に合わせて見せるため)。
 * 対象は開始予定が生成した日より後の帯に入る、完了した課題とその子課題
 */
export const holdAhead = (issues, timeline, today) => {
  const ahead = new Set(
    timeline.groups
      .flatMap((g) => g.bands)
      .filter((b) => b.start && today < b.start)
      .flatMap((b) => b.issues),
  );
  return issues.map((i) =>
    ahead.has(i.number) && isDone(i)
      ? {
          ...i,
          status: "In Progress",
          state: "OPEN",
          subIssues: i.subIssues.map((c) => ({ ...c, state: "OPEN" })),
        }
      : i,
  );
};

export const escapeHtml = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch],
  );

const STATUS_LABEL = { todo: "未着手", doing: "対応中", done: "完了" };

/** 状態は画面上で変えられる(打ち合わせ中の見せ方の調整用)。GitHub には書き戻さず、ブラウザにだけ保存する */
const statusClass = (issue) =>
  isDone(issue) ? "done" : issue.status === "In Progress" ? "doing" : "todo";

const statusSelect = (issue) => {
  const cls = statusClass(issue);
  const options = Object.entries(STATUS_LABEL)
    .map(([v, label]) => `<option value="${v}"${v === cls ? " selected" : ""}>${label}</option>`)
    .join("");
  return `<select class="badge status ${cls}" autocomplete="off" data-issue="${issue.number}" data-github="${cls}" aria-label="#${issue.number} の状態">${options}</select>`;
};

/**
 * 画面で状態を変えたときに描き直す数字。data-issues の課題の状態から、ページ内のスクリプトが kind ごとに数え直す
 * (GitHub の状態で描いた値が初期値)
 */
const live = (kind, issues, content, attrs = "") =>
  `<span data-tally="${kind}" data-issues="${issues.join(",")}"${attrs}>${content}</span>`;

const bar = (rate, issues = null) =>
  `<div class="bar" role="img" aria-label="${rate}%"${issues ? ` data-tally="bar" data-issues="${issues.join(",")}"` : ""}><span style="width:${rate}%"></span></div>`;

const doingParen = (n) => (n > 0 ? `(対応中 ${n} 件)` : "");

const issueRow = (i, depth) => {
  const note =
    i.children.length > 0
      ? `<span class="children-count">子課題 ${i.children.filter(isDone).length}/${i.children.length}</span>`
      : "";
  // 1 階層 16px — 3 階層目でも課題名の列幅を圧迫しない幅
  const indent =
    depth > 0 ? `<span class="indent" style="padding-left:${(depth - 1) * 16 + 8}px">└</span>` : "";
  return `
      <tr class="${depth > 0 ? "child" : "parent"}" data-issue="${i.number}" data-end="${i.end ?? ""}">
        <td class="num"><a href="${escapeHtml(i.url)}">#${i.number}</a></td>
        <td class="title">${indent}${escapeHtml(i.title)}${note}</td>
        <td class="feature">${escapeHtml(i.feature ?? "")}</td>
        <td>${statusSelect(i)}</td>
        <td>${escapeHtml((i.assignees ?? []).join(", "))}</td>
      </tr>`;
};

/**
 * 課題一覧のまとまり(上から順に表示)。工程の値で振り分け、工程が空の課題は機能で振り分ける。
 * どれにも当たらない課題は末尾の「その他」に入る
 */
const STAGES = [
  { name: "基本設計", processes: ["基本設計"] },
  { name: "詳細設計", processes: ["画面設計", "詳細設計"] },
  { name: "フロントエンド開発", processes: ["フロントエンド開発"] },
  // 工程が「開発」の課題は API・DB の開発なので、バックエンド開発に入れる
  { name: "バックエンド開発", processes: ["バックエンド開発", "開発"] },
  {
    name: "テスト",
    processes: ["内部結合テスト", "テスト"],
    features: ["テスト計画", "総合テスト", "UAT", "脆弱性診断準備"],
  },
];
const OTHER_STAGE = "その他";

export const stageOf = (node) => {
  const byProcess = (n) => STAGES.find((s) => s.processes?.includes(n.process))?.name;
  const byFeature = (n) => STAGES.find((s) => s.features?.includes(n.feature))?.name;
  const descendants = flattenTree(node.children ?? []).map(({ node: n }) => n);
  return (
    byProcess(node) ??
    descendants.map(byProcess).find(Boolean) ??
    byFeature(node) ??
    descendants.map(byFeature).find(Boolean) ??
    OTHER_STAGE
  );
};

export const groupByStage = (tree) => {
  const groups = Map.groupBy(tree, stageOf);
  return [...STAGES.map((s) => s.name), OTHER_STAGE]
    .filter((name) => groups.has(name))
    .map((name) => {
      const nodes = flattenTree(groups.get(name)).map(({ node }) => node);
      const dates = nodes
        .flatMap((n) => [n.start, n.end])
        .filter(Boolean)
        .sort();
      return {
        name,
        tree: groups.get(name),
        start: dates[0] ?? null,
        end: dates.at(-1) ?? null,
        total: nodes.length,
        done: nodes.filter(isDone).length,
        inProgress: nodes.filter((n) => !isDone(n) && n.status === "In Progress").length,
        issues: nodes.map((n) => n.number),
      };
    });
};

const issueTable = (tree) => {
  if (tree.length === 0) return '<p class="empty">課題管理表に課題がまだありません。</p>';
  const stages = groupByStage(tree);
  // 最初から開くのは、終わっていない最初のまとまり(今やっている工程)だけ
  const openIndex = stages.findIndex((s) => s.done < s.total);
  return stages
    .map((s, i) => {
      const rows = flattenTree(s.tree).map(({ node, depth }) => issueRow(node, depth));
      const rate = ratio(s.done, s.total);
      const period = s.start
        ? `<span class="stage-period">予定 ${md(s.start)}〜${md(s.end)}</span>`
        : "";
      return `
    <details class="stage"${i === openIndex ? " open" : ""}>
      <summary><span class="stage-name">${escapeHtml(s.name)}</span><span class="stage-count">完了 ${live("done", s.issues, s.done)} / ${s.total} 件${live("doing-paren", s.issues, doingParen(s.inProgress))}</span>${period}<span class="stage-bar">${bar(rate, s.issues)}</span></summary>
      <div class="table-wrap"><table class="issues">
        <thead><tr><th>No.</th><th>課題</th><th>機能</th><th>状態</th><th>担当</th></tr></thead>
        <tbody>${rows.join("")}
        </tbody>
      </table></div>
    </details>
    <ul class="stage-late print-only"></ul>`;
    })
    .join("");
};

const md = (date) => `${Number(date.slice(5, 7))}/${Number(date.slice(8, 10))}`;

// 1 週 56px — 2 週(営業日 12 日)の帯に「詳細設計 12/34」まで収まり、半年(約 26 週)でも横スクロールが 1 画面強で済む幅
const WEEK_PX = 56;
const DAY_PX = WEEK_PX / 7;
const LANE_LABEL_PX = 170;
const BAND_ROW_PX = 26;
const MARK_ROW_PX = 20;
// 年・月・週の見出し 3 行(各 24px)。▼ の破線はその下から引く
const HEAD_PX = 3 * 24;
// CSS の .tl-band の左右の padding(4px + 矢印の先を含む 10px)と合わせる
const BAND_PAD_PX = 14;
// 日本語 1 文字 ≒ 13px(12px のフォント + 字間)。▼ の見出しが重ならないよう段を分ける目安
const MARK_CHAR_PX = 13;

const BAND_STATE = {
  done: "完了",
  current: "進行中",
  late: "予定超過",
  upcoming: "予定",
};

const spans = (weeks, keyOf) => {
  const out = [];
  weeks.forEach((w, i) => {
    const key = keyOf(w);
    if (out.at(-1)?.key === key) out.at(-1).count++;
    else out.push({ key, index: i, count: 1 });
  });
  return out;
};

const untilDue = (date, today) => {
  const days = daysBetween(today, date);
  return days > 0 ? `あと ${days} 日` : days === 0 ? "今日が期日" : `期日を ${-days} 日超過`;
};

// 工程ごとの進行中・予定超過は図の帯の色で読めるので、図の上には現在のマイルストーンだけを出す
const timelineStatus = (t, today) => {
  const m = t.currentMilestone;
  return m
    ? `<ul class="now"><li class="now-milestone"><span class="badge ${m.date < today ? "late" : "todo"}" data-milestone-badge>現在のマイルストーン</span> ▼${escapeHtml(m.title)}(<span data-milestone-date>${md(m.date)}</span>、<span data-milestone-until>${untilDue(m.date, today)}</span>)</li></ul>`
    : "";
};

export const bandKey = (group, band) => `${group.name}/${band.label}`;

const bandAttrs = (g, b) =>
  `data-key="${escapeHtml(bandKey(g, b))}" data-group="${escapeHtml(g.name)}" data-label="${escapeHtml(b.label)}" data-start="${b.start ?? ""}" data-end="${b.end ?? ""}" data-issues="${b.issues.join(",")}"`;

export const renderTimeline = (t, today) => {
  if (!t) return '<p class="empty">マイルストーン図のデータがありません。</p>';
  const weeks = Array.from({ length: t.weeks }, (_, i) => addDays(t.start, i * 7));
  const width = t.weeks * WEEK_PX;
  const x = (date) => daysBetween(t.start, date) * DAY_PX;
  const cell = (s, text, cls = "", attrs = "") =>
    `<div class="tl-cell ${cls}"${attrs} style="left:${s.index * WEEK_PX}px;width:${s.count * WEEK_PX}px">${text}</div>`;
  const thisWeek = mondayOf(today);
  const header = [
    ["tl-year", spans(weeks, (w) => w.slice(0, 4)).map((s) => cell(s, `${s.key}年`))],
    [
      "tl-month",
      spans(weeks, (w) => w.slice(0, 7)).map((s) => cell(s, `${Number(s.key.slice(5))}月`)),
    ],
    [
      "tl-week",
      weeks.map((w, index) =>
        cell(
          { index, count: 1 },
          String(Number(w.slice(8))),
          w === thisWeek ? "this-week" : "",
          ` data-week="${w}"`,
        ),
      ),
    ],
  ]
    .map(
      ([cls, cells]) =>
        `<div class="tl-row ${cls}"><div class="tl-label"></div><div class="tl-track" style="width:${width}px">${cells.join("")}</div></div>`,
    )
    .join("");

  const laidMarks = layoutMarks(t.milestones, {
    start: t.start,
    dayPx: DAY_PX,
    rowPx: MARK_ROW_PX,
    charPx: MARK_CHAR_PX,
  });
  const marks = laidMarks.marks.map((p) => {
    const m = t.milestones.find((x) => x.title === p.title);
    return `<div class="tl-mark${m.date < today ? " past" : ""}" data-title="${escapeHtml(m.title)}" data-date="${m.date}" data-default-date="${m.date}" style="left:${p.left}px;top:${p.top}px" title="${escapeHtml(m.title)} ${m.date}">${escapeHtml(p.text)}</div>`;
  });
  const markLines = laidMarks.marks
    .map(
      (p) =>
        `<div class="tl-mark-line" data-title="${escapeHtml(p.title)}" style="left:${LANE_LABEL_PX + p.left + 6}px;top:${HEAD_PX}px"></div>`,
    )
    .join("");
  const markRow =
    marks.length > 0
      ? `<div class="tl-row tl-marks"><div class="tl-label">マイルストーン</div><div class="tl-track" style="width:${width}px;height:${laidMarks.rows * MARK_ROW_PX + 8}px">${marks.join("")}</div></div>`
      : "";

  const groups = t.groups
    .map((g) => {
      const laid = layoutBands(
        g.bands.map((b) => ({ ...b, key: bandKey(g, b) })),
        { start: t.start, dayPx: DAY_PX, rowPx: BAND_ROW_PX, padPx: BAND_PAD_PX },
      );
      const placed = new Map(laid.bands.map((p) => [p.key, p]));
      const bands = g.bands
        .map((b) => {
          const p = placed.get(bandKey(g, b));
          if (!p)
            return `<div class="tl-band unscheduled" ${bandAttrs(g, b)} hidden><span></span></div>`;
          const tip = `${escapeHtml(b.label)} ${b.start}〜${b.end}`;
          const band = `<div class="tl-band ${b.state}" ${bandAttrs(g, b)} style="left:${p.left}px;width:${p.width}px;top:${p.top}px;--rate:${ratio(b.done, b.total)}%" title="${tip}"><span>${escapeHtml(p.inside)}</span></div>`;
          return p.out
            ? `${band}<div class="tl-band-out ${b.state}" data-band-out style="left:${p.out.left}px;top:${p.out.top}px" title="${tip}">${escapeHtml(p.out.text)}</div>`
            : band;
        })
        .join("");
      const rows = laid.rows;
      const unscheduled = g.bands.filter((b) => b.start === null);
      const note =
        unscheduled.length > 0
          ? `日付未設定: ${unscheduled.map((b) => escapeHtml(b.label)).join("・")}`
          : "";
      return `<div class="tl-row tl-group tone-${escapeHtml(g.tone)}${g.spaceBefore ? " space-before" : ""}"><div class="tl-label"><div class="tl-group-name">${escapeHtml(g.name)}</div><div class="tl-note">${note}</div></div><div class="tl-track" style="width:${width}px;min-height:${rows * BAND_ROW_PX + 12}px">${bands}</div></div>`;
    })
    .join("");

  const todayX = LANE_LABEL_PX + x(today) + DAY_PX / 2;
  return `${timelineStatus(t, today)}
    <div class="tl-scroll" data-today-x="${todayX}" data-start="${t.start}" data-day-px="${DAY_PX}" data-label-px="${LANE_LABEL_PX}" data-days="${t.weeks * 7}">
      <div class="tl" style="width:${LANE_LABEL_PX + width}px;--week:${WEEK_PX}px">
        ${header}${markRow}${groups}
        <div class="tl-row tl-foot"><div class="tl-label"></div><div class="tl-track" style="width:${width}px"></div></div>
        ${markLines}
        <div class="tl-today" style="left:${todayX}px" data-today="${today}"><span>今日 ${md(today)}</span></div>
      </div>
    </div>
    <div class="tl-legend">${Object.entries(BAND_STATE)
      .map(([k, v]) => `<span><i class="tl-band ${k}"></i>${v}</span>`)
      .join(
        "",
      )}<span class="muted">帯 = 課題の Start〜end(数字は完了 / 全件、帯の左から緑に塗った長さが完了率)。並びは scripts/progress/layout.json。▼ = 節目(layout.json)</span></div>`;
};

/**
 * 帯ごとの予定。開始予定・完了予定は画面の日付でも図の帯のドラッグでも変えられ、両方に反映する(ブラウザにだけ保存)。
 * 初期値は課題の Start / end から求めた帯の期間
 */
const bandTable = (t, today) => {
  const rows = t.groups.flatMap((g) =>
    g.bands.map((b, i) => {
      const key = escapeHtml(bandKey(g, b));
      const rate = ratio(b.done, b.total);
      const input = (edge, value) =>
        `<input type="date" class="band-date" data-band="${key}" data-edge="${edge}" value="${value ?? ""}" autocomplete="off" aria-label="${escapeHtml(`${g.name} ${b.label} の${edge === "start" ? "開始" : "完了"}予定`)}">`;
      const overdue = b.end !== null && b.end < today && b.done < b.total;
      return `<tr${i === 0 ? ' class="group-first"' : ""}><td>${i === 0 ? escapeHtml(g.name) : ""}</td><td>${escapeHtml(b.label)}</td><td>${input("start", b.start)}</td><td>${input("end", b.end)} ${live("overdue", b.issues, "予定超過", ` class="badge late" data-band="${key}"${overdue ? "" : " hidden"}`)}</td>${b.total > 0 ? `<td class="right">${live("done", b.issues, b.done)} / ${b.total}</td><td>${live("rate", b.issues, `${rate}%`)}${bar(rate, b.issues)}</td>` : '<td class="right muted">—</td><td class="muted">課題なし</td>'}</tr>`;
    }),
  );
  return `<div class="table-wrap"><table class="bands" style="margin-top:16px">
      <thead><tr><th>機能</th><th>工程</th><th>開始予定</th><th>完了予定</th><th class="right">完了 / 全件</th><th style="width:22%">完了率</th></tr></thead>
      <tbody>${rows.join("")}</tbody>
    </table></div>`;
};

const kpi = (label, value, sub) =>
  `<div class="kpi"><div class="label">${label}</div><div class="value">${value}</div><div class="note">${sub}</div></div>`;

export const renderHtml = ({
  today,
  summary,
  tree,
  projectUrl,
  timeline = null,
  systemName = "J-クレジット創出システム",
}) => {
  const { all } = summary;
  const milestone = timeline?.currentMilestone ?? null;
  const milestoneRate = milestone ? ratio(milestone.done, milestone.total) : 0;
  const title = `${systemName} 進捗報告 ${today}`;
  const issueData = Object.fromEntries(
    flattenTree(tree).map(({ node }) => [
      node.number,
      { s: statusClass(node), t: node.title, u: node.url, b: node.body ?? "" },
    ]),
  );
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>
  :root { --fg:#1f2328; --muted:#656d76; --line:#d0d7de; --bg:#fff; --soft:#f6f8fa; --accent:#0969da; --done:#1a7f37; --doing:#9a6700; }
  * { box-sizing: border-box; }
  /* .badge などの display 指定が hidden 属性より強く、隠したい要素が出てしまうため */
  [hidden] { display:none !important; }
  body { margin:0; background:var(--soft); color:var(--fg); font:14px/1.6 "Hiragino Sans","Noto Sans JP",system-ui,sans-serif; }
  main { max-width:1440px; margin:0 auto; padding:24px 16px 48px; }
  .layout { display:grid; grid-template-columns:minmax(0,1fr) 380px; gap:16px; align-items:start; }
  .notes { position:sticky; top:16px; max-height:calc(100vh - 32px); overflow-y:auto; }
  .notes section { padding:12px; margin-bottom:12px; }
  .notes .editable { min-height:96px; }
  .layout.notes-closed { grid-template-columns:minmax(0,1fr); }
  .layout.notes-closed .notes { display:none; }
  @media (max-width:1100px) {
    .layout { grid-template-columns:minmax(0,1fr); }
    .notes { position:static; max-height:none; overflow:visible; }
  }
  header { display:flex; justify-content:space-between; align-items:flex-end; gap:16px; flex-wrap:wrap; margin-bottom:16px; }
  h1 { font-size:22px; margin:0; }
  h2 { font-size:16px; margin:0 0 12px; padding-left:8px; border-left:4px solid var(--accent); }
  .meta { color:var(--muted); font-size:12px; }
  .as-of input { font:inherit; color:inherit; border:1px solid transparent; border-radius:4px; background:transparent; padding:0 2px; cursor:pointer; width:7.4em; }
  .as-of input:hover, .as-of input:focus { border-color:var(--line); outline:none; }
  .as-of input::-webkit-calendar-picker-indicator { display:none; }
  section { background:var(--bg); border:1px solid var(--line); border-radius:8px; padding:16px; margin-bottom:16px; }
  .actions { display:flex; gap:8px; }
  button { font:inherit; cursor:pointer; border:1px solid var(--line); background:var(--bg); border-radius:6px; padding:6px 12px; }
  button.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
  button.danger { color:#cf222e; }
  .footer-actions { display:flex; justify-content:flex-end; }
  .kpis { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:12px; }
  .kpi { border:1px solid var(--line); border-radius:6px; padding:12px; }
  .kpi .label { color:var(--muted); font-size:12px; }
  .kpi .value { font-size:26px; font-weight:700; }
  .kpi .note { color:var(--muted); font-size:12px; }
  .bar { height:8px; background:var(--soft); border-radius:4px; overflow:hidden; margin-top:6px; }
  .bar span { display:block; height:100%; background:var(--done); }
  table { width:100%; border-collapse:collapse; }
  th, td { text-align:left; padding:6px 8px; border-bottom:1px solid var(--line); vertical-align:top; }
  th { background:var(--soft); font-size:12px; color:var(--muted); font-weight:600; }
  .right { text-align:right; }
  .num a { color:var(--accent); text-decoration:none; }
  tr.parent td { font-weight:600; }
  tr.child td { font-weight:400; }
  .indent { color:var(--muted); margin-right:6px; }
  td.feature { white-space:nowrap; font-size:12px; font-weight:400; color:var(--muted); }
  .children-count { margin-left:8px; color:var(--muted); font-size:12px; font-weight:400; }
  .badge { display:inline-block; padding:0 8px; border-radius:10px; font-size:12px; font-weight:600; white-space:nowrap; }
  .badge.done { background:#dafbe1; color:var(--done); }
  .badge.doing { background:#fff8c5; color:var(--doing); }
  .badge.todo { background:var(--soft); color:var(--muted); }
  select.status { font:inherit; font-size:12px; font-weight:600; border:1px solid transparent; cursor:pointer; padding:1px 6px; appearance:none; -webkit-appearance:none; text-align:center; }
  select.status:hover, select.status:focus { border-color:var(--line); outline:none; }
  details.stage { border:1px solid var(--line); border-radius:6px; margin-bottom:8px; }
  details.stage > summary { display:flex; align-items:center; gap:12px; padding:8px 12px; cursor:pointer; background:var(--soft); border-radius:6px; list-style:none; }
  details.stage > summary::-webkit-details-marker { display:none; }
  details.stage > summary::before { content:"▶"; font-size:10px; color:var(--muted); transition:transform .15s; }
  details.stage[open] > summary::before { transform:rotate(90deg); }
  details.stage[open] > summary { border-bottom:1px solid var(--line); border-radius:6px 6px 0 0; }
  .stage-name { font-weight:700; min-width:80px; }
  .stage-count { color:var(--muted); font-size:12px; }
  .stage-period { color:var(--muted); font-size:12px; }
  .print-only { display:none; }
  .stage-late { margin:-4px 0 8px; padding:4px 12px 4px 28px; font-size:11px; }
  .stage-bar { flex:1; max-width:200px; }
  .stage-bar .bar { margin-top:0; }
  table.bands tr.group-first td { border-top:2px solid var(--line); }
  table.bands td:first-child { font-weight:600; white-space:nowrap; }
  .band-date { font:inherit; color:inherit; border:1px solid transparent; border-radius:4px; background:transparent; padding:0 2px; cursor:pointer; width:7.4em; }
  .band-date:hover, .band-date:focus { border-color:var(--line); outline:none; }
  .band-date::-webkit-calendar-picker-indicator { display:none; }
  .badge.late { background:#ffebe9; color:#cf222e; }
  .muted { color:var(--muted); }
  .empty { color:var(--muted); margin:0; }
  .editable { min-height:72px; border:1px dashed var(--line); border-radius:6px; padding:8px; white-space:pre-wrap; outline:none; }
  .editable:focus, td[contenteditable]:focus { border-color:var(--accent); background:#f5f9ff; }
  .editable:empty::before { content:attr(data-placeholder); color:var(--muted); }
  td[contenteditable] { outline:none; min-width:60px; }
  .row-actions { margin-top:8px; }
  .del { border:none; background:none; color:var(--muted); padding:0 4px; }
  .table-wrap { overflow-x:auto; }
  .topic { border:1px solid var(--line); border-radius:6px; margin-bottom:8px; }
  .topic-head { display:flex; align-items:center; gap:8px; padding:6px 12px; background:var(--soft); border-bottom:1px solid var(--line); border-radius:6px 6px 0 0; font-weight:600; }
  .topic-head .topic-title { flex:1; outline:none; }
  .topic-head .topic-title[contenteditable]:empty::before { content:"議題のタイトル"; color:var(--muted); font-weight:400; }
  .topic-body { display:grid; grid-template-columns:1fr 1fr; gap:12px; padding:8px 12px 12px; }
  details.topic-issue { margin:8px 12px 0; border:1px solid var(--line); border-radius:6px; }
  details.topic-issue > summary { padding:4px 8px; cursor:pointer; font-size:12px; color:var(--muted); }
  details.topic-issue[open] > summary { border-bottom:1px solid var(--line); }
  .topic-issue-body { padding:6px 10px; font-size:13px; white-space:pre-wrap; max-height:320px; overflow-y:auto; }
  .topic-issue-body:empty { display:none; }
  .topic-issue-body .md-h { font-weight:700; margin-top:6px; }
  .topic-issue-body .md-h:first-child { margin-top:0; }
  .topic-label { font-size:12px; color:var(--muted); margin-bottom:4px; }
  .topic .editable { min-height:56px; }
  @media (max-width:700px) { .topic-body { grid-template-columns:1fr; } }
  .topic-add { display:flex; gap:8px; }
  .topic-add input { flex:1; max-width:480px; font:inherit; border:1px solid var(--line); border-radius:6px; padding:6px 8px; }
  .now { list-style:none; margin:0 0 12px; padding:0; display:flex; flex-direction:column; gap:4px; }
  .tl-scroll { overflow-x:auto; border:1px solid var(--line); border-radius:6px; }
  .tl { position:relative; font-size:12px; }
  .tl-row { display:flex; border-bottom:1px solid var(--line); }
  .tl-label { position:sticky; left:0; z-index:3; flex:0 0 ${LANE_LABEL_PX}px; padding:4px 8px; background:var(--bg); border-right:1px solid var(--line); font-weight:600; }
  .tl-track { position:relative; flex:none; background-image:linear-gradient(to right, var(--line) 1px, transparent 1px); background-size:var(--week) 100%; }
  .tl-year, .tl-month, .tl-week { height:24px; }
  .tl-year .tl-label, .tl-month .tl-label, .tl-week .tl-label { background:#3f3d8f; border-right-color:#5c5aa8; }
  .tl-year .tl-track, .tl-month .tl-track, .tl-week .tl-track { background:#3f3d8f; color:#fff; }
  .tl-cell { position:absolute; top:0; height:100%; line-height:24px; padding-left:6px; border-left:1px solid #5c5aa8; white-space:nowrap; overflow:hidden; }
  .tl-week .tl-cell { padding-left:0; text-align:center; }
  .tl-cell.this-week { background:#cf222e; font-weight:700; }
  .tl-mark { position:absolute; white-space:nowrap; font-weight:600; line-height:${MARK_ROW_PX}px; cursor:grab; user-select:none; touch-action:none; }
  .tl-mark.past { color:var(--muted); font-weight:400; }
  .tl-mark-line { position:absolute; bottom:0; width:0; border-left:1px dashed #7d7ac4; z-index:1; pointer-events:none; }
  .tl-today { position:absolute; top:0; bottom:0; width:0; border-left:2px solid #cf222e; z-index:2; pointer-events:none; }
  .tl-today span { position:absolute; bottom:0; left:-2px; background:#cf222e; color:#fff; font-size:11px; font-weight:700; padding:0 6px; border-radius:0 4px 0 0; white-space:nowrap; line-height:20px; }
  .tl-foot { height:20px; border-bottom:none; }
  .tl-marks .tl-label { font-size:12px; }
  .tl-group { margin-top:4px; border:1px solid var(--group-line, var(--line)); background:var(--group-bg, var(--bg)); }
  .tl-group .tl-label { background:var(--group-bg, var(--bg)); border-right-color:var(--group-line, var(--line)); display:flex; flex-direction:column; justify-content:flex-end; padding:6px 10px; }
  .tl-group .tl-track { background-image:linear-gradient(to right, rgba(0,0,0,.08) 1px, transparent 1px); }
  .tl-group.space-before { margin-top:16px; }
  .tone-app { --group-bg:#f6d9da; --group-line:#5b3f99; }
  .tone-api { --group-bg:#dfe2f7; --group-line:#5b5fc7; }
  .tone-test { --group-bg:#fdefd2; --group-line:#b7862c; }
  .tone-plain { --group-bg:var(--bg); --group-line:var(--line); }
  .tl-group-name { font-size:15px; font-weight:800; }
  .tl-note { font-size:11px; font-weight:400; color:var(--muted); margin-top:2px; }
  .tl-band { --band-done:#9fd8ab; --band-fill:#fdf8e4; --band-text:#3d3418; position:absolute; isolation:isolate; height:${BAND_ROW_PX - 6}px; line-height:${BAND_ROW_PX - 6}px; padding:0 10px 0 4px; white-space:nowrap; overflow:hidden; text-align:center; font-size:12px; color:var(--band-text); background:#8a8466; clip-path:polygon(0 0, calc(100% - 8px) 0, 100% 50%, calc(100% - 8px) 100%, 0 100%); }
  .tl-band::before { content:""; position:absolute; inset:1px; z-index:-1; background:linear-gradient(to right, var(--band-done) var(--rate, 0%), var(--band-fill) var(--rate, 0%)); clip-path:polygon(0 0, calc(100% - 8px) 0, 100% 50%, calc(100% - 8px) 100%, 0 100%); }
  .tl-band.current { --band-fill:#c9e6ff; --band-text:#0a3069; font-weight:700; background:#0969da; }
  .tl-band.done { --band-fill:#d3f0d9; --band-text:#11552a; background:#4a9a5f; }
  .tl-band.late { --band-fill:#ffd8d3; --band-text:#82071e; font-weight:700; background:#cf222e; }
  .tl-band[data-key] { touch-action:none; user-select:none; -webkit-user-select:none; }
  .tl-band-out { position:absolute; line-height:${BAND_ROW_PX - 6}px; font-size:11px; white-space:nowrap; }
  .tl-band-out.current, .tl-band-out.late { font-weight:700; }
  .tl-band-out.late { color:#82071e; }
  .tl-legend { display:flex; flex-wrap:wrap; gap:6px 16px; margin-top:8px; font-size:12px; align-items:center; }
  .tl-legend i.tl-band { position:relative; display:inline-block; width:32px; height:14px; padding:0; margin-right:4px; vertical-align:-2px; }
  @media print {
    @page { size:A4; margin:12mm; }
    body { background:#fff; font-size:11px; }
    main { max-width:none; padding:0; }
    .layout { display:block; }
    .layout.notes-closed .notes { display:block; }
    .notes { position:static; max-height:none; overflow:visible; }
    .tl-scroll { overflow:visible; border:none; }
    .tl-label { position:static; }
    section { break-inside:avoid; border-color:#bbb; }
    section.issues-section { break-inside:auto; }
    tr, .topic { break-inside:avoid; }
    .no-print, .del, .row-actions { display:none !important; }
    .editable { border:none; padding:0; min-height:0; }
    .topic-issue-body { max-height:none; overflow:visible; }
    .editable:empty::before { content:"(記載なし)"; }
    details.stage > :not(summary) { display:none; }
    details.stage > summary::before { content:none; }
    details.stage[open] > summary { border-bottom:none; border-radius:6px; }
    .stage-late:not(:empty) { display:block; }
    .num a { color:var(--fg); }
    * { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  }
</style>
</head>
<body>
<main>
  <header>
    <div>
      <h1>${escapeHtml(systemName)} 進捗報告</h1>
      <div class="meta"><label class="as-of" title="クリックで日付を変える"><input type="date" id="as-of" value="${today}" autocomplete="off"> 時点</label>${projectUrl ? ` / <a class="no-print" href="${escapeHtml(projectUrl)}">課題管理表</a>` : ""}</div>
    </div>
    <div class="actions no-print">
      <button type="button" id="toggle-notes" aria-controls="notes" aria-expanded="true">決定事項・宿題・メモをしまう</button>
      <button type="button" id="save-html" title="画面で変えた状態・予定日・入力を入れた HTML を保存する(他の人に渡すとき用)">この状態で保存</button>
      <button type="button" class="primary" id="pdf">PDF 出力</button>
    </div>
  </header>

  <div class="layout">
  <div class="content">
  <section>
    <h2>マイルストーン(現在地)</h2>
    ${renderTimeline(timeline, today)}
  </section>

  <section>
    <h2>進捗サマリ</h2>
    <div class="kpis">
      ${kpi("全体の完了率", live("rate", all.issues, `${all.rate}%`), `完了 ${live("done", all.issues, all.done)} / 全 ${all.total} 件${live("doing-paren", all.issues, doingParen(all.inProgress))}${bar(all.rate, all.issues)}`)}
      ${
        milestone
          ? kpi(
              `現在のマイルストーン(▼${escapeHtml(milestone.title)} <span data-milestone-date>${md(milestone.date)}</span>)`,
              live("rate", milestone.issues, `${milestoneRate}%`, " data-milestone-kpi"),
              `完了 ${live("done", milestone.issues, milestone.done, " data-milestone-kpi")} / 全 ${live("total", milestone.issues, milestone.total, " data-milestone-kpi")} 件 / <span data-milestone-until>${untilDue(milestone.date, today)}</span>${bar(milestoneRate, milestone.issues).replace("<div ", `<div data-milestone-kpi="${escapeHtml(milestone.title)}" `)}`,
            )
          : kpi("現在のマイルストーン", "—", "課題の入った ▼ がありません")
      }
    </div>
    ${timeline ? bandTable(timeline, today) : ""}
  </section>

  <section class="issues-section">
    <h2>課題一覧(親子課題)</h2>
    ${issueTable(tree)}
  </section>

  <section>
    <h2>議題</h2>
    <div id="topics"></div>
    <p class="empty" id="topics-empty">議題はありません。</p>
    <div class="row-actions topic-add no-print">
      <input type="text" id="topic-pick" list="topic-options" placeholder="#番号 またはタイトル" autocomplete="off" aria-label="追加する議題">
      <datalist id="topic-options">${flattenTree(tree)
        .map(
          ({ node }) => `<option value="${escapeHtml(`#${node.number} ${node.title}`)}"></option>`,
        )
        .join("")}</datalist>
      <button type="button" id="add-topic">+ 議題を追加</button>
    </div>
  </section>
  </div>

  <aside class="notes" id="notes">
  <section>
    <h2>決定事項</h2>
    <div class="editable" contenteditable="true" data-key="decisions" data-placeholder="ここに決定事項を記入(1 行 1 件)"></div>
  </section>

  <section>
    <h2>宿題</h2>
    <div class="table-wrap"><table id="homework">
      <thead><tr><th style="width:55%">内容</th><th>担当</th><th>期限</th><th class="no-print"></th></tr></thead>
      <tbody></tbody>
    </table></div>
    <div class="row-actions"><button type="button" id="add-homework">+ 行を追加</button></div>
  </section>

  <section>
    <h2>メモ</h2>
    <div class="editable" contenteditable="true" data-key="memo" data-placeholder="打ち合わせのメモを記入"></div>
  </section>

  <div class="footer-actions no-print">
    <button type="button" class="danger" id="clear">入力をすべてクリア</button>
  </div>
  </aside>
  </div>
</main>
<script type="application/json" id="milestone-data">${JSON.stringify({ current: timeline?.currentMilestone?.title ?? null, list: (timeline?.milestones ?? []).map((m) => ({ title: m.title, date: m.date })) }).replace(/</g, "\\u003c")}</script>
<script type="application/json" id="issue-data">${JSON.stringify(issueData).replace(/</g, "\\u003c")}</script>
<script type="application/json" id="saved-state">null</script>
<script>
(() => {
  // 「この状態で保存」で書き出すのは、スクリプトが DOM を書き換える前のページ(開き直したときに二重に描かないように)
  const ORIGINAL = "<!doctype html>" + document.documentElement.outerHTML;
  const SAVED_TAG = '<script type="application/json" id="saved-state">';
  const SAVED = JSON.parse(document.getElementById("saved-state").textContent);
  // 渡されたファイルは保存した時刻ごとに別のキーにする(同じ日の報告を自分で触った状態に上書きされないように)
  const KEY = ${JSON.stringify(`jcredit-progress:${today}`)} + (SAVED ? ":" + SAVED.savedAt : "");
  const load = () => {
    try { return JSON.parse(localStorage.getItem(KEY)) || SAVED?.state || {}; } catch { return SAVED?.state || {}; }
  };
  const state = load();
  const save = () => {
    state.homework = [...document.querySelectorAll("#homework tbody tr")].map((tr) =>
      [...tr.querySelectorAll("td[contenteditable]")].map((td) => td.innerText.trim()));
    for (const el of document.querySelectorAll(".editable[data-key]")) state[el.dataset.key] = el.innerText.replace(/\\n$/, "");
    state.topics = [...document.querySelectorAll("#topics .topic")].map((el) => ({
      n: el.dataset.issue || null,
      title: el.dataset.issue ? "" : el.querySelector(".topic-title").innerText.trim(),
      discuss: el.querySelector('[data-field="discuss"]').innerText.replace(/\\n$/, ""),
      decided: el.querySelector('[data-field="decided"]').innerText.replace(/\\n$/, ""),
      open: el.querySelector(".topic-issue")?.open ?? true,
    }));
    state.asOf = asOf.value;
    state.bands = {};
    for (const input of document.querySelectorAll(".band-date")) {
      if (input.value === input.defaultValue) continue;
      state.bands[input.dataset.band] = { ...state.bands[input.dataset.band], [input.dataset.edge]: input.value };
    }
    state.milestones = {};
    for (const el of document.querySelectorAll(".tl-mark[data-title]")) {
      if (el.dataset.date !== el.dataset.defaultDate) state.milestones[el.dataset.title] = el.dataset.date;
    }
    state.status = {};
    for (const el of document.querySelectorAll("select.status")) {
      if (el.value !== el.dataset.github) state.status[el.dataset.issue] = el.value;
    }
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  };
  const addRow = (cells = ["", "", ""]) => {
    const tr = document.createElement("tr");
    for (const v of cells) {
      const td = document.createElement("td");
      td.contentEditable = "true";
      td.innerText = v;
      tr.append(td);
    }
    const del = document.createElement("td");
    del.className = "no-print";
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "del";
    btn.textContent = "×";
    btn.setAttribute("aria-label", "この行を削除");
    btn.onclick = () => { tr.remove(); save(); };
    del.append(btn);
    tr.append(del);
    document.querySelector("#homework tbody").append(tr);
    return tr;
  };
  for (const el of document.querySelectorAll(".editable[data-key]")) el.innerText = state[el.dataset.key] || "";
  const paintStatus = (el) => {
    el.classList.remove("todo", "doing", "done");
    el.classList.add(el.value);
  };
  // 「〇〇 時点」は打ち合わせの日に合わせて変えられる(見出し・PDF のファイル名・今日の縦線に効く。集計は生成日のまま)
  const asOf = document.getElementById("as-of");
  const TITLE_PREFIX = ${JSON.stringify(`${systemName} 進捗報告 `)};
  const DAY_MS = 86400000;
  // 時点を変えたら、今日の縦線と見出しの赤い週も動かす(帯の色・予定超過の判定は生成した日のまま)
  const moveToday = () => {
    const sc = document.querySelector(".tl-scroll");
    const line = sc?.querySelector(".tl-today");
    if (!line) return;
    const date = new Date(asOf.value + "T00:00:00Z");
    const days = (date - new Date(sc.dataset.start + "T00:00:00Z")) / DAY_MS;
    const dayPx = Number(sc.dataset.dayPx);
    const x = Number(sc.dataset.labelPx) + days * dayPx + dayPx / 2;
    line.style.left = x + "px";
    line.hidden = days < 0 || days >= Number(sc.dataset.days);
    const md = date.getUTCMonth() + 1 + "/" + date.getUTCDate();
    line.firstElementChild.textContent = (asOf.value === line.dataset.today ? "今日 " : "") + md;
    const monday = new Date(date - ((date.getUTCDay() + 6) % 7) * DAY_MS).toISOString().slice(0, 10);
    for (const cell of sc.querySelectorAll("[data-week]")) cell.classList.toggle("this-week", cell.dataset.week === monday);
    sc.dataset.todayX = String(x);
  };
  const paintAsOf = () => {
    document.title = TITLE_PREFIX + asOf.value;
    moveToday();
  };
  if (state.asOf) asOf.value = state.asOf;
  paintAsOf();
  asOf.addEventListener("click", () => asOf.showPicker?.());
  asOf.addEventListener("change", () => {
    if (!asOf.value) asOf.value = ${JSON.stringify(today)};
    paintAsOf();
    save();
  });
  const ISSUES = JSON.parse(document.getElementById("issue-data").textContent);
  const statusEls = new Map([...document.querySelectorAll("select.status")].map((el) => [el.dataset.issue, el]));
  const statusOf = (n) => statusEls.get(n)?.value ?? ISSUES[n]?.s ?? "todo";
  const tally = (el) => {
    const ids = el.dataset.issues ? el.dataset.issues.split(",") : [];
    const done = ids.filter((n) => statusOf(n) === "done");
    return {
      total: ids.length,
      done: done.length,
      doing: ids.filter((n) => statusOf(n) === "doing").length,
    };
  };
  const pct = (t) => (t.total === 0 ? 0 : Math.round((t.done / t.total) * 100));
  const sc = document.querySelector(".tl-scroll");
  const MILESTONES = JSON.parse(document.getElementById("milestone-data").textContent);
  const GEN_TODAY = ${JSON.stringify(today)};
  const bandState = ${bandState.toString()};
  const layoutBands = ${layoutBands.toString()};
  const layoutMarks = ${layoutMarks.toString()};
  const shortDate = (d) => Number(d.slice(5, 7)) + "/" + Number(d.slice(8, 10));
  const allBands = () => [...document.querySelectorAll(".tl-band[data-key]")];
  const bandByKey = (key) => allBands().find((b) => b.dataset.key === key);
  const layoutGroup = (track) => {
    for (const out of track.querySelectorAll("[data-band-out]")) out.remove();
    const bands = [...track.querySelectorAll(".tl-band[data-key]")];
    const input = bands.map((b) => ({ key: b.dataset.key, label: b.dataset.label, start: b.dataset.start, end: b.dataset.end, ...tally(b) }));
    const laid = layoutBands(input, { start: sc.dataset.start, dayPx: Number(sc.dataset.dayPx), rowPx: ${BAND_ROW_PX}, padPx: ${BAND_PAD_PX} });
    const placed = new Map(laid.bands.map((p) => [p.key, p]));
    for (const [i, b] of bands.entries()) {
      const p = placed.get(b.dataset.key);
      b.hidden = !p;
      if (!p) continue;
      const state = bandState(b.dataset.start, b.dataset.end, input[i].done, input[i].total, GEN_TODAY);
      b.dataset.state = state;
      b.className = "tl-band " + state;
      b.style.left = p.left + "px";
      b.style.width = p.width + "px";
      b.style.top = p.top + "px";
      b.style.setProperty("--rate", pct(input[i]) + "%");
      b.title = b.dataset.label + " " + b.dataset.start + "〜" + b.dataset.end;
      b.firstElementChild.textContent = p.inside;
      if (!p.out) continue;
      const out = document.createElement("div");
      out.className = "tl-band-out " + state;
      out.dataset.bandOut = "";
      out.textContent = p.out.text;
      out.title = b.title;
      out.style.left = p.out.left + "px";
      out.style.top = p.out.top + "px";
      track.append(out);
    }
    track.style.minHeight = laid.rows * ${BAND_ROW_PX} + 12 + "px";
    const missing = bands.filter((b) => b.hidden).map((b) => b.dataset.label);
    track.previousElementSibling.querySelector(".tl-note").textContent = missing.length ? "日付未設定: " + missing.join("・") : "";
  };
  const allMarks = () => [...document.querySelectorAll(".tl-mark[data-title]")];
  const layoutMarkRow = () => {
    const marks = allMarks();
    if (marks.length === 0) return;
    const laid = layoutMarks(
      marks.map((el) => ({ title: el.dataset.title, date: el.dataset.date })),
      { start: sc.dataset.start, dayPx: Number(sc.dataset.dayPx), rowPx: ${MARK_ROW_PX}, charPx: ${MARK_CHAR_PX} },
    );
    const placed = new Map(laid.marks.map((p) => [p.title, p]));
    for (const el of marks) {
      const p = placed.get(el.dataset.title);
      el.style.left = p.left + "px";
      el.style.top = p.top + "px";
      el.textContent = p.text;
      el.classList.toggle("past", el.dataset.date < GEN_TODAY);
      el.title = el.dataset.title + " " + el.dataset.date;
    }
    marks[0].parentElement.style.height = laid.rows * ${MARK_ROW_PX} + 8 + "px";
    for (const line of document.querySelectorAll(".tl-mark-line")) {
      line.style.left = Number(sc.dataset.labelPx) + placed.get(line.dataset.title).left + 6 + "px";
    }
    MILESTONES.list = marks
      .map((el) => ({ title: el.dataset.title, date: el.dataset.date }))
      .sort((a, b) => a.date.localeCompare(b.date));
  };
  const untilDue = (date) => {
    const days = dayDiff(GEN_TODAY, date);
    return days > 0 ? "あと " + days + " 日" : days === 0 ? "今日が期日" : "期日を " + -days + " 日超過";
  };
  // 現在のマイルストーンの数字は、その ▼ までに終わる予定の帯の課題で数える。帯や ▼ の日付を変えたら対象も変わる
  const updateMilestoneKpi = () => {
    const i = MILESTONES.list.findIndex((m) => m.title === MILESTONES.current);
    if (i === -1) return;
    const prev = MILESTONES.list[i - 1]?.date ?? "";
    const due = MILESTONES.list[i].date;
    for (const el of document.querySelectorAll("[data-milestone-date]")) el.textContent = shortDate(due);
    for (const el of document.querySelectorAll("[data-milestone-until]")) el.textContent = untilDue(due);
    for (const el of document.querySelectorAll("[data-milestone-badge]")) {
      el.classList.toggle("late", due < GEN_TODAY);
      el.classList.toggle("todo", due >= GEN_TODAY);
    }
    const ids = allBands()
      .filter((b) => b.dataset.end && prev < b.dataset.end && b.dataset.end <= due)
      .flatMap((b) => (b.dataset.issues ? b.dataset.issues.split(",") : []));
    for (const el of document.querySelectorAll("[data-milestone-kpi]")) el.dataset.issues = ids.join(",");
  };
  const refresh = () => {
    if (sc) {
      for (const track of document.querySelectorAll(".tl-group .tl-track")) layoutGroup(track);
      layoutMarkRow();
    }
    updateMilestoneKpi();
    for (const el of document.querySelectorAll("[data-tally]")) {
      const t = tally(el);
      const kind = el.dataset.tally;
      if (kind === "done") el.textContent = t.done;
      else if (kind === "doing-paren") el.textContent = t.doing > 0 ? "(対応中 " + t.doing + " 件)" : "";
      else if (kind === "rate") el.textContent = pct(t) + "%";
      else if (kind === "bar") {
        el.firstElementChild.style.width = pct(t) + "%";
        el.setAttribute("aria-label", pct(t) + "%");
      } else if (kind === "total") el.textContent = t.total;
      else if (kind === "overdue") {
        const end = bandByKey(el.dataset.band)?.dataset.end;
        el.hidden = !(end && end < GEN_TODAY && t.done < t.total);
      }
    }
  };
  const topicsEl = document.getElementById("topics");
  const paintTopicsEmpty = () => { document.getElementById("topics-empty").hidden = topicsEl.children.length > 0; };
  const topicField = (field, label, value) => {
    const wrap = document.createElement("div");
    const head = document.createElement("div");
    head.className = "topic-label";
    head.textContent = label;
    const body = document.createElement("div");
    body.className = "editable";
    body.contentEditable = "true";
    body.dataset.field = field;
    body.dataset.placeholder = label + "を記入";
    body.innerText = value;
    wrap.append(head, body);
    return wrap;
  };
  // 本文の Markdown は見出し・チェックボックス・箇条書きだけ読みやすくし、ほかは文字のまま出す(HTML として解釈しない)
  const issueContent = (n, open) => {
    const text = ISSUES[n]?.b ?? "";
    if (!text) return null;
    const details = document.createElement("details");
    details.className = "topic-issue";
    details.open = open;
    const summary = document.createElement("summary");
    summary.textContent = "課題の内容";
    const body = document.createElement("div");
    body.className = "topic-issue-body";
    for (const line of text.split("\\n")) {
      const div = document.createElement("div");
      const h = line.match(/^#{1,6} (.*)/);
      if (h) {
        div.className = "md-h";
        div.textContent = h[1];
      } else {
        div.textContent = line
          .replace(/^(\\s*)[-*] \\[[xX]\\] /, "$1☑ ")
          .replace(/^(\\s*)[-*] \\[ \\] /, "$1☐ ")
          .replace(/^(\\s*)[-*] /, "$1・");
      }
      body.append(div);
    }
    details.append(summary, body);
    details.addEventListener("toggle", save);
    return details;
  };
  const addTopic = ({ n = null, title = "", discuss = "", decided = "", open = true } = {}) => {
    const el = document.createElement("div");
    el.className = "topic";
    const head = document.createElement("div");
    head.className = "topic-head";
    const name = document.createElement("span");
    name.className = "topic-title";
    if (n) {
      el.dataset.issue = n;
      const a = document.createElement("a");
      a.className = "num";
      a.href = ISSUES[n]?.u ?? "";
      a.textContent = "#" + n;
      name.textContent = ISSUES[n]?.t ?? "";
      head.append(a, name);
    } else {
      name.contentEditable = "true";
      name.innerText = title;
      head.append(name);
    }
    const del = document.createElement("button");
    del.type = "button";
    del.className = "del";
    del.textContent = "×";
    del.setAttribute("aria-label", "この議題を削除");
    del.onclick = () => { el.remove(); paintTopicsEmpty(); save(); };
    head.append(del);
    const body = document.createElement("div");
    body.className = "topic-body";
    body.append(topicField("discuss", "議論したい内容", discuss), topicField("decided", "確定事項", decided));
    el.append(head);
    const content = n ? issueContent(n, open) : null;
    if (content) el.append(content);
    el.append(body);
    topicsEl.append(el);
    paintTopicsEmpty();
    return el;
  };
  const topicPick = document.getElementById("topic-pick");
  const pickTopic = () => {
    const text = topicPick.value.trim();
    const n = text.match(/^#(\\d+)/)?.[1];
    const issue = n && ISSUES[n] ? n : null;
    // 同じ課題を二重に足さず、足してある議題へ移る
    const existing = issue && topicsEl.querySelector('.topic[data-issue="' + issue + '"]');
    const el = existing || addTopic(issue ? { n: issue } : { title: text });
    topicPick.value = "";
    if (!existing) { refresh(); save(); }
    el.scrollIntoView({ block: "nearest" });
    (issue ? el.querySelector('[data-field="discuss"]') : el.querySelector(".topic-title")).focus();
  };
  document.getElementById("add-topic").onclick = pickTopic;
  // datalist の候補を選んだときはそのまま足す。手で打った文字はボタンか Enter で足す
  // 候補の選択は Chrome では insertReplacementText、inputType を持たない Event で来るブラウザもあるので両方を見る
  topicPick.addEventListener("input", (e) => {
    if (e.inputType === "insertReplacementText" || e.inputType === undefined) {
      const n = topicPick.value.match(/^#(\\d+) /)?.[1];
      if (n && ISSUES[n]) pickTopic();
    }
  });
  topicPick.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); pickTopic(); }
  });
  for (const t of state.topics ?? []) addTopic(t);
  paintTopicsEmpty();
  const dateInputs = [...document.querySelectorAll(".band-date")];
  for (const input of dateInputs) {
    const band = bandByKey(input.dataset.band);
    const saved = state.bands?.[input.dataset.band]?.[input.dataset.edge];
    // 再読み込み時のフォーム復元に任せず、生成時の値か保存した値から始める
    input.value = saved ?? input.defaultValue;
    if (band) band.dataset[input.dataset.edge] = input.value;
    input.addEventListener("click", () => input.showPicker?.());
    input.addEventListener("change", () => {
      const edge = input.dataset.edge;
      band.dataset[edge] = input.value;
      // 開始が完了より後になったら、もう片方を同じ日に合わせる(帯の幅が負にならないように)
      if (band.dataset.start && band.dataset.end && band.dataset.start > band.dataset.end) {
        const other = edge === "start" ? "end" : "start";
        band.dataset[other] = input.value;
        const pair = dateInputs.find((x) => x.dataset.band === input.dataset.band && x.dataset.edge === other);
        if (pair) pair.value = input.value;
      }
      save();
      refresh();
    });
  }
  // 8px — .tl-band の clip-path の矢印の先の幅。右端は矢印の先ごと伸縮の取っ手にする
  const EDGE_PX = 8;
  const shiftDate = (date, days) => new Date(Date.parse(date + "T00:00:00Z") + days * DAY_MS).toISOString().slice(0, 10);
  const dayDiff = (from, to) => Math.round((Date.parse(to + "T00:00:00Z") - Date.parse(from + "T00:00:00Z")) / DAY_MS);
  const dragModeAt = (band, clientX) => {
    const r = band.getBoundingClientRect();
    return clientX - r.left <= EDGE_PX ? "start" : r.right - clientX <= EDGE_PX ? "end" : "move";
  };
  let drag = null;
  for (const band of allBands()) {
    band.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      band.setPointerCapture(e.pointerId);
      drag = { band, mode: dragModeAt(band, e.clientX), x: e.clientX, start: band.dataset.start, end: band.dataset.end, moved: false };
      band.style.cursor = drag.mode === "move" ? "grabbing" : "ew-resize";
    });
    band.addEventListener("pointermove", (e) => {
      if (!drag) {
        band.style.cursor = dragModeAt(band, e.clientX) === "move" ? "grab" : "ew-resize";
        return;
      }
      if (drag.band !== band) return;
      const first = sc.dataset.start;
      const last = shiftDate(first, Number(sc.dataset.days) - 1);
      const days = Math.round((e.clientX - drag.x) / Number(sc.dataset.dayPx));
      let { start, end } = drag;
      if (drag.mode === "move") {
        const d = Math.min(Math.max(days, dayDiff(start, first)), dayDiff(end, last));
        start = shiftDate(start, d);
        end = shiftDate(end, d);
      } else if (drag.mode === "start") {
        start = [first, shiftDate(start, days), end].sort()[1];
      } else {
        end = [start, shiftDate(end, days), last].sort()[1];
      }
      if (start === band.dataset.start && end === band.dataset.end) return;
      drag.moved = true;
      band.dataset.start = start;
      band.dataset.end = end;
      for (const input of dateInputs) {
        if (input.dataset.band === band.dataset.key) input.value = band.dataset[input.dataset.edge];
      }
      refresh();
    });
    const finish = () => {
      if (drag?.band !== band) return;
      if (drag.moved) save();
      drag = null;
      band.style.cursor = "";
    };
    band.addEventListener("pointerup", finish);
    band.addEventListener("pointercancel", finish);
  }
  for (const mark of allMarks()) {
    mark.dataset.date = state.milestones?.[mark.dataset.title] ?? mark.dataset.defaultDate;
    let from = null;
    mark.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      mark.setPointerCapture(e.pointerId);
      from = { x: e.clientX, date: mark.dataset.date, moved: false };
      mark.style.cursor = "grabbing";
    });
    mark.addEventListener("pointermove", (e) => {
      if (!from) return;
      const first = sc.dataset.start;
      const last = shiftDate(first, Number(sc.dataset.days) - 1);
      const date = [first, shiftDate(from.date, Math.round((e.clientX - from.x) / Number(sc.dataset.dayPx))), last].sort()[1];
      if (date === mark.dataset.date) return;
      from.moved = true;
      mark.dataset.date = date;
      refresh();
    });
    const finish = () => {
      if (!from) return;
      if (from.moved) save();
      from = null;
      mark.style.cursor = "";
    };
    mark.addEventListener("pointerup", finish);
    mark.addEventListener("pointercancel", finish);
  }
  for (const el of document.querySelectorAll("select.status")) {
    // ブラウザの再読み込み時のフォーム復元は行の位置で値を戻すため、行の並びが変わると別の課題に入る。GitHub の値から始め直す
    el.value = state.status?.[el.dataset.issue] ?? el.dataset.github;
    paintStatus(el);
    el.addEventListener("change", () => { paintStatus(el); save(); refresh(); });
  }
  refresh();
  for (const row of state.homework?.length ? state.homework : [["", "", ""]]) addRow(row);
  document.addEventListener("input", (e) => {
    const el = e.target;
    if (el.classList?.contains("editable") && !el.innerText.trim()) el.replaceChildren();
    save();
  });
  document.getElementById("add-homework").onclick = () => { addRow().querySelector("td").focus(); save(); };
  document.getElementById("clear").onclick = () => {
    if (!window.confirm("議題・決定事項・宿題・メモと、変えた状態・予定日をすべて元に戻します。元に戻せません。よろしいですか?")) return;
    for (const el of document.querySelectorAll(".editable[data-key]")) el.innerText = "";
    topicsEl.replaceChildren();
    paintTopicsEmpty();
    for (const el of document.querySelectorAll("select.status")) {
      el.value = el.dataset.github;
      paintStatus(el);
    }
    for (const input of dateInputs) {
      input.value = input.defaultValue;
      const band = bandByKey(input.dataset.band);
      if (band) band.dataset[input.dataset.edge] = input.value;
    }
    for (const mark of allMarks()) mark.dataset.date = mark.dataset.defaultDate;
    refresh();
    document.querySelector("#homework tbody").replaceChildren();
    addRow();
    save();
  };
  document.getElementById("pdf").onclick = () => window.print();
  document.getElementById("save-html").onclick = () => {
    save();
    const json = JSON.stringify({ savedAt: new Date().toISOString(), state }).replace(/</g, "\\u003c");
    const start = ORIGINAL.indexOf(SAVED_TAG) + SAVED_TAG.length;
    const html = ORIGINAL.slice(0, start) + json + ORIGINAL.slice(ORIGINAL.indexOf("</" + "script>", start));
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([html], { type: "text/html" }));
    a.download = document.title + ".html";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  // しまったかどうかは見る人の好みなので、日付ごとの入力とは別のキーに残す。印刷では常に出す(議事録として残すため)
  const NOTES_KEY = "jcredit-progress:notes-closed";
  const layoutEl = document.querySelector(".layout");
  const toggleNotes = document.getElementById("toggle-notes");
  const setNotesClosed = (closed) => {
    layoutEl.classList.toggle("notes-closed", closed);
    toggleNotes.textContent = closed ? "決定事項・宿題・メモを出す" : "決定事項・宿題・メモをしまう";
    toggleNotes.setAttribute("aria-expanded", String(!closed));
  };
  try { setNotesClosed(localStorage.getItem(NOTES_KEY) === "1"); } catch {}
  toggleNotes.onclick = () => {
    const closed = !layoutEl.classList.contains("notes-closed");
    setNotesClosed(closed);
    try { localStorage.setItem(NOTES_KEY, closed ? "1" : "0"); } catch {}
  };
  const scroller = document.querySelector(".tl-scroll");
  // 今日の縦線が左から 1/3 あたりに来るよう寄せる(過去の工程も少し見えるように)
  if (scroller) scroller.scrollLeft = Number(scroller.dataset.todayX) - scroller.clientWidth / 3;
  // A4 縦の本文幅 ≒ 700px(96dpi、余白 12mm)。図全体を 1 枚の幅に縮めて切れないようにする
  const PRINT_WIDTH_PX = 700;
  window.addEventListener("beforeprint", () => {
    const tl = document.querySelector(".tl");
    if (tl) tl.style.zoom = String(Math.min(1, PRINT_WIDTH_PX / tl.scrollWidth));
    // 先方に送る PDF では課題を並べず、工程ごとの件数と、予定(end)を生成した日より前に過ぎて残っている課題だけを出す
    for (const ul of document.querySelectorAll(".stage-late")) {
      const late = [...ul.previousElementSibling.querySelectorAll("tr[data-issue]")].filter(
        (tr) => tr.dataset.end && tr.dataset.end < GEN_TODAY && statusOf(tr.dataset.issue) !== "done",
      );
      ul.replaceChildren(
        ...late.map((tr) => {
          const li = document.createElement("li");
          li.textContent = "予定超過: #" + tr.dataset.issue + " " + ISSUES[tr.dataset.issue].t + "(" + shortDate(tr.dataset.end) + " 予定)";
          return li;
        }),
      );
    }
    for (const tr of document.querySelectorAll("#homework tbody tr")) {
      if ([...tr.querySelectorAll("td[contenteditable]")].every((td) => !td.innerText.trim())) tr.classList.add("no-print");
    }
  });
  window.addEventListener("afterprint", () => {
    const tl = document.querySelector(".tl");
    if (tl) tl.style.zoom = "";
    for (const ul of document.querySelectorAll(".stage-late")) ul.replaceChildren();
    for (const tr of document.querySelectorAll("#homework tbody tr.no-print")) tr.classList.remove("no-print");
  });
})();
</script>
</body>
</html>
`;
};

/** query は --input(JSON body)で送る。-F はネストした変数を扱えない */
const graphql = (query, variables = {}) => {
  try {
    const out = execFileSync("gh", ["api", "graphql", "--input", "-"], {
      input: JSON.stringify({ query, variables }),
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
      maxBuffer: 64 * 1024 * 1024,
    });
    const json = JSON.parse(out);
    if (json.errors) throw new Error(json.errors.map((e) => e.message).join("; "));
    return json.data;
  } catch (e) {
    const detail = e.stderr?.trim() || e.message;
    // 個人アカウントが active のままだと project スコープが無く、フィールドごとに同じエラーが大量に出る
    if (detail.includes("read:project")) {
      throw new Error(
        "gh の active アカウントに project スコープが無い。作業用アカウントに切り替える(`gh auth switch --user <作業用アカウント>`)。切り替えても出るなら `gh auth refresh -h github.com -s read:project`",
      );
    }
    throw new Error(`graphql failed: ${detail}`);
  }
};

// repositoryOwner + ProjectV2Owner で引く — fork 先の Project は org ではなく個人の所有のことがある
const ITEMS_QUERY = `
query($owner: String!, $number: Int!, $after: String) {
  repositoryOwner(login: $owner) {
    ... on ProjectV2Owner {
    projectV2(number: $number) {
      url
      items(first: 100, after: $after) {
        pageInfo { hasNextPage endCursor }
        nodes {
          content {
            __typename
            ... on Issue {
              id number title url body state stateReason
              issueType { name }
              assignees(first: 10) { nodes { login } }
              parent { number }
              subIssues(first: 50) { pageInfo { hasNextPage endCursor } nodes { number title url state stateReason } }
            }
          }
          status: fieldValueByName(name: "Status") { ... on ProjectV2ItemFieldSingleSelectValue { name } }
          feature: fieldValueByName(name: "機能") { ... on ProjectV2ItemFieldSingleSelectValue { name } }
          process: fieldValueByName(name: "工程") { ... on ProjectV2ItemFieldSingleSelectValue { name } }
          start: fieldValueByName(name: "Start") { ... on ProjectV2ItemFieldDateValue { date } }
          end: fieldValueByName(name: "end") { ... on ProjectV2ItemFieldDateValue { date } }
          priority: fieldValueByName(name: "Priority") { ... on ProjectV2ItemFieldSingleSelectValue { name } }
          sprint: fieldValueByName(name: "Sprint") { ... on ProjectV2ItemFieldIterationValue { title startDate duration } }
        }
      }
    }
    }
  }
}`;

const fetchProject = ({ projectOwner, projectNumber }) => {
  const nodes = [];
  let after = null;
  let url = null;
  do {
    const notFound = new Error(
      `Project が見つからない: ${projectOwner} の #${projectNumber}(PROGRESS_PROJECT_OWNER / PROGRESS_PROJECT_NUMBER を確認)`,
    );
    let p;
    try {
      p = graphql(ITEMS_QUERY, { owner: projectOwner, number: projectNumber, after })
        .repositoryOwner?.projectV2;
    } catch (e) {
      // 番号違いは null ではなく GraphQL エラー(NOT_FOUND)で返る
      if (e.message.includes("Could not resolve to a ProjectV2")) throw notFound;
      throw e;
    }
    if (!p) throw notFound;
    url = p.url;
    nodes.push(...p.items.nodes);
    after = p.items.pageInfo.hasNextPage ? p.items.pageInfo.endCursor : null;
  } while (after);
  for (const n of nodes) if (n.content?.__typename === "Issue") fetchRemainingSubIssues(n.content);
  const dropped = nodes.filter((n) => DROPPED_REASONS.includes(n.content?.stateReason));
  if (dropped.length > 0) {
    console.log(
      `info: 対応しない理由で閉じた Issue ${dropped.length} 件を数えない(${dropped.map((n) => `#${n.content.number}`).join(" ")})`,
    );
  }
  return { url, issues: nodes.map(normalizeItem).filter(Boolean) };
};

const fetchRemainingSubIssues = (issue) => {
  let page = issue.subIssues.pageInfo;
  while (page?.hasNextPage) {
    const more = graphql(
      `query($id: ID!, $after: String) { node(id: $id) { ... on Issue { subIssues(first: 100, after: $after) { pageInfo { hasNextPage endCursor } nodes { number title url state stateReason } } } } }`,
      { id: issue.id, after: page.endCursor },
    ).node.subIssues;
    issue.subIssues.nodes.push(...more.nodes);
    page = more.pageInfo;
  }
};

const detectRepo = () => {
  try {
    return execFileSync("gh", ["repo", "view", "--json", "nameWithOwner", "-q", ".nameWithOwner"], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    }).trim();
  } catch (e) {
    throw new Error(
      `リポジトリを判定できない(PROGRESS_REPO で指定できる): ${e.stderr?.trim() || e.message}`,
    );
  }
};

const parseArgs = (argv) => {
  const opts = { out: null, data: null, saveData: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--out") opts.out = argv[++i];
    else if (a === "--data") opts.data = argv[++i];
    else if (a === "--save-data") opts.saveData = argv[++i];
    else throw new Error(`unknown option: ${a}`);
  }
  return opts;
};

const main = () => {
  const opts = parseArgs(process.argv.slice(2));
  const now = new Date();
  const today = todayInTokyo(now);
  const title = process.env.PROGRESS_TITLE || undefined;
  let raw;
  if (opts.data) {
    raw = JSON.parse(readFileSync(opts.data, "utf8"));
  } else {
    const config = resolveConfig(process.env, detectRepo);
    raw = { project: fetchProject(config) };
  }
  if (opts.saveData) writeFileSync(opts.saveData, JSON.stringify(raw, null, 2));

  const layout = JSON.parse(readFileSync(new URL("./layout.json", import.meta.url), "utf8"));
  const own = excludeInfra(raw.project.issues);
  // 先に進んだ課題を決めるには元の状態で帯を作る必要があるので、帯は holdAhead の前後で 2 回作る
  const issues = holdAhead(own, buildTimeline(own, layout, today), today);
  const html = renderHtml({
    today,
    summary: summarize(issues),
    tree: buildTree(issues),
    projectUrl: raw.project.url,
    timeline: buildTimeline(issues, layout, today),
    systemName: title,
  });
  const out = resolve(opts.out ?? `.progress/progress-${today}.html`);
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, html);
  console.log(out);
};

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    main();
  } catch (e) {
    console.error(`error: ${e.message}`);
    process.exit(1);
  }
}
