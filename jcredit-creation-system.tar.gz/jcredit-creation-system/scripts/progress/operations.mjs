#!/usr/bin/env node
/**
 * 運用設計・業務マニュアルの予定(週単位のガントチャート)を 1 枚の HTML にする CLI。
 * 予定は docs/operations/schedule.json(運用の担当が書き換える)だけから作り、GitHub の Milestone や Project は読まない。
 * 画面で工程の帯・節目を動かせる。動かした結果はそのブラウザにだけ残り、schedule.json へは「書き出す」で落として置き換える。
 * 手順は docs/operations/README.md「予定」。
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { escapeHtml, todayInTokyo } from "./build.mjs";

const DAY = 86_400_000;
const toMs = (date) => Date.parse(`${date}T00:00:00Z`);
const toDate = (ms) => new Date(ms).toISOString().slice(0, 10);
const mondayOf = (date) => toDate(toMs(date) - ((new Date(toMs(date)).getUTCDay() + 6) % 7) * DAY);
const md = (date) => `${Number(date.slice(5, 7))}/${Number(date.slice(8, 10))}`;

/**
 * 描く範囲は予定の最初の週から最後の週まで。今日が範囲の外でも赤線が出るように今日の週も含める。
 * 画面で帯を動かしても範囲は変えない(広げたいときは schedule.json を直して作り直す)ので、前後に 2 週の余白を持たせる
 */
export const chartRange = (schedule, today) => {
  const dates = [
    ...schedule.tasks.flatMap((t) => [t.start, t.end]),
    ...schedule.milestones.map((m) => m.date),
    today,
  ].sort();
  const from = toDate(toMs(mondayOf(dates[0])) - 14 * DAY);
  const lastMonday = toDate(toMs(mondayOf(dates.at(-1))) + 14 * DAY);
  const weeks = Math.round((toMs(lastMonday) - toMs(from)) / (7 * DAY)) + 1;
  return { from, weeks, days: weeks * 7 };
};

/** 範囲の左端からの位置(%)。end は当日の終わりまで塗るので +1 日で渡す */
export const pos = (range, date) => ((toMs(date) - toMs(range.from)) / DAY / range.days) * 100;

const monthSpans = (range) => {
  const spans = [];
  for (let w = 0; w < range.weeks; w++) {
    const monday = toDate(toMs(range.from) + w * 7 * DAY);
    const label = `${Number(monday.slice(5, 7))}月`;
    if (spans.at(-1)?.label === label) spans.at(-1).weeks++;
    else spans.push({ label, weeks: 1 });
  }
  return spans;
};

// 右端に近い名前(80% より右)は線の左側に出して見切れないようにする。近い日付の節目(UAT終了とリリース 等)の名前が重ならないよう、名前は 2 段に交互に置く
const markClass = (range, date, i) =>
  `mark milestone level-${i % 2}${pos(range, date) > 80 ? " flip" : ""}`;

// JSON を <script> に埋めるとき、文字列中の </script> で閉じられないようにする
const embedJson = (value) => JSON.stringify(value).replaceAll("<", "\\u003c");

export const renderHtml = (schedule, today) => {
  const range = chartRange(schedule, today);
  const weekCols = Array.from({ length: range.weeks }, (_, w) =>
    toDate(toMs(range.from) + w * 7 * DAY),
  );
  const grid = `repeating-linear-gradient(to right, transparent 0, transparent calc(${100 / range.weeks}% - 1px), var(--line) calc(${100 / range.weeks}% - 1px), var(--line) ${100 / range.weeks}%)`;

  const marks = [
    ...schedule.milestones.map(
      (m, i) =>
        `<span class="${markClass(range, m.date, i)}" data-m="${i}" style="left:${pos(range, m.date)}%" title="ドラッグで日付を動かす">▼${escapeHtml(m.title)} ${md(m.date)}</span>`,
    ),
    `<span class="mark today${pos(range, today) > 80 ? " flip" : ""}" data-today style="left:${pos(range, today)}%">今日 ${md(today)}</span>`,
  ].join("");
  const milestoneLines = schedule.milestones
    .map(
      (m, i) =>
        `<div class="vline milestone" data-m="${i}" style="left:${pos(range, m.date)}%"></div>`,
    )
    .join("");

  const rows = schedule.tasks
    .map((t, i) => {
      const left = pos(range, t.start);
      const width = pos(range, toDate(toMs(t.end) + DAY)) - left;
      return `<div class="row task"><div class="name"><b>${escapeHtml(t.label)}</b><span>${escapeHtml(t.owner ?? "")}</span></div><div class="lane"><div class="bar ${escapeHtml(t.kind)}" data-t="${i}" style="left:${left}%;width:${width}%" title="${escapeHtml(`${t.label}(${md(t.start)}〜${md(t.end)})`)}"><i class="grip start"></i><i class="grip end"></i></div></div></div>`;
    })
    .join("");

  const taskInputs = schedule.tasks
    .map(
      (t, i) =>
        `<tr><td>${escapeHtml(t.label)}</td><td>${escapeHtml(t.owner ?? "")}</td><td><input type="date" data-t="${i}" data-edge="start" value="${t.start}"></td><td><input type="date" data-t="${i}" data-edge="end" value="${t.end}"></td></tr>`,
    )
    .join("");
  const milestoneInputs = schedule.milestones
    .map(
      (m, i) =>
        `<tr><td><input type="text" data-m="${i}" data-edge="title" value="${escapeHtml(m.title)}"></td><td><input type="date" data-m="${i}" data-edge="date" value="${m.date}"></td></tr>`,
    )
    .join("");

  const legend = Object.entries(schedule.kinds)
    .map(([k, v]) => `<span><i class="${escapeHtml(k)}"></i>${escapeHtml(v)}</span>`)
    .join("");

  return `<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(schedule.title)}</title>
<style>
  :root { --fg:#1f2328; --muted:#656d76; --line:#d0d7de; --head:#4a3fa0; --soft:#f3f1fa; --today:#cf222e; --accent:#0969da;
    --design:#4a3fa0; --verify:#5b8aa8; --approve:#df8a4a; --prepare:#6a8f68; }
  * { box-sizing:border-box; }
  body { margin:24px; color:var(--fg); background:#fff; font:14px/1.5 -apple-system,BlinkMacSystemFont,"Hiragino Sans","Noto Sans JP",sans-serif; }
  h1 { font-size:22px; margin:0 0 4px; }
  h2 { font-size:16px; margin:32px 0 8px; }
  .sub { color:var(--muted); margin:0 0 16px; }
  .as-of { font:inherit; color:var(--fg); border:1px solid transparent; border-radius:4px; padding:0 2px; background:transparent; cursor:pointer; }
  .as-of:hover, .as-of:focus { border-color:var(--line); outline:none; }
  .frame { min-width:1200px; }
  .chart { border:1px solid var(--line); }
  .row { display:grid; grid-template-columns:300px 1fr; border-top:1px solid var(--line); }
  .row:nth-child(even of .task) { background:var(--soft); }
  .head { background:var(--head); color:#fff; font-weight:600; border-top:0; }
  .head .lane { display:grid; }
  .head .lane div { text-align:center; padding:4px 0; border-left:1px solid rgba(255,255,255,.35); }
  .head .name { display:flex; align-items:center; font-size:16px; }
  .name { padding:10px 12px; display:flex; justify-content:space-between; gap:8px; }
  .name span { color:var(--muted); font-size:12px; }
  .lane { position:relative; border-left:1px solid var(--line); }
  .task .lane { background-image:${grid}; min-height:44px; }
  .bar { position:absolute; top:12px; height:20px; border-radius:2px; cursor:grab; touch-action:none; z-index:2; }
  .bar.dragging { cursor:grabbing; opacity:.85; }
  .grip { position:absolute; top:0; bottom:0; width:8px; cursor:ew-resize; }
  .grip.start { left:-2px; } .grip.end { right:-2px; }
  .design, i.design { background:var(--design); } .verify, i.verify { background:var(--verify); }
  .approve, i.approve { background:var(--approve); } .prepare, i.prepare { background:var(--prepare); }
  .body { position:relative; }
  .overlay { position:absolute; inset:0 0 0 300px; pointer-events:none; }
  .vline { position:absolute; top:0; bottom:0; border-left:2px dashed var(--muted); }
  .vline.today { border-left:2px solid var(--today); z-index:3; }
  .marks { position:relative; height:44px; margin-left:300px; }
  .mark { position:absolute; white-space:nowrap; font-size:12px; color:var(--muted); transform:translateX(-6px); }
  .mark.milestone { cursor:ew-resize; touch-action:none; user-select:none; }
  .mark.milestone:hover { color:var(--fg); }
  .mark.flip { transform:translateX(calc(-100% + 6px)); }
  .mark.level-0 { top:0; } .mark.level-1 { top:20px; }
  .mark.today { top:22px; color:var(--today); font-weight:600; }
  .legend { display:flex; gap:24px; margin-top:4px; color:var(--muted); font-size:13px; }
  .legend i { display:inline-block; width:12px; height:12px; margin-right:6px; vertical-align:-1px; }
  .scroll { overflow-x:auto; padding-bottom:16px; }
  .tools { display:flex; gap:8px; align-items:center; margin:24px 0 0; }
  .tools button { font:inherit; padding:4px 12px; border:1px solid var(--line); border-radius:6px; background:#fff; cursor:pointer; }
  .tools button:hover { border-color:var(--accent); color:var(--accent); }
  .tools span { color:var(--muted); font-size:13px; }
  .edit { display:flex; gap:40px; flex-wrap:wrap; }
  table { border-collapse:collapse; }
  th, td { text-align:left; padding:4px 8px; border-bottom:1px solid var(--line); }
  th { color:var(--muted); font-weight:600; font-size:13px; }
  td input { font:inherit; border:1px solid transparent; border-radius:4px; padding:2px 4px; background:transparent; }
  td input:hover, td input:focus { border-color:var(--line); outline:none; }
  td input[type="text"] { width:14em; }
  @media print { body { margin:8mm; } .scroll { overflow:visible; } .tools, .edit, h2 { display:none; } }
</style></head><body>
<h1>${escapeHtml(schedule.title)}</h1>
<p class="sub"><input type="date" class="as-of" value="${today}" min="${range.from}" max="${toDate(toMs(range.from) + (range.days - 1) * DAY)}" data-today="${today}" aria-label="基準日"> 時点。赤の線が基準日(日付を押して変えられる)、破線が開発側の節目。帯はドラッグで移動、両端で伸び縮み。節目は名前をドラッグで移動。</p>
<div class="scroll"><div class="frame">
<div class="marks">${marks}</div>
<div class="chart">
  <div class="row head"><div class="name" style="grid-row:span 2">工程・主担当</div>
    <div class="lane" style="grid-template-columns:${monthSpans(range)
      .map((s) => `${s.weeks}fr`)
      .join(" ")}">${monthSpans(range)
      .map((s) => `<div>${s.label}</div>`)
      .join("")}</div>
    <div class="lane" style="grid-template-columns:repeat(${range.weeks},1fr)">${weekCols.map((d) => `<div>${Number(d.slice(8, 10))}</div>`).join("")}</div>
  </div>
  <div class="body">
    ${rows}
    <div class="overlay">
      ${milestoneLines}
      <div class="vline today" data-today style="left:${pos(range, today)}%"></div>
    </div>
  </div>
</div></div></div>
<div class="legend">${legend}</div>
<div class="tools">
  <button type="button" data-action="export">schedule.json を書き出す</button>
  <button type="button" data-action="reset">元に戻す</button>
  <span data-status></span>
</div>
<div class="edit">
  <div><h2>工程</h2><table><thead><tr><th>工程</th><th>主担当</th><th>開始</th><th>終了</th></tr></thead><tbody>${taskInputs}</tbody></table></div>
  <div><h2>節目</h2><table><thead><tr><th>名前</th><th>日付</th></tr></thead><tbody>${milestoneInputs}</tbody></table></div>
</div>
<script type="application/json" id="schedule">${embedJson(schedule)}</script>
<script type="application/json" id="range">${embedJson(range)}</script>
<script>
(() => {
  const DAY = 86400000;
  const base = JSON.parse(document.getElementById("schedule").textContent);
  const range = JSON.parse(document.getElementById("range").textContent);
  const baseJson = JSON.stringify(base);
  const KEY = "operations-schedule";
  const toMs = (d) => Date.parse(d + "T00:00:00Z");
  const toDate = (ms) => new Date(ms).toISOString().slice(0, 10);
  const md = (d) => Number(d.slice(5, 7)) + "/" + Number(d.slice(8, 10));
  const pos = (d) => ((toMs(d) - toMs(range.from)) / DAY / range.days) * 100;
  const first = toMs(range.from);
  const last = first + (range.days - 1) * DAY;
  const clamp = (ms) => Math.min(last, Math.max(first, ms));
  const addDays = (d, n) => toDate(toMs(d) + n * DAY);

  // 保存した編集は、元にした schedule.json が同じときだけ使う(schedule.json を直して作り直したら、古い編集で上書きしない)
  const load = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || "null");
      if (saved && saved.base === baseJson) return saved.schedule;
    } catch {}
    return JSON.parse(baseJson);
  };
  let state = load();
  const status = document.querySelector("[data-status]");
  const save = () => {
    const changed = JSON.stringify(state) !== baseJson;
    try {
      if (changed) localStorage.setItem(KEY, JSON.stringify({ base: baseJson, schedule: state }));
      else localStorage.removeItem(KEY);
    } catch {}
    status.textContent = changed ? "変更あり(このブラウザにだけ保存。schedule.json に反映するには書き出して置き換える)" : "";
  };

  const apply = () => {
    state.tasks.forEach((t, i) => {
      const bar = document.querySelector('.bar[data-t="' + i + '"]');
      const left = pos(t.start);
      bar.style.left = left + "%";
      bar.style.width = pos(addDays(t.end, 1)) - left + "%";
      bar.title = t.label + "(" + md(t.start) + "〜" + md(t.end) + ")";
      for (const input of document.querySelectorAll('input[data-t="' + i + '"]')) {
        if (document.activeElement !== input) input.value = t[input.dataset.edge];
      }
    });
    state.milestones.forEach((m, i) => {
      const mark = document.querySelector('.mark[data-m="' + i + '"]');
      mark.style.left = pos(m.date) + "%";
      mark.textContent = "▼" + m.title + " " + md(m.date);
      mark.classList.toggle("flip", pos(m.date) > 80);
      document.querySelector('.vline[data-m="' + i + '"]').style.left = pos(m.date) + "%";
      for (const input of document.querySelectorAll('input[data-m="' + i + '"]')) {
        if (document.activeElement !== input) input.value = m[input.dataset.edge];
      }
    });
    save();
  };

  const lane = document.querySelector(".task .lane");
  const dayWidth = () => lane.getBoundingClientRect().width / range.days;
  let drag = null;
  const startDrag = (e, payload) => {
    e.preventDefault();
    drag = { x: e.clientX, ...payload };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  for (const bar of document.querySelectorAll(".bar")) {
    bar.addEventListener("pointerdown", (e) => {
      const t = state.tasks[bar.dataset.t];
      const mode = e.target.classList.contains("start") ? "start" : e.target.classList.contains("end") ? "end" : "move";
      bar.classList.add("dragging");
      startDrag(e, { kind: "task", i: bar.dataset.t, mode, start: t.start, end: t.end, el: bar });
    });
  }
  for (const mark of document.querySelectorAll(".mark.milestone")) {
    mark.addEventListener("pointerdown", (e) => {
      startDrag(e, { kind: "milestone", i: mark.dataset.m, date: state.milestones[mark.dataset.m].date, el: mark });
    });
  }
  document.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const n = Math.round((e.clientX - drag.x) / dayWidth());
    if (drag.kind === "milestone") {
      state.milestones[drag.i].date = toDate(clamp(toMs(drag.date) + n * DAY));
    } else {
      const t = state.tasks[drag.i];
      if (drag.mode === "move") {
        const len = toMs(drag.end) - toMs(drag.start);
        const s = Math.min(last - len, Math.max(first, toMs(drag.start) + n * DAY));
        t.start = toDate(s);
        t.end = toDate(s + len);
      } else if (drag.mode === "start") {
        t.start = toDate(Math.min(toMs(drag.end), clamp(toMs(drag.start) + n * DAY)));
      } else {
        t.end = toDate(Math.max(toMs(drag.start), clamp(toMs(drag.end) + n * DAY)));
      }
    }
    apply();
  });
  const endDrag = () => {
    if (drag) drag.el.classList.remove("dragging");
    drag = null;
  };
  document.addEventListener("pointerup", endDrag);
  document.addEventListener("pointercancel", endDrag);

  for (const input of document.querySelectorAll(".edit input")) {
    input.addEventListener("change", () => {
      const v = input.value;
      if (input.dataset.t !== undefined) {
        if (!v) return apply();
        const t = state.tasks[input.dataset.t];
        const ms = clamp(toMs(v));
        if (input.dataset.edge === "start") t.start = toDate(Math.min(ms, toMs(t.end)));
        else t.end = toDate(Math.max(ms, toMs(t.start)));
      } else {
        const m = state.milestones[input.dataset.m];
        if (input.dataset.edge === "title") m.title = v;
        else if (v) m.date = toDate(clamp(toMs(v)));
      }
      apply();
    });
  }

  document.querySelector('[data-action="export"]').addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2) + "\\n"], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "schedule.json";
    a.click();
    URL.revokeObjectURL(a.href);
  });
  document.querySelector('[data-action="reset"]').addEventListener("click", () => {
    state = JSON.parse(baseJson);
    apply();
  });

  // 基準日(赤線の位置)は予定と別に持つ。書き出す schedule.json には入れず、作った日が変わったら作った日に戻す
  const asOf = document.querySelector(".as-of");
  const AS_OF_KEY = "operations-as-of";
  const applyAsOf = () => {
    const d = asOf.value;
    const flip = pos(d) > 80;
    for (const el of document.querySelectorAll("[data-today]:not(.as-of)")) el.style.left = pos(d) + "%";
    const mark = document.querySelector(".mark[data-today]");
    mark.textContent = (d === asOf.dataset.today ? "今日 " : "") + md(d);
    mark.classList.toggle("flip", flip);
    try {
      if (d === asOf.dataset.today) localStorage.removeItem(AS_OF_KEY);
      else localStorage.setItem(AS_OF_KEY, JSON.stringify({ today: asOf.dataset.today, asOf: d }));
    } catch {}
  };
  try {
    const saved = JSON.parse(localStorage.getItem(AS_OF_KEY) || "null");
    if (saved && saved.today === asOf.dataset.today) asOf.value = saved.asOf;
  } catch {}
  asOf.addEventListener("change", () => {
    if (!asOf.value) asOf.value = asOf.dataset.today;
    asOf.value = toDate(clamp(toMs(asOf.value)));
    applyAsOf();
  });
  applyAsOf();

  apply();
})();
</script>
</body></html>
`;
};

const main = () => {
  const args = process.argv.slice(2);
  const outIndex = args.indexOf("--out");
  const today = todayInTokyo(new Date());
  const path = new URL("../../docs/operations/schedule.json", import.meta.url);
  const schedule = JSON.parse(readFileSync(path, "utf8"));
  const out = resolve(outIndex >= 0 ? args[outIndex + 1] : `.progress/operations-${today}.html`);
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, renderHtml(schedule, today));
  console.log(out);
};

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    main();
  } catch (e) {
    console.error(`error: ${e.message}`);
    process.exit(1);
  }
}
