/** build.mjs の公開シグネチャ。テストから型付きで import するためだけに置く(実装は .mjs) */
export interface Sprint {
  title: string;
  startDate: string;
  duration: number;
}

export interface SubIssue {
  number: number;
  title: string;
  url: string;
  state: "OPEN" | "CLOSED";
}

export interface ProgressIssue extends SubIssue {
  body?: string;
  type: string | null;
  assignees: string[];
  parent: number | null;
  subIssues: SubIssue[];
  status: string | null;
  feature: string | null;
  process: string | null;
  start: string | null;
  end: string | null;
  priority: string | null;
  sprint: Sprint | null;
}

export interface Tally {
  total: number;
  done: number;
  inProgress: number;
  rate: number;
}

export interface Summary {
  all: Tally;
}

export type TreeNode =
  | (ProgressIssue & { children: TreeNode[] })
  | (SubIssue & { status: null; children: [] });

export interface TimelineBand {
  label: string;
  start: string | null;
  end: string | null;
  total: number;
  done: number;
  state: BandState;
  issues: number[];
}

export type BandState = "done" | "current" | "late" | "upcoming" | "unscheduled";

export interface PlacedBand {
  key: string;
  row: number;
  left: number;
  width: number;
  top: number;
  inside: string;
  out: { text: string; left: number; top: number } | null;
}

export interface TimelineLayout {
  until?: string;
  milestones: { title: string; date: string }[];
  groups: {
    name: string;
    tone?: "app" | "api" | "test" | "plain";
    spaceBefore?: boolean;
    bands: {
      label: string;
      feature?: string;
      processes?: string[];
      start?: string;
      end?: string;
    }[];
  }[];
}

export interface TimelineMark {
  title: string;
  date: string;
  done: number;
  total: number;
}

export interface Timeline {
  start: string;
  weeks: number;
  groups: {
    name: string;
    tone: string;
    spaceBefore: boolean;
    rows: number;
    bands: TimelineBand[];
  }[];
  milestones: TimelineMark[];
  currentMilestone: TimelineMark | null;
}

export interface ProgressConfig {
  repo: string;
  projectOwner: string;
  projectNumber: number;
}

export declare const resolveConfig: (
  env: Record<string, string | undefined>,
  detectRepo: () => string,
) => ProgressConfig;
export declare const todayInTokyo: (from: Date) => string;
export declare const isDone: (issue: { status: string | null; state: string }) => boolean;
export declare const cleanBody: (body: string | null | undefined) => string;
export declare const normalizeItem: (node: unknown) => ProgressIssue | null;
export declare const excludeInfra: (issues: ProgressIssue[]) => ProgressIssue[];
export declare const buildTree: (issues: ProgressIssue[]) => TreeNode[];
export declare const flattenTree: (
  tree: TreeNode[],
  depth?: number,
) => { node: TreeNode; depth: number }[];
export declare const summarize: (issues: ProgressIssue[]) => Summary;
export declare const buildTimeline: (
  issues: ProgressIssue[],
  layout: TimelineLayout,
  today: string,
) => Timeline;
export declare const holdAhead: (
  issues: ProgressIssue[],
  timeline: Timeline,
  today: string,
) => ProgressIssue[];
export declare const bandState: (
  start: string | null,
  end: string | null,
  done: number,
  total: number,
  today: string,
) => BandState;
export declare const layoutMarks: (
  marks: { title: string; date: string }[],
  opts: { start: string; dayPx: number; rowPx: number; charPx: number },
) => { marks: { title: string; text: string; left: number; top: number }[]; rows: number };
export declare const layoutBands: (
  bands: {
    key: string;
    label: string;
    start: string | null;
    end: string | null;
    done: number;
    total: number;
  }[],
  opts: { start: string; dayPx: number; rowPx: number; padPx: number },
) => { bands: PlacedBand[]; rows: number };
export declare const bandKey: (group: { name: string }, band: { label: string }) => string;
export declare const renderTimeline: (timeline: Timeline | null, today: string) => string;
export declare const stageOf: (node: TreeNode) => string;
export declare const groupByStage: (tree: TreeNode[]) => {
  name: string;
  tree: TreeNode[];
  start: string | null;
  end: string | null;
  total: number;
  done: number;
  inProgress: number;
}[];
export declare const escapeHtml: (s: unknown) => string;
export declare const renderHtml: (input: {
  today: string;
  summary: Summary;
  tree: TreeNode[];
  projectUrl: string | null;
  timeline?: Timeline | null;
  systemName?: string;
}) => string;
