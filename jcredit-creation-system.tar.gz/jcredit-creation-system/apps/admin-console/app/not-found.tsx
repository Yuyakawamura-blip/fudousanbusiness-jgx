import { Button } from "@jcredit/ui/components/button";
import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-4 p-8">
      <h1 className="text-xl font-bold">ページが見つかりません</h1>
      <p className="text-muted-foreground">
        URL が間違っているか、ページが移動または削除された可能性があります。
      </p>
      <div>
        <Button asChild>
          <Link href="/">トップへ戻る</Link>
        </Button>
      </div>
    </main>
  );
}
