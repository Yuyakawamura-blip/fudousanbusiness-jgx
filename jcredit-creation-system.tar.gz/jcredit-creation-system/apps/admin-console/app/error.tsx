"use client";

import { Button } from "@jcredit/ui/components/button";
import { useEffect } from "react";

export default function ErrorPage({
  error,
  retry,
}: {
  error: Error & { digest?: string };
  retry: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-4 p-8">
      <h1 className="text-xl font-bold">エラーが発生しました</h1>
      <p className="text-muted-foreground">
        時間をおいて再度お試しください。解決しない場合は、下のエラー ID
        を添えてお問い合わせください。
      </p>
      {error.digest && (
        <p className="text-sm text-muted-foreground">
          エラー ID: <code>{error.digest}</code>
        </p>
      )}
      <div>
        <Button onClick={() => retry()}>再読み込み</Button>
      </div>
    </main>
  );
}
