import { Toaster } from "@jcredit/ui/components/sonner";
import type { Metadata } from "next";
import { Noto_Sans_JP } from "next/font/google";
import { env } from "@/env";
import "./globals.css";

// 日本語グリフは subsets で絞れないため preload せず、必要時に読ませる
const notoSansJp = Noto_Sans_JP({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  display: "swap",
  preload: false,
  variable: "--font-noto-sans-jp",
});

export const metadata: Metadata = {
  title: {
    default: env.NEXT_PUBLIC_APP_NAME,
    template: `%s | ${env.NEXT_PUBLIC_APP_NAME}`,
  },
  description: "J-Credit Creation System",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja" className={notoSansJp.variable} suppressHydrationWarning>
      <body className="min-h-screen font-sans antialiased">
        <header className="border-b bg-console-accent px-6 py-3 text-primary-foreground">
          <span className="text-sm font-medium">{env.NEXT_PUBLIC_APP_NAME}</span>
        </header>
        {children}
        {/* ThemeProvider を置いていないため theme を明示しないと OS のダーク設定に追従してしまう */}
        <Toaster theme="light" />
      </body>
    </html>
  );
}
