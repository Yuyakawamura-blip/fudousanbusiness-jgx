import { defineConfig } from "vitest/config";

/**
 * ユニットテスト。画面(RSC / client)は Playwright(`test:e2e`)が担い、
 * ここでは **DOM 非依存の純ロジック**(`lib/*.ts`)だけを対象にする。
 */
export default defineConfig({
  test: {
    environment: "node",
    include: ["lib/**/*.test.ts"],
    globals: false,
    clearMocks: true,
    restoreMocks: true,
  },
  resolve: {
    alias: {
      "@": new URL(".", import.meta.url).pathname,
    },
  },
});
