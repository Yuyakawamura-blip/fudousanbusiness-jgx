import { defineConfig, devices } from "@playwright/test";

const PORT = Number(process.env.PORT ?? 3002);
const BASE_URL = `http://localhost:${PORT}`;

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  ...(process.env.CI ? { workers: 1 } : {}),
  reporter: process.env.CI ? "github" : "list",
  use: {
    baseURL: BASE_URL,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
  },
  webServer: {
    command: `pnpm exec next dev --turbopack -p ${PORT}`,
    url: BASE_URL,
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
    env: {
      INTERNAL_API_URL: process.env.INTERNAL_API_URL ?? "http://localhost:8787",
    },
  },
  // Web のみ・デスクトップ Chrome のみ(モバイル viewport は対象外)
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
});
