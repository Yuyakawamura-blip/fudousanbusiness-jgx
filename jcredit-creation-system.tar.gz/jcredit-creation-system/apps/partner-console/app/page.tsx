import { Button } from "@jcredit/ui/components/button";
import { unstable_rethrow } from "next/navigation";
import { env } from "@/env";
import { getApiClient } from "@/lib/api";

async function fetchGreeting(): Promise<string> {
  try {
    const api = await getApiClient();
    const res = await api.hello.$get({ query: { name: "創出PTマイページ" } });
    if (!res.ok) return "API error";
    return (await res.json()).message;
  } catch (err) {
    // redirect() / notFound() / headers() は throw で制御を返すため、握り潰さず Next に戻す
    unstable_rethrow(err);
    return "API 未接続(pnpm dev で apps/api を起動してください)";
  }
}

export default async function HomePage() {
  const greeting = await fetchGreeting();
  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-6 p-8">
      <h1 className="text-2xl font-bold">{env.NEXT_PUBLIC_APP_NAME}</h1>
      <p className="text-muted-foreground">J-Credit Creation System — 創出PTマイページ(雛形)</p>
      <div className="rounded-lg border bg-card p-4">
        <p className="text-sm">
          API (<code>/api/partner/hello</code>): {greeting}
        </p>
      </div>
      <div>
        <Button>shadcn Button</Button>
      </div>
    </main>
  );
}
