import { serve } from "@hono/node-server";
import { app } from "./app.ts";
import { env } from "./env.ts";
import { db } from "./lib/db.ts";
import { logger } from "./lib/logger.ts";

const server = serve(
  {
    fetch: app.fetch,
    port: env.PORT,
  },
  (info) => {
    logger.info({ port: info.port }, "api listening");
  },
);

// ECS / Kubernetes が SIGTERM から SIGKILL までに待つ既定の 30 秒より十分短くし、ログを出して自分で終わる
const SHUTDOWN_TIMEOUT_MS = 10_000;

const shutdown = (signal: NodeJS.Signals) => {
  logger.info({ signal }, "shutdown");
  // 処理中のリクエストが終わらないと server.close のコールバックが呼ばれず、待ち続けるため
  setTimeout(() => {
    logger.error({ timeoutMs: SHUTDOWN_TIMEOUT_MS }, "shutdown timed out");
    process.exit(1);
  }, SHUTDOWN_TIMEOUT_MS).unref();
  server.close(async (err) => {
    if (err) {
      logger.error({ err }, "shutdown failed");
      process.exit(1);
    }
    try {
      await db.$client.end();
    } catch (endErr) {
      logger.error({ err: endErr }, "db pool close failed");
      process.exit(1);
    }
    process.exit(0);
  });
};

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
