import { Scalar } from "@scalar/hono-api-reference";
import { secureHeaders } from "hono/secure-headers";
import { timing } from "hono/timing";
import { openApiApp } from "./lib/openapi-app.ts";
import {
  errorHandler,
  notFoundHandler,
  type RequestIdVariables,
  requestId,
  requestLogger,
} from "./middleware/index.ts";
import { openApiConfig } from "./openapi.ts";
import { adminApp } from "./routes/admin/index.ts";
import { healthRoute } from "./routes/health.ts";
import { memberApp } from "./routes/member/index.ts";
import { partnerApp } from "./routes/partner/index.ts";

const app = openApiApp<{ Variables: RequestIdVariables }>();

// グローバル CORS は置かない — ブラウザから API への直接クロスオリジンアクセスは存在しない
// (各 Web アプリはサーバー側 RSC / Server Action 経由で呼ぶ)ため、CORS ヘッダを返さない =
// ブラウザからは全ブロックが既定の姿勢。
app.use("*", requestId());
app.use("*", requestLogger());
app.use("*", timing());
// secureHeaders() は既定で CSP を出さないため、Scalar(/docs)の CDN スクリプト読み込みも妨げない。
// 将来 CSP を明示するときは /docs 用に contentSecurityPolicy だけを個別に緩める(全ヘッダを外さない)
app.use("*", secureHeaders());
app.onError(errorHandler);
app.notFound(notFoundHandler);

const routes = app
  .route("/health", healthRoute)
  .route("/api/admin", adminApp)
  .route("/api/partner", partnerApp)
  .route("/api/member", memberApp);

// OpenAPI spec と API ドキュメント(Scalar。Swagger UI は使わない)
app.doc("/openapi.json", openApiConfig);
app.get("/docs", Scalar({ url: "/openapi.json", pageTitle: openApiConfig.info.title }));

export { app };
export type AppType = typeof routes;
// レーン別 RPC 型(mount 前の sub-app 型)。各 Web アプリは自レーンの型だけを使う
export type AdminRouter = typeof adminApp;
export type PartnerRouter = typeof partnerApp;
export type MemberRouter = typeof memberApp;
