/**
 * OpenAPI ドキュメント設定。`/openapi.json` と Scalar(`/docs`)が共有する。
 * バージョンは 3.0.3 — `app.doc()` は 3.0 生成器のため表記を一致させる
 * (3.1 に上げる場合は `doc31()` へ同時に切り替えること)。
 */
export const openApiConfig = {
  openapi: "3.0.3",
  info: {
    title: "J-Credit Creation System API",
    version: "0.0.0",
    description:
      "J-クレジット創出システムのバックエンド API。レーン(admin / partner / member)ごとに分離されている。",
  },
  tags: [
    { name: "health", description: "死活監視" },
    { name: "admin", description: "運営者コンソール向け(/api/admin)" },
    { name: "partner", description: "創出PTマイページ向け(/api/partner)" },
    { name: "member", description: "会員マイページ向け(/api/member)" },
  ],
};
