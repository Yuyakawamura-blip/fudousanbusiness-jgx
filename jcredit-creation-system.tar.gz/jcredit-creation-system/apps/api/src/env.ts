import { DB_DEFAULTS } from "@jcredit/db";
import { APP_ENVS } from "@jcredit/shared";
import { z } from "zod";

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  // デプロイ環境の識別。NODE_ENV はデプロイ済み dev でも development のため判別に使えない。
  APP_ENV: z.enum(APP_ENVS).default("local"),
  PORT: z.coerce.number().int().positive().default(8787),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),
  // DB 接続情報(既定値は packages/db の DB_DEFAULTS = ローカル docker-compose)。
  DB_HOST: z.string().min(1).default(DB_DEFAULTS.host),
  DB_PORT: z.coerce.number().int().positive().default(DB_DEFAULTS.port),
  DB_NAME: z.string().min(1).default(DB_DEFAULTS.name),
  DB_USER: z.string().min(1).default(DB_DEFAULTS.user),
  DB_PASSWORD: z.string().min(1).default(DB_DEFAULTS.password),
  DB_SSL: z
    .enum(["true", "false"])
    .default("false")
    .transform((v) => v === "true"),
});

export type Env = z.infer<typeof EnvSchema>;

// `.env` の `KEY=` は空文字として届くが、zod の `.default()` は undefined にしか効かない。
// 空値を未設定とみなし、compose / migration(resolveDatabaseUrl)と同じく既定値で補う
const withoutEmpty = (source: NodeJS.ProcessEnv) =>
  Object.fromEntries(Object.entries(source).filter(([, value]) => value !== ""));

export const parseEnv = (source: NodeJS.ProcessEnv): Env => EnvSchema.parse(withoutEmpty(source));

// 起動時 fail-fast: 型不正をここで弾く
export const env: Env = parseEnv(process.env);
