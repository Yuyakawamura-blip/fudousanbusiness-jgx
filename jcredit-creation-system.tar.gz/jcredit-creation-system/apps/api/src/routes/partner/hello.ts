import { createRoute } from "@hono/zod-openapi";
import { openApiApp } from "../../lib/openapi-app.ts";
import type { RequestIdVariables } from "../../middleware/request-id.ts";
import { errorResponses } from "../../schemas/common.ts";
import { HelloQuerySchema, HelloResponseSchema } from "../../schemas/partner/hello.ts";
import { buildGreeting } from "../../services/partner/hello.ts";

const helloGetRoute = createRoute({
  method: "get",
  path: "/",
  tags: ["partner"],
  summary: "動作確認用の挨拶(創出PT)",
  request: { query: HelloQuerySchema },
  responses: {
    200: {
      description: "挨拶",
      content: { "application/json": { schema: HelloResponseSchema } },
    },
    ...errorResponses,
  },
});

export const helloRoute = openApiApp<{ Variables: RequestIdVariables }>().openapi(
  helloGetRoute,
  (c) => c.json(buildGreeting(c.req.valid("query").name), 200),
);
