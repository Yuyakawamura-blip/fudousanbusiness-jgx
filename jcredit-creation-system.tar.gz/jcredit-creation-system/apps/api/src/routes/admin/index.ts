import { openApiApp } from "../../lib/openapi-app.ts";
import type { RequestIdVariables } from "../../middleware/request-id.ts";
import { helloRoute } from "./hello.ts";

/**
 * admin レーン(`/api/admin`)の sub-app。運営者向け。
 * 各ルートはレーン相対パスで定義し、ここで結合する。他レーンのファイルは import しない
 * (src/__tests__/lane-isolation.test.ts が機械的に検査する)。
 */
export const adminApp = openApiApp<{ Variables: RequestIdVariables }>().route("/hello", helloRoute);
