import { createRoute } from "@hono/zod-openapi";
import { openApiApp } from "../lib/openapi-app.ts";
import type { RequestIdVariables } from "../middleware/request-id.ts";
import { HealthLiveResponseSchema, HealthReadyResponseSchema } from "../schemas/health.ts";

const startedAt = Date.now();

const liveRoute = createRoute({
  method: "get",
  path: "/live",
  tags: ["health"],
  summary: "Liveness probe",
  responses: {
    200: {
      description: "サービスが生きている",
      content: { "application/json": { schema: HealthLiveResponseSchema } },
    },
  },
});

const readyRoute = createRoute({
  method: "get",
  path: "/ready",
  tags: ["health"],
  summary: "Readiness probe",
  responses: {
    200: {
      description: "サービスがリクエストを受け付け可能",
      content: { "application/json": { schema: HealthReadyResponseSchema } },
    },
  },
});

export const healthRoute = openApiApp<{ Variables: RequestIdVariables }>()
  .openapi(liveRoute, (c) => c.json({ status: "ok" as const, requestId: c.get("requestId") }, 200))
  .openapi(readyRoute, (c) =>
    c.json(
      { status: "ok" as const, uptimeMs: Date.now() - startedAt, requestId: c.get("requestId") },
      200,
    ),
  );
