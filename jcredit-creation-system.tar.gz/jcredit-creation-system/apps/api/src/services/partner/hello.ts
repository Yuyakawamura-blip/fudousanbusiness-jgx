/** 創出PTレーンの雛形サービス。実装時はこの層に業務ロジックを置き、repositories/partner を呼ぶ */
export const buildGreeting = (name: string | undefined) => ({
  lane: "partner" as const,
  message: `Hello, ${name ?? "創出PT"}`,
});
