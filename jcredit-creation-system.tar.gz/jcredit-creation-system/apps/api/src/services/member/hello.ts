/** 会員レーンの雛形サービス。実装時はこの層に業務ロジックを置き、repositories/member を呼ぶ */
export const buildGreeting = (name: string | undefined) => ({
  lane: "member" as const,
  message: `Hello, ${name ?? "会員"}`,
});
