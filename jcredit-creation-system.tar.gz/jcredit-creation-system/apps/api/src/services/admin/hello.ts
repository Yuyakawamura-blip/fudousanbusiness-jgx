/** 運営者レーンの雛形サービス。実装時はこの層に業務ロジックを置き、repositories/admin を呼ぶ */
export const buildGreeting = (name: string | undefined) => ({
  lane: "admin" as const,
  message: `Hello, ${name ?? "運営者"}`,
});
