import { createMiddleware } from "hono/factory";
import { logger } from "../lib/logger.ts";
import type { RequestIdVariables } from "./request-id.ts";

export const requestLogger = () =>
  createMiddleware<{ Variables: RequestIdVariables }>(async (c, next) => {
    const start = performance.now();
    await next();
    logger.info(
      {
        requestId: c.get("requestId"),
        method: c.req.method,
        path: c.req.path,
        status: c.res.status,
        durationMs: Math.round(performance.now() - start),
      },
      "request",
    );
  });
