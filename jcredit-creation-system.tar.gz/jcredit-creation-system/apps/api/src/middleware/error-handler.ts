import type { ErrorHandler, NotFoundHandler } from "hono";
import { HTTPException } from "hono/http-exception";
import type { ZodError } from "zod";
import { AppError, ValidationError } from "../lib/errors.ts";
import { logger } from "../lib/logger.ts";
import type { RequestIdVariables } from "./request-id.ts";

/**
 * `@hono/zod-openapi` の defaultHook。リクエスト検証失敗を ValidationError として throw し、
 * onError(下の errorHandler)に集約する — 各ルートで 400 の形を作らない。
 */
// 成功時は**何も返さない**こと。truthy な値を返すと zod-openapi がそれをレスポンス扱いする。
export const validationHook = (
  result: { success: true } | { success: false; error: ZodError },
): void => {
  if (!result.success) throw new ValidationError(result.error.issues);
};

/** 全レーン共通のエラー整形。業務エラー(AppError)は code 付き、それ以外は 500 に丸める */
export const errorHandler: ErrorHandler<{ Variables: RequestIdVariables }> = (err, c) => {
  const requestId = c.get("requestId");
  if (err instanceof ValidationError) {
    return c.json(
      { error: { code: err.code, message: err.message, issues: err.issues }, requestId },
      400,
    );
  }
  if (err instanceof AppError) {
    return c.json({ error: { code: err.code, message: err.message }, requestId }, err.status);
  }
  if (err instanceof HTTPException) {
    return c.json({ error: { code: "http_error", message: err.message }, requestId }, err.status);
  }
  logger.error({ err, requestId }, "unhandled error");
  return c.json({ error: { code: "internal", message: "Internal Server Error" }, requestId }, 500);
};

/** どのルートにも当たらなかったときも、errorHandler と同じ形で返す(Hono 既定は text/plain) */
export const notFoundHandler: NotFoundHandler<{ Variables: RequestIdVariables }> = (c) =>
  c.json(
    { error: { code: "not_found", message: "Not Found" }, requestId: c.get("requestId") },
    404,
  );
