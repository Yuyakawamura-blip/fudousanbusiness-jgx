import { z } from "@hono/zod-openapi";

export const HealthLiveResponseSchema = z
  .object({
    status: z.literal("ok").openapi({ example: "ok" }),
    requestId: z.string().openapi({ example: "3f2a…" }),
  })
  .openapi("HealthLiveResponse");

export const HealthReadyResponseSchema = z
  .object({
    status: z.literal("ok").openapi({ example: "ok" }),
    uptimeMs: z.number().int().nonnegative().openapi({ example: 12345 }),
    requestId: z.string().openapi({ example: "3f2a…" }),
  })
  .openapi("HealthReadyResponse");
