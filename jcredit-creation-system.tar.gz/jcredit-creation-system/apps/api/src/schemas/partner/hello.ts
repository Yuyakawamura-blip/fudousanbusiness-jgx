import { z } from "@hono/zod-openapi";

export const HelloQuerySchema = z.object({
  name: z.string().min(1).max(50).optional().openapi({ example: "Taro" }),
});

export const HelloResponseSchema = z
  .object({
    lane: z.literal("partner").openapi({ example: "partner" }),
    message: z.string().openapi({ example: "Hello, Taro" }),
  })
  .openapi("PartnerHelloResponse");
