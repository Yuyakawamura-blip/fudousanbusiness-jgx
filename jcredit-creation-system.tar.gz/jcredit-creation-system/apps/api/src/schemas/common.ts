import { z } from "@hono/zod-openapi";

/** onError が返すエラー形。全レーン共通の技術基盤 */
export const ErrorResponseSchema = z
  .object({
    error: z.object({
      code: z.string().openapi({ example: "validation_error" }),
      message: z.string().openapi({ example: "Request validation failed" }),
      issues: z.array(z.unknown()).optional(),
    }),
    requestId: z.string().openapi({ example: "3f2a…" }),
  })
  .openapi("ErrorResponse");

export const errorResponses = {
  400: {
    description: "リクエスト検証失敗",
    content: { "application/json": { schema: ErrorResponseSchema } },
  },
} as const;
