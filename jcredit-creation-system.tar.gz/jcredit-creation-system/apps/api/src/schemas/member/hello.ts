import { z } from "@hono/zod-openapi";

export const HelloQuerySchema = z.object({
  name: z.string().min(1).max(50).optional().openapi({ example: "Taro" }),
});

export const HelloResponseSchema = z
  .object({
    lane: z.literal("member").openapi({ example: "member" }),
    message: z.string().openapi({ example: "Hello, Taro" }),
  })
  .openapi("MemberHelloResponse");
