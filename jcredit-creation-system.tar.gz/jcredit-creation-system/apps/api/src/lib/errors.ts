import { HTTPException } from "hono/http-exception";
import type { ZodIssue } from "zod";

/** 業務エラーは Result 型ではなく throw する。onError(middleware/error-handler.ts)で統一捕捉 */
export class AppError extends HTTPException {
  constructor(
    status: 400 | 401 | 403 | 404 | 409 | 422,
    public readonly code: string,
    message: string,
  ) {
    super(status, { message });
  }
}

/** リクエスト検証失敗(zod)。validationHook が throw し、400 + issues で返す */
export class ValidationError extends AppError {
  constructor(public readonly issues: ZodIssue[]) {
    super(400, "validation_error", "Request validation failed");
  }
}

export const notFound = (what: string) => new AppError(404, "not_found", `${what} not found`);
