import { OpenAPIHono } from "@hono/zod-openapi";
import type { Env } from "hono";
import { validationHook } from "../middleware/error-handler.ts";

/**
 * `OpenAPIHono` の唯一の生成口。**`new OpenAPIHono()` を直に書かない**。
 *
 * `defaultHook`(リクエスト検証失敗を throw して onError に集約する)は**インスタンス単位**で、
 * `.route()` でマウントしても子には伝わらない。ルートを定義する sub-app は 1 つ残らずここを通す。
 * RPC 型は `.openapi()` のチェーンから推論されるので、ここを挟んでも型は変わらない。
 */
export function openApiApp<E extends Env = Env>(): OpenAPIHono<E> {
  return new OpenAPIHono<E>({ defaultHook: validationHook });
}
