import { createDb, resolveDatabaseUrl } from "@jcredit/db";
import { env } from "../env.ts";

/** DB 接続プール(全レーン共有の技術基盤)。接続先は検証済みの env から packages/db の規則で組み立てる */
export const db = createDb(
  resolveDatabaseUrl({
    DB_HOST: env.DB_HOST,
    DB_PORT: String(env.DB_PORT),
    DB_NAME: env.DB_NAME,
    DB_USER: env.DB_USER,
    DB_PASSWORD: env.DB_PASSWORD,
    DB_SSL: String(env.DB_SSL),
  }),
);
