import { readdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

/**
 * `new OpenAPIHono()` の直書きを禁止する。defaultHook はインスタンス単位で `.route()` では
 * 継承されないため、1 つでも素の生成が残るとその route だけ 400 の形が変わる。
 * 生成口は lib/openapi-app.ts の openApiApp() のみ。
 */
const SRC_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function walk(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = resolve(dir, e.name);
    if (e.isDirectory()) return walk(p);
    return /\.tsx?$/.test(e.name) ? [p] : [];
  });
}

describe("OpenAPIHono factory", () => {
  it("is only instantiated in lib/openapi-app.ts", () => {
    const offenders = walk(SRC_DIR)
      .filter((f) => !f.endsWith("lib/openapi-app.ts") && !f.includes("__tests__"))
      .filter((f) => /new\s+OpenAPIHono\b/.test(readFileSync(f, "utf8")));
    expect(offenders).toEqual([]);
  });
});
