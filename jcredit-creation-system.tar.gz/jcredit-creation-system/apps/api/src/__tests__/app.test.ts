import { describe, expect, it } from "vitest";
import { app } from "../app.ts";

describe("app", () => {
  it("GET /health/live returns ok with request id", async () => {
    const res = await app.request("/health/live");
    expect(res.status).toBe(200);
    expect(res.headers.get("x-request-id")).toBeTruthy();
    expect(await res.json()).toMatchObject({ status: "ok" });
  });

  it.each(["admin", "partner", "member"] as const)("GET /api/%s/hello", async (lane) => {
    const res = await app.request(`/api/${lane}/hello?name=Test`);
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ lane, message: "Hello, Test" });
  });

  it("rejects invalid query with 400 in the shared error shape", async () => {
    const res = await app.request("/api/admin/hello?name=");
    expect(res.status).toBe(400);
    const body = (await res.json()) as {
      error: { code: string; issues: unknown[] };
      requestId: string;
    };
    expect(body.error.code).toBe("validation_error");
    expect(body.error.issues.length).toBeGreaterThan(0);
    expect(body.requestId).toBeTruthy();
  });

  it("returns 404 for unknown paths in the shared error shape", async () => {
    const res = await app.request("/api/admin/nope");
    expect(res.status).toBe(404);
    const body = (await res.json()) as { error: { code: string }; requestId: string };
    expect(body.error.code).toBe("not_found");
    expect(body.requestId).toBe(res.headers.get("x-request-id"));
  });
});

describe("api docs", () => {
  it("GET /openapi.json lists every lane's routes", async () => {
    const res = await app.request("/openapi.json");
    expect(res.status).toBe(200);
    const spec = (await res.json()) as { openapi: string; paths: Record<string, unknown> };
    expect(spec.openapi).toBe("3.0.3");
    expect(Object.keys(spec.paths)).toEqual(
      expect.arrayContaining([
        "/health/live",
        "/health/ready",
        "/api/admin/hello",
        "/api/partner/hello",
        "/api/member/hello",
      ]),
    );
  });

  it("GET /docs serves Scalar (not Swagger UI)", async () => {
    const res = await app.request("/docs");
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain("scalar");
    expect(html).not.toContain("swagger-ui");
  });
});
