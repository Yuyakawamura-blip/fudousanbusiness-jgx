import { DB_DEFAULTS } from "@jcredit/db";
import { describe, expect, it } from "vitest";
import { parseEnv } from "../env.ts";

describe("parseEnv", () => {
  it("treats empty values as unset and falls back to defaults", () => {
    const env = parseEnv({ DB_PASSWORD: "", DB_PORT: "", PORT: "" });
    expect(env.DB_PASSWORD).toBe(DB_DEFAULTS.password);
    expect(env.DB_PORT).toBe(DB_DEFAULTS.port);
    expect(env.PORT).toBe(8787);
  });

  it("still rejects invalid values", () => {
    expect(() => parseEnv({ DB_PORT: "abc" })).toThrow();
  });
});
