import { readdirSync, readFileSync } from "node:fs";
import { dirname, posix, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { describe, expect, it } from "vitest";

/**
 * レーン分離の機械的ガード。
 *
 * API はレーン(admin / partner / member)ごとに routes / services / repositories / schemas を
 * 完全分離する。処理が同じでも共通化せず複製するのが正で、共有できるのは技術基盤
 * (env / lib / middleware 直下)のみ。ここでは「他レーンへの import」「層の逆流」に加え、
 * 技術基盤がドメイン(レーン層・DB テーブル)を知らないことを字句解析で検査する(ADR-0006)。
 */

const SRC_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const LANES = ["admin", "partner", "member"] as const;
const LANE_LAYERS = ["routes", "services", "repositories", "schemas"] as const;
/** 依存の向き。数値が小さいほど上位層。schemas は全層から参照してよい */
const LAYER_RANK: Record<string, number> = { routes: 0, services: 1, repositories: 2 };
/**
 * @jcredit/db のうち技術基盤が読んでよい export。これ以外(テーブル定義・enum)は
 * `export *` で同じ入口から出てくるため、名前で区別するしかない
 */
const DB_CLIENT_EXPORTS = new Set([
  "createDb",
  "Db",
  "DB_DEFAULTS",
  "loadRootEnvFiles",
  "resolveDatabaseUrl",
  "newId",
]);

type Lane = (typeof LANES)[number];

function walk(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = resolve(dir, e.name);
    if (e.isDirectory()) return e.name === "__tests__" ? [] : walk(p);
    return /\.tsx?$/.test(e.name) && !/\.test\.tsx?$/.test(e.name) ? [p] : [];
  });
}

function laneOf(relPath: string): { lane: Lane; layer: string } | null {
  const [layer, lane] = relPath.split("/");
  if (!layer || !lane) return null;
  if (!(LANE_LAYERS as readonly string[]).includes(layer)) return null;
  if (!(LANES as readonly string[]).includes(lane)) return null;
  return { lane: lane as Lane, layer };
}

function importsOf(file: string): string[] {
  const src = readFileSync(file, "utf8");
  return ts
    .preProcessFile(src, true, true)
    .importedFiles.map((f) => f.fileName)
    .filter((f) => f.startsWith("."));
}

function isInfra(relPath: string): boolean {
  return relPath === "env.ts" || relPath.startsWith("lib/") || relPath.startsWith("middleware/");
}

type ModuleBinding = { specifier: string; names: string[] | "namespace" };

/**
 * import / re-export の module specifier と、名前付き束縛を取り出す(default / namespace は "namespace")。
 * `import("...")` の動的 import は destructure 先の名前を静的に追えないため "namespace" 扱いにする
 * (レーン層チェックの `preProcessFile` が動的 import を拾うのと検出範囲を揃えるため)
 */
function bindingsOf(file: string): ModuleBinding[] {
  const src = readFileSync(file, "utf8");
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, false);
  const out: ModuleBinding[] = [];
  for (const st of sf.statements) {
    if (ts.isImportDeclaration(st) && ts.isStringLiteral(st.moduleSpecifier)) {
      const clause = st.importClause;
      const named = clause?.namedBindings;
      if (!clause || clause.name || (named && ts.isNamespaceImport(named))) {
        out.push({ specifier: st.moduleSpecifier.text, names: "namespace" });
      } else if (named && ts.isNamedImports(named)) {
        out.push({
          specifier: st.moduleSpecifier.text,
          names: named.elements.map((e) => (e.propertyName ?? e.name).text),
        });
      }
    } else if (
      ts.isExportDeclaration(st) &&
      st.moduleSpecifier &&
      ts.isStringLiteral(st.moduleSpecifier)
    ) {
      const clause = st.exportClause;
      out.push({
        specifier: st.moduleSpecifier.text,
        names:
          clause && ts.isNamedExports(clause)
            ? clause.elements.map((e) => (e.propertyName ?? e.name).text)
            : "namespace",
      });
    }
  }
  const visit = (node: ts.Node): void => {
    if (
      ts.isCallExpression(node) &&
      node.expression.kind === ts.SyntaxKind.ImportKeyword &&
      node.arguments[0] &&
      ts.isStringLiteralLike(node.arguments[0])
    ) {
      out.push({ specifier: node.arguments[0].text, names: "namespace" });
    }
    ts.forEachChild(node, visit);
  };
  ts.forEachChild(sf, visit);
  return out;
}

const files = walk(SRC_DIR).map((abs) => ({
  abs,
  rel: posix.normalize(relative(SRC_DIR, abs).split("\\").join("/")),
}));

describe("lane isolation", () => {
  it("never imports another lane's files", () => {
    const violations: string[] = [];
    for (const { abs, rel } of files) {
      const from = laneOf(rel);
      if (!from) continue;
      for (const spec of importsOf(abs)) {
        const target = posix.normalize(posix.join(posix.dirname(rel), spec));
        const to = laneOf(target);
        if (to && to.lane !== from.lane) violations.push(`${rel} -> ${target}`);
      }
    }
    expect(violations).toEqual([]);
  });

  it("keeps the layer direction routes -> services -> repositories", () => {
    const violations: string[] = [];
    for (const { abs, rel } of files) {
      const from = laneOf(rel);
      if (!from || LAYER_RANK[from.layer] === undefined) continue;
      for (const spec of importsOf(abs)) {
        const target = posix.normalize(posix.join(posix.dirname(rel), spec));
        const to = laneOf(target);
        if (!to || LAYER_RANK[to.layer] === undefined) continue;
        const fromRank = LAYER_RANK[from.layer] ?? 0;
        const toRank = LAYER_RANK[to.layer] ?? 0;
        if (toRank < fromRank) violations.push(`${rel} -> ${target}`);
        if (toRank - fromRank > 1) violations.push(`${rel} -> ${target} (skips a layer)`);
      }
    }
    expect(violations).toEqual([]);
  });
});

describe("technical infrastructure (env / lib / middleware)", () => {
  const infra = files.filter(({ rel }) => isInfra(rel));

  it("never imports routes / services / repositories / schemas", () => {
    const violations: string[] = [];
    for (const { abs, rel } of infra) {
      for (const spec of importsOf(abs)) {
        const target = posix.normalize(posix.join(posix.dirname(rel), spec));
        const [layer] = target.split("/");
        if (layer && (LANE_LAYERS as readonly string[]).includes(layer))
          violations.push(`${rel} -> ${target}`);
      }
    }
    expect(violations).toEqual([]);
  });

  it("reads only the client from @jcredit/db, never the schema", () => {
    const violations: string[] = [];
    for (const { abs, rel } of infra) {
      for (const { specifier, names } of bindingsOf(abs)) {
        if (specifier === "@jcredit/db/schema" || specifier.startsWith("@jcredit/db/schema/")) {
          violations.push(`${rel} -> ${specifier}`);
        } else if (specifier === "@jcredit/db") {
          if (names === "namespace")
            violations.push(`${rel} -> ${specifier} (namespace / default import)`);
          else
            for (const n of names)
              if (!DB_CLIENT_EXPORTS.has(n)) violations.push(`${rel} -> ${specifier} { ${n} }`);
        }
      }
    }
    expect(violations).toEqual([]);
  });
});
