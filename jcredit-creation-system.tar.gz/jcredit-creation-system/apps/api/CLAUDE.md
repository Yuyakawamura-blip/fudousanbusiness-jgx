# apps/api (Hono)

Web 3 アプリ共通の API サーバ。ポートは **8787**。

## ディレクトリ構成(`src/`)
```
routes/<lane>/       ルーティング層 — Hono ハンドラ。schemas で検証し services を呼ぶ。DB クエリを書かない
schemas/<lane>/      入出力の zod。OpenAPI と RPC 型(Web が type import)の元
services/<lane>/     業務ロジック — ドメインルール・ユースケース
repositories/<lane>/ 永続化 — Drizzle でテーブルを触るのはここだけ
middleware/          横断的関心事 — request-id / ログ / エラー整形(ドメインを知らない)
lib/                 技術基盤 — db 接続 / errors / logger / openapi-app(ドメインを知らない)
env.ts               環境変数(zod)
app.ts               3 レーンを mount(RPC 型の出所)
```

## レーン
- `admin`(`/api/admin`)= 運営者コンソール / `partner`(`/api/partner`)= 創出PTマイページ / `member`(`/api/member`)= 会員マイページ
- `routes / services / repositories / schemas` は**レーンごとに完全分離**。他レーンのファイルを import しない(`src/__tests__/lane-isolation.test.ts` が弾く)。処理が同じでも複製する
- 共有できるのは技術基盤のみ: `env.ts` / `lib/*` / `middleware/*` 直下(ドメイン知識を持たないもの)
- **`lib/` / `middleware/` に業務ロジックを置かない**。技術基盤は routes / services / repositories / schemas を import できず、`@jcredit/db` から読めるのは client(`createDb` / `newId` 等)だけでテーブル定義は読めない(同テストが弾く — ADR-0006)。レーン間で同じ処理を共通化したくなったら、それは業務ロジックなので `services/<lane>/` に複製する。`lib/` に置いてよいのは「送る仕組み」「呼ぶ仕組み」であって「何をいつ送るか」ではない
- 層の向きは `routes → services → repositories`。route に DB クエリを直書きしない

## ルール
- ルートは `@hono/zod-openapi` の `createRoute`(request / responses に zod schema を付ける)+ `lib/openapi-app.ts` の `openApiApp()`。**`new OpenAPIHono()` を直に書かない**(`__tests__/openapi-app-factory.test.ts` が弾く)。RPC 型は `app.ts` の `AdminRouter` 等を Web が `@jcredit/api/app` から type import する(`packages/shared` を経由しない — ADR-0005)
- API ドキュメントは **Scalar**(`/docs`、spec は `/openapi.json`)。Swagger UI は入れない。エラー形は `schemas/common.ts` の `errorResponses` を responses に spread する
- エラーは `lib/errors.ts` の `AppError` を throw(onError で統一整形)。Result 型は使わない
- DB は `lib/db.ts` の `db` を使う。スキーマ変更は `packages/db` で `pnpm db:generate`
- 環境変数は `src/env.ts`(zod、起動時 fail-fast)経由でのみ参照
