import { defineConfig } from "tsdown";

export default defineConfig({
  entry: ["src/index.ts"],
  outDir: "dist",
  format: "esm",
  target: "node24",
  platform: "node",
  // package.json が "type":"module" のため .js のままで ESM(start の dist/index.js 契約を維持)
  fixedExtension: false,
  // workspace パッケージは dist を持たず src/*.ts を直接 export しているため、
  // 外部化せずバンドルに含める(Node は node_modules 配下の型ストリッピングを拒否する)
  deps: {
    alwaysBundle: [/^@jcredit\//],
  },
  clean: true,
  dts: false,
  sourcemap: true,
  minify: false,
});
