# apps/member-portal (Next.js)

**会員マイページ**。App Router(RSC 既定)。dev ポートは **3000**。API レーンは `member`(`/api/member`)。

## ルール
- `app/` 配下は既定で RSC。クライアント機能は `_components/<Name>.client.tsx`(PascalCase)に切り出し、ロジックは `_hooks/useXxx.ts`(camelCase)へ分離する(Biome が強制)
- データ取得は `lib/api.ts` の `getApiClient()` 経由(サーバー側のみ。ブラウザから API を直接 fetch しない)。`cache: "no-store"`
- UI は必ず `packages/ui` の shadcn を先に確認。無ければ `packages/ui` に追加してから使う
- 画像は `next/image`、リンクは `next/link`
- 環境変数は `env.ts`(T3 env)経由
- 他の Web アプリ(apps/*)のコードを import しない。共通化は `packages/ui` / `packages/shared` へ
- 画面(`app/**`)を変更した PR には**変更前後のスクリーンショット**が必須(`/pr-screenshots`)。動的ルートは `screenshots.config.json` の `routeParams` にサンプル URL を登録する

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
