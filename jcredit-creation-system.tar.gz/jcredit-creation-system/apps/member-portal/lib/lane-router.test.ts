import { readdirSync, readFileSync } from "node:fs";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { describe, expect, it } from "vitest";

/**
 * レーン境界の機械的ガード(ADR-0005)。
 * このアプリが `@jcredit/api` から読んでよいのは自レーンのルータ型だけ、しかも type import のみ
 * (値 import は API のランタイムを Web のバンドルに引き込む)。他レーンの Router を
 * 使うと別レーンのエンドポイント型で呼び出しが書けてしまうため、静的解析で弾く。
 */

const APP_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const LANE_ROUTER = "MemberRouter";
const API_PACKAGE_RE = /^@jcredit\/api(\/|$)/;
const SKIP_DIRS = new Set(["node_modules", ".next", "e2e", "playwright-report", "test-results"]);

function walk(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = resolve(dir, e.name);
    if (e.isDirectory()) return SKIP_DIRS.has(e.name) ? [] : walk(p);
    return /\.tsx?$/.test(e.name) && !/\.test\.tsx?$/.test(e.name) ? [p] : [];
  });
}

type ApiImport = { file: string; names: string[]; typeOnly: boolean };

function apiImportsOf(file: string): ApiImport[] {
  const source = ts.createSourceFile(
    file,
    readFileSync(file, "utf8"),
    ts.ScriptTarget.Latest,
    true,
  );
  const found: ApiImport[] = [];
  for (const stmt of source.statements) {
    if (!ts.isImportDeclaration(stmt) || !ts.isStringLiteral(stmt.moduleSpecifier)) continue;
    if (!API_PACKAGE_RE.test(stmt.moduleSpecifier.text)) continue;
    const clause = stmt.importClause;
    const bindings = clause?.namedBindings;
    const named = bindings && ts.isNamedImports(bindings) ? bindings.elements : [];
    // default import / namespace import は名前で判定できないので、それ自体を違反として名前に残す
    const names = [
      ...(clause?.name ? [`default:${clause.name.text}`] : []),
      ...(bindings && ts.isNamespaceImport(bindings) ? [`namespace:${bindings.name.text}`] : []),
      ...named.map((el) => (el.propertyName ?? el.name).text),
    ];
    const typeOnly =
      clause?.isTypeOnly === true || (named.length > 0 && named.every((el) => el.isTypeOnly));
    found.push({ file: relative(APP_DIR, file), names, typeOnly });
  }
  return found;
}

describe(`@jcredit/api から読むのは ${LANE_ROUTER} の type import だけ`, () => {
  const imports = walk(APP_DIR).flatMap(apiImportsOf);

  it("他レーンの Router やルータ型以外を import していない", () => {
    const offenders = imports.flatMap((i) =>
      i.names.filter((n) => n !== LANE_ROUTER).map((n) => `${i.file} -> ${n}`),
    );
    expect(offenders).toEqual([]);
  });

  it("値 import が無い(型のみ)", () => {
    const offenders = imports.filter((i) => !i.typeOnly).map((i) => i.file);
    expect(offenders).toEqual([]);
  });
});
