import "server-only";
import type { MemberRouter } from "@jcredit/api/app";
import { createApiClient } from "@jcredit/shared";
import { headers } from "next/headers";
import { env } from "@/env";

/**
 * RSC / Server Action / Route Handler 専用の API クライアント(member レーン)。
 * リクエスト毎に新しいインスタンスを作り、x-request-id を上流に転送する。
 * 認証を入れるときは httpOnly cookie のセッションをここで Authorization: Bearer に変換する
 * (ブラウザは cookie を apps/api に直接送らない)。
 */
export async function getApiClient() {
  const h = await headers();
  const requestId = h.get("x-request-id");

  return createApiClient<MemberRouter>(`${env.INTERNAL_API_URL}/api/member`, {
    headers: {
      ...(requestId ? { "x-request-id": requestId } : {}),
    },
    // RSC の fetch キャッシュは明示的に opt-in する方が事故が少ない
    cache: "no-store",
  });
}
