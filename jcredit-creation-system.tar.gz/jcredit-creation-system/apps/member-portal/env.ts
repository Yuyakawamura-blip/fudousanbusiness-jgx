import { createEnv } from "@t3-oss/env-nextjs";
import { z } from "zod";

export const env = createEnv({
  server: {
    NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
    // RSC / Server Action からの内部呼び出し用。ブラウザから API を直接呼ばない
    INTERNAL_API_URL: z.string().url().default("http://localhost:8787"),
  },
  client: {
    NEXT_PUBLIC_APP_NAME: z.string().default("会員マイページ"),
  },
  runtimeEnv: {
    NODE_ENV: process.env.NODE_ENV,
    INTERNAL_API_URL: process.env.INTERNAL_API_URL,
    NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  },
  emptyStringAsUndefined: true,
  skipValidation: process.env.SKIP_ENV_VALIDATION === "true",
});
