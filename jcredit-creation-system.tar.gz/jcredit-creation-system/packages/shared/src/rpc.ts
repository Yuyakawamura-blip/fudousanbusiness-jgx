import type { Hono } from "hono";
import { hc } from "hono/client";

// FIXME(any): hono/client の `hc` 自体が `T extends Hono<any, any, any>` を要求するため、
// 呼び出し側でレーン別ルータ型(AdminRouter 等)を受け取れるようにするには同じ制約が必要。
type AnyHono = Hono<any, any, any>;

/**
 * 型付き API クライアント。web 側(RSC / Server Action)で:
 *   import type { AdminRouter } from "@jcredit/api/app";
 *   const api = createApiClient<AdminRouter>(`${env.INTERNAL_API_URL}/api/admin`);
 *   const res = await api.hello.$get({ query: { name: "J" } });
 *
 * baseUrl にはレーンの prefix(`/api/admin` 等)を含める。
 * ルータ型はここで re-export しない — shared が apps/api に依存すると api → shared と
 * 循環になり、turbo の `^` 依存が使えなくなる(ADR-0005)。
 *
 * 注意: `init.headers` は `hc()` の `{ init }` 経由では渡さない — `hc()` は内部で
 * `fetch(url, { headers, ...opt.init })` と組み立てるため、`init` に `headers` を含めると
 * 自動生成ヘッダ(`Content-Type: application/json` 等)をまるごと上書きしてしまう。
 * また `hc()` の `headers` はプレーンオブジェクト前提(内部でスプレッドする)なので、
 * `Headers` インスタンスや配列で渡されても落ちないよう `Headers` を経由して正規化する。
 */
export const createApiClient = <T extends AnyHono>(baseUrl: string, init?: RequestInit) => {
  const { headers, ...restInit } = init ?? {};
  return hc<T>(baseUrl, {
    ...(headers ? { headers: Object.fromEntries(new Headers(headers)) } : {}),
    ...(Object.keys(restInit).length > 0 ? { init: restInit } : {}),
  });
};

export type ApiClient<T extends AnyHono> = ReturnType<typeof createApiClient<T>>;
