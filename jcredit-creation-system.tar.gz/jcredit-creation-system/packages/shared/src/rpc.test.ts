import { describe, expect, it } from "vitest";
import { createApiClient } from "./rpc.ts";

/** fetch を差し替えて、hc が組み立てたリクエストヘッダを回収する */
async function sentHeaders(init: RequestInit): Promise<Record<string, string>> {
  let captured: Headers | undefined;
  const fetchSpy: typeof fetch = async (_url, reqInit) => {
    captured = new Headers(reqInit?.headers);
    return new Response("{}", { headers: { "content-type": "application/json" } });
  };
  const api = createApiClient("http://api.test/api/admin", init);
  // FIXME(any): テストでは実ルータ型を持たないため、hc の proxy を型なしで辿る
  const client = api as any;
  await client.hello.$get({}, { fetch: fetchSpy });
  return Object.fromEntries(captured ?? new Headers());
}

describe("createApiClient", () => {
  it("プレーンオブジェクトのヘッダをそのまま送る", async () => {
    const h = await sentHeaders({ headers: { "x-request-id": "req-1" } });
    expect(h["x-request-id"]).toBe("req-1");
  });

  it("Headers インスタンスも送られる", async () => {
    const h = await sentHeaders({ headers: new Headers({ "x-request-id": "req-2" }) });
    expect(h["x-request-id"]).toBe("req-2");
  });

  it("配列形式も送られる(`0: ...` にならない)", async () => {
    const h = await sentHeaders({ headers: [["x-request-id", "req-3"]] });
    expect(h["x-request-id"]).toBe("req-3");
    expect(h["0"]).toBeUndefined();
  });

  it("headers 以外の init は fetch に渡される", async () => {
    let captured: RequestInit | undefined;
    const fetchSpy: typeof fetch = async (_url, reqInit) => {
      captured = reqInit;
      return new Response("{}", { headers: { "content-type": "application/json" } });
    };
    // FIXME(any): 同上
    const client = createApiClient("http://api.test/api/admin", { cache: "no-store" }) as any;
    await client.hello.$get({}, { fetch: fetchSpy });
    expect(captured?.cache).toBe("no-store");
  });
});
