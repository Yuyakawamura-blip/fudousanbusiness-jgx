import { readdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { describe, expect, it } from "vitest";

/**
 * `packages/shared` が `apps/*` に依存しないことの機械的ガード(ADR-0005)。
 * shared → api の辺があると api → shared と循環し、turbo の `^` 依存(transit)が
 * `Cyclic dependency detected` で使えなくなる。turbo 自身は警告しか出さないのでここで弾く。
 */

const PKG_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const SRC_DIR = resolve(PKG_DIR, "src");
const APP_PACKAGE_RE = /^@jcredit\/(api|admin-console|partner-console|member-portal)(\/|$)/;

function walk(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = resolve(dir, e.name);
    if (e.isDirectory()) return e.name === "__tests__" ? [] : walk(p);
    return /\.tsx?$/.test(e.name) && !/\.test\.tsx?$/.test(e.name) ? [p] : [];
  });
}

function importsOf(file: string): string[] {
  const info = ts.preProcessFile(readFileSync(file, "utf8"), true, true);
  return info.importedFiles.map((f) => f.fileName);
}

describe("packages/shared は apps/* に依存しない", () => {
  it("package.json に apps のワークスペースパッケージが無い", () => {
    const pkg = JSON.parse(readFileSync(resolve(PKG_DIR, "package.json"), "utf8"));
    const names = Object.keys({
      ...pkg.dependencies,
      ...pkg.devDependencies,
      ...pkg.peerDependencies,
    });
    expect(names.filter((n) => APP_PACKAGE_RE.test(n))).toEqual([]);
  });

  it("src に apps のパッケージを import するファイルが無い(type import も含む)", () => {
    const offenders = walk(SRC_DIR).flatMap((file) =>
      importsOf(file)
        .filter((spec) => APP_PACKAGE_RE.test(spec) || spec.includes("/apps/"))
        .map((spec) => `${file.slice(PKG_DIR.length + 1)} -> ${spec}`),
    );
    expect(offenders).toEqual([]);
  });
});
