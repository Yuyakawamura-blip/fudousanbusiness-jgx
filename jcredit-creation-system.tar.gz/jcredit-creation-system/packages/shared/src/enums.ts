/**
 * 列挙値の正。DB は text + CHECK(packages/db の enumCheck)、API は zod の enum で参照する。
 * 値を増やすときはここだけを変更し、DB は `pnpm db:generate --name <意味名>` で追随させる。
 */

/** デプロイ環境(APP_ENV)。ブランチとの対応は docs/branching.md */
export const APP_ENVS = ["local", "dev", "stg", "prd"] as const;
export type AppEnv = (typeof APP_ENVS)[number];

/** API のレーン = 利用者区分。各 Web アプリと 1:1 で対応する */
export const API_LANES = ["admin", "partner", "member"] as const;
export type ApiLane = (typeof API_LANES)[number];

/** 会員種別(members.member_type) */
export const MEMBER_TYPES = ["INDIVIDUAL", "CORPORATE"] as const;
export type MemberType = (typeof MEMBER_TYPES)[number];

/** 会員状態(members.member_status)。遷移は docs/design/detailed/db/identity.md */
export const MEMBER_STATUSES = ["PRE_REGISTERED", "PROVISIONAL", "ACTIVE", "WITHDRAWN"] as const;
export type MemberStatus = (typeof MEMBER_STATUSES)[number];

/** 表示ブランド区分(members.brand_type)。会員募集の 3 種(一般・東京商工会議所・日本商工会議所)と対応する */
export const BRAND_TYPES = ["GENERAL", "TOKYO_CCI", "JCCI"] as const;
export type BrandType = (typeof BRAND_TYPES)[number];

/** 創出PTの利用状態(partners.partner_status) */
export const ORGANIZATION_STATUSES = ["INVITED", "ACTIVE", "TERMINATED"] as const;
export type OrganizationStatus = (typeof ORGANIZATION_STATUSES)[number];

/** ユーザーのアカウント状態(*_users.account_status)。ロック中は locked_until で判定し、状態には持たない */
export const ACCOUNT_STATUSES = ["ACTIVE", "DISABLED"] as const;
export type AccountStatus = (typeof ACCOUNT_STATUSES)[number];

/** ロール名(roles.role_name)。`admin` は運営者を指すため、管理者は ADMIN ではなく MANAGER */
export const ROLE_NAMES = ["MANAGER", "STAFF"] as const;
export type RoleName = (typeof ROLE_NAMES)[number];

/** 設備区分コード(equipment_types.equipment_type_code) */
export const EQUIPMENT_TYPE_CODES = ["SOLAR", "LED"] as const;
export type EquipmentTypeCode = (typeof EQUIPMENT_TYPE_CODES)[number];

/** プロジェクト定義の募集状態(project_definitions.recruitment_status)。遷移は docs/design/detailed/db/project.md */
export const RECRUITMENT_STATUSES = ["DRAFT", "OPEN", "SUSPENDED", "CLOSED"] as const;
export type RecruitmentStatus = (typeof RECRUITMENT_STATUSES)[number];

/** プロジェクトの状態(projects.status) */
export const PROJECT_STATUSES = ["ACTIVE", "CLOSED"] as const;
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];

/** 規約種別(terms_versions.terms_type)。TERMS_OF_USE / PRIVACY_POLICY は全プロジェクト共通で、ほかはプロジェクト定義ごと */
export const TERMS_TYPES = [
  "TERMS_OF_USE",
  "PRIVACY_POLICY",
  "MEMBER_AGREEMENT",
  "SERVICE_CONSENT",
  "DECLARATION",
] as const;
export type TermsType = (typeof TERMS_TYPES)[number];

/** 全プロジェクト共通の規約種別(terms_versions.project_definition_id が NULL のもの) */
export const COMMON_TERMS_TYPES = [
  "TERMS_OF_USE",
  "PRIVACY_POLICY",
] as const satisfies readonly TermsType[];

/** 必要書類の必須区分(document_requirements.requirement_type) */
export const DOCUMENT_REQUIREMENT_TYPES = ["REQUIRED", "OPTIONAL"] as const;
export type DocumentRequirementType = (typeof DOCUMENT_REQUIREMENT_TYPES)[number];

/** ユーザーの種別(*_by_user_type)。どのユーザー表の id かを示し、FK を張れない「種別 + ID」の参照に使う */
export const USER_TYPES = ["MEMBER", "PARTNER", "ADMIN"] as const;
export type UserType = (typeof USER_TYPES)[number];

/** 招待の状態(*_invitations.status)。期限切れは状態に持たず、expires_at で判定する */
export const INVITATION_STATUSES = ["INVITED", "REGISTERED", "CANCELLED"] as const;
export type InvitationStatus = (typeof INVITATION_STATUSES)[number];

/** 参加申請の状態(participation_requests.status)。遷移は docs/design/detailed/db/application.md */
export const PARTICIPATION_REQUEST_STATUSES = ["PENDING", "LINKED", "REMOVED"] as const;
export type ParticipationRequestStatus = (typeof PARTICIPATION_REQUEST_STATUSES)[number];

/**
 * 申込・参加の状態(project_applications.application_status)。遷移は docs/design/detailed/db/application.md。
 * 一次・二次のどちらの審査中かは状態に持たず、審査(reviews)の審査段階で表す
 */
export const APPLICATION_STATUSES = [
  "DRAFT",
  "UNDER_REVIEW",
  "RETURNED",
  "PARTICIPATING",
  "REJECTED",
  "EXPIRED",
  "WITHDRAWN",
] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

/** 審査段階(reviews.review_stage)。申込の審査だけが持ち、会員基本情報申請・創出PT情報申請の審査は NULL */
export const REVIEW_STAGES = ["FIRST", "SECOND"] as const;
export type ReviewStage = (typeof REVIEW_STAGES)[number];

/** 審査結果(reviews.review_result) */
export const REVIEW_RESULTS = ["APPROVED", "REJECTED", "RETURNED"] as const;
export type ReviewResult = (typeof REVIEW_RESULTS)[number];

/**
 * 会員基本情報申請・創出PT情報申請の状態(*_info_requests.request_status)。遷移は docs/design/detailed/db/review.md。
 * 判定後の値は審査結果と同じ
 */
export const INFO_REQUEST_STATUSES = ["SUBMITTED", "APPROVED", "REJECTED", "RETURNED"] as const;
export type InfoRequestStatus = (typeof INFO_REQUEST_STATUSES)[number];

/** 会員基本情報申請の種別(member_basic_info_requests.request_type) */
export const MEMBER_BASIC_INFO_REQUEST_TYPES = ["REGISTRATION", "CHANGE"] as const;
export type MemberBasicInfoRequestType = (typeof MEMBER_BASIC_INFO_REQUEST_TYPES)[number];

/** 書類枠の状態(document_slots.slot_status)。遷移は docs/design/detailed/db/facility.md */
export const DOCUMENT_SLOT_STATUSES = ["NOT_SUBMITTED", "SUBMITTED", "NOT_APPLICABLE"] as const;
export type DocumentSlotStatus = (typeof DOCUMENT_SLOT_STATUSES)[number];

/** 証跡書類の確認状態(evidence_documents.verification_status)。運営者が審査で中身を確認したか */
export const EVIDENCE_VERIFICATION_STATUSES = ["UNVERIFIED", "VERIFIED"] as const;
export type EvidenceVerificationStatus = (typeof EVIDENCE_VERIFICATION_STATUSES)[number];

/** 通知種別の配信先(notification_types.delivery_destination)。メールだけの通知(認証 URL 等)は通知の行を作らない */
export const NOTIFICATION_DELIVERY_DESTINATIONS = ["EMAIL_AND_SYSTEM", "SYSTEM_ONLY"] as const;
export type NotificationDeliveryDestination = (typeof NOTIFICATION_DELIVERY_DESTINATIONS)[number];

/**
 * 通知の分類(notification_types.category)。通知一覧の分類列・絞り込みに使い、3 アプリで共通。
 * 機能要件一覧の通知一覧の分類(8 種)は絞り込みには細かいので、機能要件で創出PT の通知一覧のフィルターに挙がっている 4 グループにまとめる
 */
export const NOTIFICATION_CATEGORIES = [
  "APPLICATION",
  "INQUIRY",
  "ACCOUNT",
  "ANNOUNCEMENT",
] as const;
export type NotificationCategory = (typeof NOTIFICATION_CATEGORIES)[number];

/** 通知の配信対象区分(notifications.audience_type)。INDIVIDUAL のときだけ宛先ユーザーを持つ */
export const NOTIFICATION_AUDIENCE_TYPES = ["ALL", "PROJECT", "INDIVIDUAL"] as const;
export type NotificationAudienceType = (typeof NOTIFICATION_AUDIENCE_TYPES)[number];

/** 通知の状態(notifications.status)。遷移は docs/design/detailed/db/notification.md */
export const NOTIFICATION_STATUSES = ["DRAFT", "SCHEDULED", "SENT", "WITHDRAWN"] as const;
export type NotificationStatus = (typeof NOTIFICATION_STATUSES)[number];

/** 問い合わせ状態(inquiries.inquiry_status) */
export const INQUIRY_STATUSES = ["OPEN", "IN_PROGRESS", "ANSWERED", "COMPLETED"] as const;
export type InquiryStatus = (typeof INQUIRY_STATUSES)[number];

/** 問い合わせ種別(inquiries.inquiry_type)。会員・創出PTで共通 */
export const INQUIRY_TYPES = [
  "ACCOUNT",
  "REGISTRATION",
  "PROJECT",
  "APPLICATION",
  "WITHDRAWAL",
  "SYSTEM",
  "OTHER",
] as const;
export type InquiryType = (typeof INQUIRY_TYPES)[number];

/** FAQ の公開先区分(faqs.audience_scope) */
export const FAQ_AUDIENCE_SCOPES = ["COMMON", "MEMBER", "PARTNER"] as const;
export type FaqAudienceScope = (typeof FAQ_AUDIENCE_SCOPES)[number];

/** メンテナンスモードの対象サイト(site_maintenance_modes.target_site)。運営者コンソールは対象外 */
export const MAINTENANCE_TARGET_SITES = ["MEMBER_PORTAL", "PARTNER_CONSOLE"] as const;
export type MaintenanceTargetSite = (typeof MAINTENANCE_TARGET_SITES)[number];
