/** application クラスタ: 参加申請・申込・確認事項・提出版・同意ログ。設計は docs/design/detailed/db/application.md */

import {
  APPLICATION_STATUSES,
  PARTICIPATION_REQUEST_STATUSES,
  USER_TYPES,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  date,
  foreignKey,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  unique,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { adminUsers, members, memberUsers, partnerBranches } from "./identity.ts";
import { projects, recruitmentPeriods, termsVersions } from "./project.ts";

export const participationRequests = pgTable(
  "participation_requests",
  {
    id: idPk(),
    memberId: text()
      .notNull()
      .references(() => members.id),
    projectId: text()
      .notNull()
      .references(() => projects.id),
    memberUserId: text()
      .notNull()
      .references(() => memberUsers.id),
    status: text().notNull().default("PENDING"),
    requestedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    linkedAt: timestamp({ withTimezone: true }),
    removedByAdminUserId: text(),
    removedAt: timestamp({ withTimezone: true }),
    partnerBranchId: text().references(() => partnerBranches.id),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "participation_requests_removed_by_fk",
      columns: [t.removedByAdminUserId],
      foreignColumns: [adminUsers.id],
    }),
    uniqueIndex("participation_requests_active_unique")
      .on(t.memberId, t.projectId)
      .where(sql`${t.status} in ('PENDING', 'LINKED')`),
    index().on(t.memberId),
    index().on(t.projectId),
    index().on(t.memberUserId),
    index().on(t.removedByAdminUserId),
    index().on(t.partnerBranchId),
    enumCheck("participation_requests_status_check", t.status, PARTICIPATION_REQUEST_STATUSES),
    check(
      "participation_requests_linked_check",
      sql`(${t.status} = 'PENDING') = (${t.linkedAt} is null)`,
    ),
    check(
      "participation_requests_removed_check",
      sql`num_nonnulls(${t.removedByAdminUserId}, ${t.removedAt}) = case when ${t.status} = 'REMOVED' then 2 else 0 end`,
    ),
  ],
);

export const projectApplications = pgTable(
  "project_applications",
  {
    id: idPk(),
    participationRequestId: text().notNull(),
    recruitmentPeriodId: text(),
    memberUserId: text()
      .notNull()
      .references(() => memberUsers.id),
    // unique() の既定の名前は casing を通らず camelCase の列名になるため、snake_case で付ける
    applicationNumber: text().notNull().unique("project_applications_application_number_unique"),
    applicationStatus: text().notNull().default("DRAFT"),
    submittedAt: timestamp({ withTimezone: true }),
    joinedOn: date(),
    effectiveTo: date(),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "project_applications_participation_request_fk",
      columns: [t.participationRequestId],
      foreignColumns: [participationRequests.id],
    }),
    foreignKey({
      name: "project_applications_recruitment_period_fk",
      columns: [t.recruitmentPeriodId],
      foreignColumns: [recruitmentPeriods.id],
    }),
    index().on(t.participationRequestId),
    index().on(t.recruitmentPeriodId),
    index().on(t.memberUserId),
    enumCheck(
      "project_applications_application_status_check",
      t.applicationStatus,
      APPLICATION_STATUSES,
    ),
    check(
      "project_applications_submitted_check",
      sql`(${t.applicationStatus} = 'DRAFT') = (${t.submittedAt} is null) and (${t.applicationStatus} = 'DRAFT' or ${t.recruitmentPeriodId} is not null)`,
    ),
    check(
      "project_applications_joined_check",
      sql`(${t.applicationStatus} in ('PARTICIPATING', 'WITHDRAWN')) = (${t.joinedOn} is not null)`,
    ),
    check("project_applications_effective_range_check", sql`${t.joinedOn} <= ${t.effectiveTo}`),
  ],
);

export const applicationConfirmations = pgTable(
  "application_confirmations",
  {
    id: idPk(),
    projectApplicationId: text().notNull(),
    hasAgreedAllTerms: boolean().notNull().default(false),
    isKeidanrenCnPlanParticipant: boolean(),
    isSpecifiedEmitter: boolean(),
    specifiedEmitterCode: text(),
    energyConservationStatus: text(),
    energyBusinessNumber: text(),
    energyFactoryNumber: text(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "application_confirmations_project_application_fk",
      columns: [t.projectApplicationId],
      foreignColumns: [projectApplications.id],
    }),
    unique("application_confirmations_project_application_id_unique").on(t.projectApplicationId),
  ],
);

export const applicationSubmissions = pgTable(
  "application_submissions",
  {
    id: idPk(),
    projectApplicationId: text().notNull(),
    memberUserId: text()
      .notNull()
      .references(() => memberUsers.id),
    submittedContent: jsonb().notNull(),
    submittedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "application_submissions_project_application_fk",
      columns: [t.projectApplicationId],
      foreignColumns: [projectApplications.id],
    }),
    index().on(t.projectApplicationId),
    index().on(t.memberUserId),
  ],
);

export const consentRecords = pgTable(
  "consent_records",
  {
    id: idPk(),
    termsVersionId: text()
      .notNull()
      .references(() => termsVersions.id),
    memberId: text().references(() => members.id),
    projectApplicationId: text(),
    consentedByUserType: text().notNull(),
    consentedByUserId: text().notNull(),
    agreedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "consent_records_project_application_fk",
      columns: [t.projectApplicationId],
      foreignColumns: [projectApplications.id],
    }),
    index().on(t.termsVersionId),
    index().on(t.memberId),
    index().on(t.projectApplicationId),
    index("consent_records_consented_by_index").on(t.consentedByUserType, t.consentedByUserId),
    enumCheck("consent_records_consented_by_user_type_check", t.consentedByUserType, USER_TYPES),
  ],
);
