/** notification クラスタ: 通知・問い合わせ・FAQ・メンテナンスモード。設計は docs/design/detailed/db/notification.md */

import {
  FAQ_AUDIENCE_SCOPES,
  INQUIRY_STATUSES,
  INQUIRY_TYPES,
  MAINTENANCE_TARGET_SITES,
  NOTIFICATION_AUDIENCE_TYPES,
  NOTIFICATION_CATEGORIES,
  NOTIFICATION_DELIVERY_DESTINATIONS,
  NOTIFICATION_STATUSES,
  USER_TYPES,
  type UserType,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  foreignKey,
  index,
  pgTable,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { adminUsers, members, partners } from "./identity.ts";
import { projectDefinitions, projects } from "./project.ts";

const INQUIRY_PARTICIPANTS = ["MEMBER", "PARTNER", "ADMIN"] as const satisfies readonly UserType[];

const INQUIRY_RECIPIENTS = ["MEMBER", "PARTNER"] as const satisfies readonly UserType[];

export const notificationTypes = pgTable(
  "notification_types",
  {
    id: idPk(),
    category: text().notNull(),
    typeName: text().notNull().unique("notification_types_type_name_unique"),
    deliveryDestination: text().notNull(),
    ...timestamps,
  },
  (t) => [
    enumCheck("notification_types_category_check", t.category, NOTIFICATION_CATEGORIES),
    enumCheck(
      "notification_types_delivery_destination_check",
      t.deliveryDestination,
      NOTIFICATION_DELIVERY_DESTINATIONS,
    ),
  ],
);

export const notifications = pgTable(
  "notifications",
  {
    id: idPk(),
    notificationTypeId: text()
      .notNull()
      .references(() => notificationTypes.id),
    adminUserId: text().references(() => adminUsers.id),
    projectId: text().references(() => projects.id),
    projectDefinitionId: text().references(() => projectDefinitions.id),
    subject: text().notNull(),
    body: text().notNull(),
    audienceType: text().notNull(),
    recipientUserType: text(),
    recipientUserId: text(),
    status: text().notNull(),
    scheduledAt: timestamp({ withTimezone: true }),
    readAt: timestamp({ withTimezone: true }),
    ...timestamps,
  },
  (t) => [
    index().on(t.notificationTypeId),
    index().on(t.adminUserId),
    index().on(t.projectId),
    index().on(t.projectDefinitionId),
    index("notifications_recipient_index").on(t.recipientUserType, t.recipientUserId),
    enumCheck("notifications_audience_type_check", t.audienceType, NOTIFICATION_AUDIENCE_TYPES),
    enumCheck("notifications_recipient_user_type_check", t.recipientUserType, USER_TYPES),
    enumCheck("notifications_status_check", t.status, NOTIFICATION_STATUSES),
    check(
      "notifications_recipient_check",
      sql`num_nonnulls(${t.recipientUserType}, ${t.recipientUserId}) = case when ${t.audienceType} = 'INDIVIDUAL' then 2 else 0 end`,
    ),
    check(
      "notifications_project_check",
      sql`num_nonnulls(${t.projectId}, ${t.projectDefinitionId}) = case when ${t.audienceType} = 'PROJECT' then 1 else 0 end`,
    ),
    check(
      "notifications_scheduled_at_check",
      sql`${t.status} = 'DRAFT' or ${t.scheduledAt} is not null`,
    ),
    check(
      "notifications_withdrawn_check",
      sql`${t.status} <> 'WITHDRAWN' or ${t.audienceType} <> 'INDIVIDUAL'`,
    ),
    check(
      "notifications_read_at_check",
      sql`${t.audienceType} = 'INDIVIDUAL' or ${t.readAt} is null`,
    ),
  ],
);

export const notificationReads = pgTable(
  "notification_reads",
  {
    id: idPk(),
    notificationId: text()
      .notNull()
      .references(() => notifications.id),
    userType: text().notNull(),
    userId: text().notNull(),
    readAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    unique("notification_reads_user_notification_unique").on(
      t.userType,
      t.userId,
      t.notificationId,
    ),
    enumCheck("notification_reads_user_type_check", t.userType, USER_TYPES),
  ],
);

export const inquiries = pgTable(
  "inquiries",
  {
    id: idPk(),
    inquiryNumber: text().notNull().unique("inquiries_inquiry_number_unique"),
    memberId: text().references(() => members.id),
    partnerId: text().references(() => partners.id),
    assignedAdminUserId: text().references(() => adminUsers.id),
    inquiryType: text(),
    subject: text().notNull(),
    body: text().notNull(),
    inquiryStatus: text().notNull().default("OPEN"),
    openedByUserType: text().notNull(),
    openedByUserId: text().notNull(),
    recipientUserType: text().notNull(),
    recipientUserId: text().notNull(),
    recipientLastReadAt: timestamp({ withTimezone: true }),
    ...timestamps,
  },
  (t) => [
    index().on(t.memberId),
    index().on(t.partnerId),
    index().on(t.assignedAdminUserId),
    index("inquiries_opened_by_index").on(t.openedByUserType, t.openedByUserId),
    index("inquiries_recipient_index").on(t.recipientUserType, t.recipientUserId),
    enumCheck("inquiries_inquiry_type_check", t.inquiryType, INQUIRY_TYPES),
    enumCheck("inquiries_inquiry_status_check", t.inquiryStatus, INQUIRY_STATUSES),
    enumCheck("inquiries_opened_by_user_type_check", t.openedByUserType, INQUIRY_PARTICIPANTS),
    enumCheck("inquiries_recipient_user_type_check", t.recipientUserType, INQUIRY_RECIPIENTS),
    check("inquiries_counterpart_check", sql`num_nonnulls(${t.memberId}, ${t.partnerId}) <= 1`),
    check(
      "inquiries_inquiry_type_required_check",
      sql`${t.openedByUserType} = 'ADMIN' or ${t.inquiryType} is not null`,
    ),
    check(
      "inquiries_recipient_check",
      sql`${t.openedByUserType} = 'ADMIN' or (${t.recipientUserType} = ${t.openedByUserType} and ${t.recipientUserId} = ${t.openedByUserId})`,
    ),
  ],
);

export const inquiryMessages = pgTable(
  "inquiry_messages",
  {
    id: idPk(),
    inquiryId: text()
      .notNull()
      .references(() => inquiries.id),
    postedByUserType: text().notNull(),
    postedByUserId: text().notNull(),
    body: text().notNull(),
    postedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    index().on(t.inquiryId, t.postedAt),
    enumCheck(
      "inquiry_messages_posted_by_user_type_check",
      t.postedByUserType,
      INQUIRY_PARTICIPANTS,
    ),
  ],
);

export const faqs = pgTable(
  "faqs",
  {
    id: idPk(),
    question: text().notNull(),
    answer: text().notNull(),
    audienceScope: text().notNull().default("COMMON"),
    ...timestamps,
  },
  (t) => [enumCheck("faqs_audience_scope_check", t.audienceScope, FAQ_AUDIENCE_SCOPES)],
);

export const siteMaintenanceModes = pgTable(
  "site_maintenance_modes",
  {
    id: idPk(),
    targetSite: text().notNull(),
    isUnderMaintenance: boolean().notNull().default(false),
    displayText: text(),
    startsAt: timestamp({ withTimezone: true }),
    endsAt: timestamp({ withTimezone: true }),
    switchedByAdminUserId: text(),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "site_maintenance_modes_switched_by_fk",
      columns: [t.switchedByAdminUserId],
      foreignColumns: [adminUsers.id],
    }),
    unique("site_maintenance_modes_target_site_unique").on(t.targetSite),
    index().on(t.switchedByAdminUserId),
    enumCheck("site_maintenance_modes_target_site_check", t.targetSite, MAINTENANCE_TARGET_SITES),
    check(
      "site_maintenance_modes_starts_at_check",
      sql`not ${t.isUnderMaintenance} or ${t.startsAt} is not null`,
    ),
    check("site_maintenance_modes_period_check", sql`${t.endsAt} > ${t.startsAt}`),
  ],
);
