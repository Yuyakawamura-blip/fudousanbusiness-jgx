/** project クラスタ: プロジェクト定義と創出PTごとのプロジェクト、募集期・規約の版・必要書類・設備区分。設計は docs/design/detailed/db/project.md */

import {
  COMMON_TERMS_TYPES,
  DOCUMENT_REQUIREMENT_TYPES,
  EQUIPMENT_TYPE_CODES,
  PROJECT_STATUSES,
  RECRUITMENT_STATUSES,
  TERMS_TYPES,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  date,
  foreignKey,
  index,
  pgTable,
  smallint,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { partners } from "./identity.ts";

export const equipmentTypes = pgTable(
  "equipment_types",
  {
    id: idPk(),
    // unique() の既定の名前は casing を通らず camelCase の列名になるため、snake_case で付ける
    equipmentTypeCode: text().notNull().unique("equipment_types_equipment_type_code_unique"),
    typeName: text().notNull(),
    ...timestamps,
  },
  (t) => [
    enumCheck(
      "equipment_types_equipment_type_code_check",
      t.equipmentTypeCode,
      EQUIPMENT_TYPE_CODES,
    ),
  ],
);

export const projectDefinitions = pgTable(
  "project_definitions",
  {
    id: idPk(),
    equipmentTypeId: text()
      .notNull()
      .references(() => equipmentTypes.id),
    projectDefinitionName: text().notNull(),
    methodologyCode: text().notNull(),
    recruitmentStatus: text().notNull().default("DRAFT"),
    description: text(),
    ...timestamps,
  },
  (t) => [
    index().on(t.equipmentTypeId),
    enumCheck(
      "project_definitions_recruitment_status_check",
      t.recruitmentStatus,
      RECRUITMENT_STATUSES,
    ),
  ],
);

export const projects = pgTable(
  "projects",
  {
    id: idPk(),
    partnerId: text()
      .notNull()
      .references(() => partners.id),
    projectDefinitionId: text()
      .notNull()
      .references(() => projectDefinitions.id),
    projectCode: text().notNull().unique("projects_project_code_unique"),
    displayName: text().notNull(),
    status: text().notNull().default("ACTIVE"),
    ...timestamps,
  },
  (t) => [
    unique("projects_partner_definition_unique").on(t.partnerId, t.projectDefinitionId),
    index().on(t.projectDefinitionId),
    enumCheck("projects_status_check", t.status, PROJECT_STATUSES),
  ],
);

export const recruitmentPeriods = pgTable(
  "recruitment_periods",
  {
    id: idPk(),
    projectDefinitionId: text().notNull(),
    periodName: text().notNull(),
    recruitmentStartAt: timestamp({ withTimezone: true }).notNull(),
    recruitmentEndAt: timestamp({ withTimezone: true }).notNull(),
    targetFiscalYear: smallint().notNull(),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "recruitment_periods_project_definition_fk",
      columns: [t.projectDefinitionId],
      foreignColumns: [projectDefinitions.id],
    }),
    index().on(t.projectDefinitionId),
    check("recruitment_periods_range_check", sql`${t.recruitmentStartAt} < ${t.recruitmentEndAt}`),
  ],
);

export const termsVersions = pgTable(
  "terms_versions",
  {
    id: idPk(),
    projectDefinitionId: text().references(() => projectDefinitions.id),
    termsType: text().notNull(),
    itemCode: text().notNull(),
    version: text().notNull(),
    content: text().notNull(),
    effectiveFrom: date().notNull(),
    ...timestamps,
  },
  (t) => [
    // 共通規約は project_definition_id が NULL。NULL 同士も重複とみなさないと、共通規約の同じ版を 2 行入れられる
    unique("terms_versions_item_version_unique")
      .on(t.termsType, t.itemCode, t.projectDefinitionId, t.version)
      .nullsNotDistinct(),
    index().on(t.projectDefinitionId),
    enumCheck("terms_versions_terms_type_check", t.termsType, TERMS_TYPES),
    check(
      "terms_versions_scope_check",
      sql`(${t.projectDefinitionId} is null) = (${t.termsType} in (${sql.raw(COMMON_TERMS_TYPES.map((v) => `'${v}'`).join(", "))}))`,
    ),
  ],
);

export const documentRequirements = pgTable(
  "document_requirements",
  {
    id: idPk(),
    projectDefinitionId: text().notNull(),
    documentType: text().notNull(),
    requirementType: text().notNull(),
    description: text(),
    isNotApplicableAllowed: boolean().notNull().default(false),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "document_requirements_project_definition_fk",
      columns: [t.projectDefinitionId],
      foreignColumns: [projectDefinitions.id],
    }),
    unique("document_requirements_definition_document_type_unique").on(
      t.projectDefinitionId,
      t.documentType,
    ),
    enumCheck(
      "document_requirements_requirement_type_check",
      t.requirementType,
      DOCUMENT_REQUIREMENT_TYPES,
    ),
  ],
);
