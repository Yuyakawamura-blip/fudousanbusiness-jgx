/** invitation クラスタ: 招く相手の種類ごとの招待 3 表。設計は docs/design/detailed/db/invitation.md */

import { INVITATION_STATUSES, type UserType } from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  type AnyPgColumn,
  check,
  index,
  pgTable,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { adminUsers, members, partners, roles } from "./identity.ts";
import { projects } from "./project.ts";

// 招待できる相手は docs/design/basic/auth.md の「招待」。運営者は会員を招待しない
const MEMBER_INVITERS = ["MEMBER", "PARTNER"] as const satisfies readonly UserType[];
const PARTNER_INVITERS = ["PARTNER", "ADMIN"] as const satisfies readonly UserType[];

const invitationColumns = () => ({
  roleId: text()
    .notNull()
    .references(() => roles.id),
  tokenHash: text().notNull(),
  inviteeEmail: text().notNull(),
  inviteeLastName: text(),
  inviteeFirstName: text(),
  inviteeLastNameKana: text(),
  inviteeFirstNameKana: text(),
  invitedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp({ withTimezone: true }).notNull(),
  status: text().notNull().default("INVITED"),
  registrationCompletedAt: timestamp({ withTimezone: true }),
});

const registrationCheck = (
  table: string,
  t: { status: AnyPgColumn; registrationCompletedAt: AnyPgColumn },
) =>
  check(
    `${table}_registration_check`,
    sql`(${t.status} = 'REGISTERED') = (${t.registrationCompletedAt} is not null)`,
  );

export const memberInvitations = pgTable(
  "member_invitations",
  {
    id: idPk(),
    memberId: text().references(() => members.id),
    projectId: text().references(() => projects.id),
    invitedByUserType: text().notNull(),
    invitedByUserId: text().notNull(),
    ...invitationColumns(),
    ...timestamps,
  },
  (t) => [
    // unique() の既定の名前は casing を通らず camelCase の列名になるため、snake_case で付ける
    unique("member_invitations_token_hash_unique").on(t.tokenHash),
    index().on(t.memberId),
    index().on(t.projectId),
    enumCheck(
      "member_invitations_invited_by_user_type_check",
      t.invitedByUserType,
      MEMBER_INVITERS,
    ),
    enumCheck("member_invitations_status_check", t.status, INVITATION_STATUSES),
    registrationCheck("member_invitations", t),
    check(
      "member_invitations_target_check",
      sql`case when ${t.invitedByUserType} = 'MEMBER' then ${t.memberId} is not null and ${t.projectId} is null else ${t.projectId} is not null end`,
    ),
  ],
);

export const partnerInvitations = pgTable(
  "partner_invitations",
  {
    id: idPk(),
    partnerId: text()
      .notNull()
      .references(() => partners.id),
    invitedByUserType: text().notNull(),
    invitedByUserId: text().notNull(),
    ...invitationColumns(),
    ...timestamps,
  },
  (t) => [
    unique("partner_invitations_token_hash_unique").on(t.tokenHash),
    index().on(t.partnerId),
    enumCheck(
      "partner_invitations_invited_by_user_type_check",
      t.invitedByUserType,
      PARTNER_INVITERS,
    ),
    enumCheck("partner_invitations_status_check", t.status, INVITATION_STATUSES),
    registrationCheck("partner_invitations", t),
  ],
);

export const adminInvitations = pgTable(
  "admin_invitations",
  {
    id: idPk(),
    adminUserId: text()
      .notNull()
      .references(() => adminUsers.id),
    ...invitationColumns(),
    ...timestamps,
  },
  (t) => [
    unique("admin_invitations_token_hash_unique").on(t.tokenHash),
    index().on(t.adminUserId),
    enumCheck("admin_invitations_status_check", t.status, INVITATION_STATUSES),
    registrationCheck("admin_invitations", t),
  ],
);
