/** identity クラスタ: 組織(会員・創出PT)と創出PTの支部、ユーザー・ロール。設計は docs/design/detailed/db/identity.md */

import {
  ACCOUNT_STATUSES,
  BRAND_TYPES,
  MEMBER_STATUSES,
  MEMBER_TYPES,
  ORGANIZATION_STATUSES,
  ROLE_NAMES,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  index,
  integer,
  pgTable,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";

const addressColumns = () => ({
  postalCode: text(),
  prefecture: text(),
  city: text(),
  streetAddress: text(),
  buildingName: text(),
});

const userColumns = () => ({
  email: text().unique(),
  pendingEmail: text(),
  phoneNumber: text(),
  lastName: text(),
  firstName: text(),
  lastNameKana: text(),
  firstNameKana: text(),
  department: text(),
  accountStatus: text().notNull().default("ACTIVE"),
  isEmailUndeliverable: boolean().notNull().default(false),
  failedLoginCount: integer().notNull().default(0),
  lockedUntil: timestamp({ withTimezone: true }),
  lastLoginAt: timestamp({ withTimezone: true }),
  activatedAt: timestamp({ withTimezone: true }),
  deletedAt: timestamp({ withTimezone: true }),
});

export const members = pgTable(
  "members",
  {
    id: idPk(),
    memberType: text(),
    memberStatus: text().notNull().default("PRE_REGISTERED"),
    corporateName: text(),
    corporateNameKana: text(),
    representativeTitle: text(),
    representativeLastName: text(),
    representativeFirstName: text(),
    representativeLastNameKana: text(),
    representativeFirstNameKana: text(),
    corporateNumber: text(),
    ...addressColumns(),
    representativePhoneNumber: text(),
    representativeContactEmail: text(),
    faxNumber: text(),
    brandType: text().notNull().default("GENERAL"),
    acquisitionChannel: text().notNull(),
    ...timestamps,
  },
  (t) => [
    enumCheck("members_member_type_check", t.memberType, MEMBER_TYPES),
    enumCheck("members_member_status_check", t.memberStatus, MEMBER_STATUSES),
    enumCheck("members_brand_type_check", t.brandType, BRAND_TYPES),
    check(
      "members_registered_fields_check",
      sql`${t.memberStatus} = 'PRE_REGISTERED' or (${t.memberType} is not null and ${t.postalCode} is not null and ${t.prefecture} is not null and ${t.city} is not null and ${t.streetAddress} is not null and ${t.representativePhoneNumber} is not null and ${t.representativeLastName} is not null and ${t.representativeFirstName} is not null and ${t.representativeLastNameKana} is not null and ${t.representativeFirstNameKana} is not null)`,
    ),
    check(
      "members_corporate_name_check",
      sql`(${t.memberType} is distinct from 'CORPORATE' or ${t.memberStatus} = 'PRE_REGISTERED' or ${t.corporateName} is not null) and (${t.memberType} is distinct from 'INDIVIDUAL' or (${t.corporateName} is null and ${t.representativeTitle} is null))`,
    ),
  ],
);

export const partners = pgTable(
  "partners",
  {
    id: idPk(),
    name: text(),
    nameKana: text(),
    ...addressColumns(),
    representativePhoneNumber: text(),
    representativeContactEmail: text(),
    contactPersonName: text(),
    partnerStatus: text().notNull().default("ACTIVE"),
    terminatedAt: timestamp({ withTimezone: true }),
    terminationReason: text(),
    ...timestamps,
  },
  (t) => [
    enumCheck("partners_partner_status_check", t.partnerStatus, ORGANIZATION_STATUSES),
    check(
      "partners_termination_check",
      sql`(${t.partnerStatus} = 'TERMINATED') = (${t.terminatedAt} is not null and ${t.terminationReason} is not null)`,
    ),
  ],
);

export const partnerBranches = pgTable(
  "partner_branches",
  {
    id: idPk(),
    partnerId: text()
      .notNull()
      .references(() => partners.id),
    branchName: text().notNull(),
    ...timestamps,
  },
  (t) => [unique("partner_branches_partner_branch_name_unique").on(t.partnerId, t.branchName)],
);

export const roles = pgTable(
  "roles",
  {
    id: idPk(),
    // unique() の既定の名前は casing を通らず camelCase の列名になる(roleName 等)。このファイルの unique は名前を snake_case で付ける
    roleName: text().notNull().unique("roles_role_name_unique"),
    description: text(),
    ...timestamps,
  },
  (t) => [enumCheck("roles_role_name_check", t.roleName, ROLE_NAMES)],
);

export const memberUsers = pgTable(
  "member_users",
  {
    id: idPk(),
    memberId: text()
      .notNull()
      .references(() => members.id),
    authSubjectId: text().unique("member_users_auth_subject_id_unique"),
    ...userColumns(),
    ...timestamps,
  },
  (t) => [
    index().on(t.memberId),
    enumCheck("member_users_account_status_check", t.accountStatus, ACCOUNT_STATUSES),
  ],
);

export const partnerUsers = pgTable(
  "partner_users",
  {
    id: idPk(),
    partnerId: text()
      .notNull()
      .references(() => partners.id),
    authSubjectId: text().notNull().unique("partner_users_auth_subject_id_unique"),
    ...userColumns(),
    ...timestamps,
  },
  (t) => [
    index().on(t.partnerId),
    enumCheck("partner_users_account_status_check", t.accountStatus, ACCOUNT_STATUSES),
  ],
);

export const adminUsers = pgTable(
  "admin_users",
  {
    id: idPk(),
    authSubjectId: text().notNull().unique("admin_users_auth_subject_id_unique"),
    ...userColumns(),
    ...timestamps,
  },
  (t) => [enumCheck("admin_users_account_status_check", t.accountStatus, ACCOUNT_STATUSES)],
);

export const memberUserRoles = pgTable(
  "member_user_roles",
  {
    id: idPk(),
    memberUserId: text()
      .notNull()
      .references(() => memberUsers.id),
    roleId: text()
      .notNull()
      .references(() => roles.id),
    assignedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [unique("member_user_roles_user_role_unique").on(t.memberUserId, t.roleId)],
);

export const partnerUserRoles = pgTable(
  "partner_user_roles",
  {
    id: idPk(),
    partnerUserId: text()
      .notNull()
      .references(() => partnerUsers.id),
    roleId: text()
      .notNull()
      .references(() => roles.id),
    assignedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [unique("partner_user_roles_user_role_unique").on(t.partnerUserId, t.roleId)],
);

export const adminUserRoles = pgTable(
  "admin_user_roles",
  {
    id: idPk(),
    adminUserId: text()
      .notNull()
      .references(() => adminUsers.id),
    roleId: text()
      .notNull()
      .references(() => roles.id),
    assignedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [unique("admin_user_roles_user_role_unique").on(t.adminUserId, t.roleId)],
);
