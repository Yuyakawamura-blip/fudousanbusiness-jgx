import { sql } from "drizzle-orm";
import { type AnyPgColumn, check, text, timestamp } from "drizzle-orm/pg-core";
import { newId } from "../src/id.ts";

/** `id text PK`(アプリ生成 UUIDv7。runtime default のため DDL に DEFAULT は出ない) */
export const idPk = () => text().primaryKey().$defaultFn(newId);

/** `created_at` / `updated_at`(updated_at はアプリ層更新 — trigger 不使用) */
export const timestamps = {
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp({ withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
};

/**
 * 列挙の CHECK 制約(text + CHECK。値リストの正は @jcredit/shared/enums)。
 * 値は sql.raw でインライン化する — パラメータ化されると CHECK の DDL が壊れるため。
 */
export const enumCheck = (name: string, column: AnyPgColumn, values: readonly string[]) =>
  check(name, sql`${column} in (${sql.raw(values.map((v) => `'${v}'`).join(", "))})`);
