/** facility クラスタ: 申込の施設・対象設備・補助金明細と、書類枠・証跡書類。設計は docs/design/detailed/db/facility.md */

import {
  DOCUMENT_REQUIREMENT_TYPES,
  DOCUMENT_SLOT_STATUSES,
  EVIDENCE_VERIFICATION_STATUSES,
  USER_TYPES,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  bigint,
  check,
  date,
  foreignKey,
  index,
  integer,
  numeric,
  pgTable,
  smallint,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { projectApplications } from "./application.ts";
import { documentRequirements, equipmentTypes } from "./project.ts";

export const facilities = pgTable(
  "facilities",
  {
    id: idPk(),
    projectApplicationId: text()
      .notNull()
      .references(() => projectApplications.id),
    equipmentTypeCode: text().notNull(),
    facilityName: text(),
    postalCode: text(),
    prefecture: text(),
    city: text(),
    streetAddress: text(),
    buildingName: text(),
    operationStartDate: date().notNull(),
    totalInvestmentAmount: numeric({ precision: 15, scale: 0 }).notNull(),
    purchasedElectricityUnitPrice: numeric({ precision: 10, scale: 4 }).notNull(),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトを超え、黙って切り詰められるため短く付ける
    foreignKey({
      name: "facilities_equipment_type_code_fk",
      columns: [t.equipmentTypeCode],
      foreignColumns: [equipmentTypes.equipmentTypeCode],
    }),
    // 区分別の詳細の複合 FK の参照先
    unique("facilities_id_equipment_type_code_unique").on(t.id, t.equipmentTypeCode),
    index().on(t.projectApplicationId),
  ],
);

export const solarFacilityDetails = pgTable(
  "solar_facility_details",
  {
    id: idPk(),
    facilityId: text().notNull(),
    equipmentTypeCode: text().notNull().default("SOLAR"),
    selfConsumptionKwh: numeric({ precision: 18, scale: 3 }).notNull(),
    soldElectricityKwh: numeric({ precision: 18, scale: 3 }).notNull(),
    soldElectricityUnitPrice: numeric({ precision: 10, scale: 4 }).notNull(),
    maintenanceCost: numeric({ precision: 15, scale: 0 }).notNull(),
    measurementDeviceStatus: text(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "solar_facility_details_facility_fk",
      columns: [t.facilityId, t.equipmentTypeCode],
      foreignColumns: [facilities.id, facilities.equipmentTypeCode],
    }),
    unique("solar_facility_details_facility_id_unique").on(t.facilityId),
    check("solar_facility_details_equipment_type_check", sql`${t.equipmentTypeCode} = 'SOLAR'`),
  ],
);

export const lightingFacilityDetails = pgTable(
  "lighting_facility_details",
  {
    id: idPk(),
    facilityId: text().notNull(),
    equipmentTypeCode: text().notNull().default("LED"),
    totalFloors: smallint().notNull(),
    targetFloors: text().notNull(),
    priorLightingInstalledOn: date(),
    buildingCompletedOn: date(),
    constructionStartFiscalYear: smallint().notNull(),
    constructionEndFiscalYear: smallint().notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "lighting_facility_details_facility_fk",
      columns: [t.facilityId, t.equipmentTypeCode],
      foreignColumns: [facilities.id, facilities.equipmentTypeCode],
    }),
    unique("lighting_facility_details_facility_id_unique").on(t.facilityId),
    check("lighting_facility_details_equipment_type_check", sql`${t.equipmentTypeCode} = 'LED'`),
    check(
      "lighting_facility_details_installed_check",
      sql`num_nonnulls(${t.priorLightingInstalledOn}, ${t.buildingCompletedOn}) >= 1`,
    ),
    check(
      "lighting_facility_details_construction_range_check",
      sql`${t.constructionStartFiscalYear} <= ${t.constructionEndFiscalYear}`,
    ),
  ],
);

export const subsidies = pgTable(
  "subsidies",
  {
    id: idPk(),
    facilityId: text()
      .notNull()
      .references(() => facilities.id),
    subsidyName: text().notNull(),
    amount: numeric({ precision: 15, scale: 0 }).notNull(),
    ...timestamps,
  },
  (t) => [index().on(t.facilityId)],
);

export const solarGenerationSystems = pgTable(
  "solar_generation_systems",
  {
    id: idPk(),
    facilityId: text().notNull(),
    manufacturer: text().notNull(),
    modelNumber: text().notNull(),
    serialNumber: text().notNull(),
    ...timestamps,
  },
  (t) => [
    // facilities ではなく太陽光の詳細を指し、区分が太陽光の施設にしか付かないようにする
    foreignKey({
      name: "solar_generation_systems_facility_fk",
      columns: [t.facilityId],
      foreignColumns: [solarFacilityDetails.facilityId],
    }),
    index().on(t.facilityId),
    index().on(t.serialNumber),
  ],
);

export const solarPanels = pgTable(
  "solar_panels",
  {
    id: idPk(),
    solarGenerationSystemId: text().notNull(),
    ratedMaxOutputKw: numeric({ precision: 12, scale: 3 }).notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "solar_panels_solar_generation_system_fk",
      columns: [t.solarGenerationSystemId],
      foreignColumns: [solarGenerationSystems.id],
    }),
    index().on(t.solarGenerationSystemId),
  ],
);

export const powerConditioners = pgTable(
  "power_conditioners",
  {
    id: idPk(),
    solarGenerationSystemId: text().notNull(),
    manufacturer: text().notNull(),
    modelNumber: text().notNull(),
    nightStandbyPowerW: numeric({ precision: 10, scale: 3 }).notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "power_conditioners_solar_generation_system_fk",
      columns: [t.solarGenerationSystemId],
      foreignColumns: [solarGenerationSystems.id],
    }),
    index().on(t.solarGenerationSystemId),
  ],
);

export const powerConditionerUnits = pgTable(
  "power_conditioner_units",
  {
    id: idPk(),
    powerConditionerId: text().notNull(),
    serialNumber: text().notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "power_conditioner_units_power_conditioner_fk",
      columns: [t.powerConditionerId],
      foreignColumns: [powerConditioners.id],
    }),
    index().on(t.powerConditionerId),
    index().on(t.serialNumber),
  ],
);

export const storageBatteries = pgTable(
  "storage_batteries",
  {
    id: idPk(),
    solarGenerationSystemId: text().notNull(),
    manufacturer: text().notNull(),
    modelNumber: text().notNull(),
    capacityKw: numeric({ precision: 12, scale: 3 }).notNull(),
    efficiencyRate: numeric({ precision: 5, scale: 2 }).notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "storage_batteries_solar_generation_system_fk",
      columns: [t.solarGenerationSystemId],
      foreignColumns: [solarGenerationSystems.id],
    }),
    index().on(t.solarGenerationSystemId),
  ],
);

export const ledFixtures = pgTable(
  "led_fixtures",
  {
    id: idPk(),
    facilityId: text().notNull(),
    installationLocation: text().notNull(),
    modelNumber: text().notNull(),
    serialNumber: text(),
    ratedOutputW: numeric({ precision: 10, scale: 3 }).notNull(),
    efficiencyLmPerW: numeric({ precision: 12, scale: 3 }),
    quantity: integer().notNull(),
    ...timestamps,
  },
  (t) => [
    // facilities ではなく照明の詳細を指し、区分が LED の施設にしか付かないようにする
    foreignKey({
      name: "led_fixtures_facility_fk",
      columns: [t.facilityId],
      foreignColumns: [lightingFacilityDetails.facilityId],
    }),
    index().on(t.facilityId),
  ],
);

export const priorEquipmentTypes = pgTable(
  "prior_equipment_types",
  {
    id: idPk(),
    equipmentTypeId: text()
      .notNull()
      .references(() => equipmentTypes.id),
    typeName: text().notNull(),
    legalUsefulLifeYears: smallint().notNull(),
    applicationDeadline: date(),
    ...timestamps,
  },
  (t) => [index().on(t.equipmentTypeId)],
);

export const priorLightingFixtures = pgTable(
  "prior_lighting_fixtures",
  {
    id: idPk(),
    facilityId: text().notNull(),
    priorEquipmentTypeId: text().notNull(),
    installationLocation: text().notNull(),
    modelNumber: text().notNull(),
    serialNumber: text(),
    ratedOutputW: numeric({ precision: 10, scale: 3 }).notNull(),
    efficiencyLmPerW: numeric({ precision: 12, scale: 3 }),
    quantity: integer().notNull(),
    ...timestamps,
  },
  (t) => [
    // facilities ではなく照明の詳細を指し、区分が LED の施設にしか付かないようにする
    foreignKey({
      name: "prior_lighting_fixtures_facility_fk",
      columns: [t.facilityId],
      foreignColumns: [lightingFacilityDetails.facilityId],
    }),
    foreignKey({
      name: "prior_lighting_fixtures_prior_equipment_type_fk",
      columns: [t.priorEquipmentTypeId],
      foreignColumns: [priorEquipmentTypes.id],
    }),
    index().on(t.facilityId),
    index().on(t.priorEquipmentTypeId),
  ],
);

export const documentSlots = pgTable(
  "document_slots",
  {
    id: idPk(),
    projectApplicationId: text().notNull(),
    documentRequirementId: text(),
    facilityId: text().references(() => facilities.id),
    solarGenerationSystemId: text(),
    subsidyId: text().references(() => subsidies.id),
    documentType: text().notNull(),
    requirementType: text().notNull(),
    slotStatus: text().notNull().default("NOT_SUBMITTED"),
    notApplicableReason: text(),
    notApplicableSelectedAt: timestamp({ withTimezone: true }),
    notApplicableSelectedByUserType: text(),
    notApplicableSelectedByUserId: text(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "document_slots_project_application_fk",
      columns: [t.projectApplicationId],
      foreignColumns: [projectApplications.id],
    }),
    foreignKey({
      name: "document_slots_document_requirement_fk",
      columns: [t.documentRequirementId],
      foreignColumns: [documentRequirements.id],
    }),
    foreignKey({
      name: "document_slots_solar_generation_system_fk",
      columns: [t.solarGenerationSystemId],
      foreignColumns: [solarGenerationSystems.id],
    }),
    index().on(t.projectApplicationId),
    index().on(t.documentRequirementId),
    index().on(t.facilityId),
    index().on(t.solarGenerationSystemId),
    index().on(t.subsidyId),
    enumCheck(
      "document_slots_requirement_type_check",
      t.requirementType,
      DOCUMENT_REQUIREMENT_TYPES,
    ),
    enumCheck("document_slots_slot_status_check", t.slotStatus, DOCUMENT_SLOT_STATUSES),
    enumCheck(
      "document_slots_not_applicable_selected_by_user_type_check",
      t.notApplicableSelectedByUserType,
      USER_TYPES,
    ),
    check(
      "document_slots_target_check",
      sql`num_nonnulls(${t.facilityId}, ${t.solarGenerationSystemId}, ${t.subsidyId}) <= 1`,
    ),
    check(
      "document_slots_not_applicable_check",
      sql`num_nonnulls(${t.notApplicableReason}, ${t.notApplicableSelectedAt}, ${t.notApplicableSelectedByUserType}, ${t.notApplicableSelectedByUserId}) = case when ${t.slotStatus} = 'NOT_APPLICABLE' then 4 else 0 end`,
    ),
  ],
);

export const evidenceDocuments = pgTable(
  "evidence_documents",
  {
    id: idPk(),
    documentSlotId: text()
      .notNull()
      .references(() => documentSlots.id),
    replacedEvidenceDocumentId: text(),
    // unique() の既定の名前は casing を通らず camelCase の列名になるため、snake_case で付ける
    storageObjectKey: text().notNull().unique("evidence_documents_storage_object_key_unique"),
    fileName: text().notNull(),
    mimeType: text().notNull(),
    fileSizeBytes: bigint({ mode: "number" }).notNull(),
    fileHash: text(),
    referenceNote: text(),
    verificationStatus: text().notNull().default("UNVERIFIED"),
    uploadedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    uploadedByUserType: text().notNull(),
    uploadedByUserId: text().notNull(),
    ...timestamps,
  },
  (t) => [
    foreignKey({
      name: "evidence_documents_replaced_evidence_document_fk",
      columns: [t.replacedEvidenceDocumentId],
      foreignColumns: [t.id],
    }),
    index().on(t.documentSlotId),
    index().on(t.replacedEvidenceDocumentId),
    index("evidence_documents_uploaded_by_index").on(t.uploadedByUserType, t.uploadedByUserId),
    enumCheck(
      "evidence_documents_verification_status_check",
      t.verificationStatus,
      EVIDENCE_VERIFICATION_STATUSES,
    ),
    enumCheck("evidence_documents_uploaded_by_user_type_check", t.uploadedByUserType, USER_TYPES),
  ],
);
