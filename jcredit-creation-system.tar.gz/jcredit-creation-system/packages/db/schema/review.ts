/** review クラスタ: 審査と、会員基本情報申請・創出PT情報申請。設計は docs/design/detailed/db/review.md */

import {
  INFO_REQUEST_STATUSES,
  MEMBER_BASIC_INFO_REQUEST_TYPES,
  REVIEW_RESULTS,
  REVIEW_STAGES,
} from "@jcredit/shared/enums";
import { sql } from "drizzle-orm";
import {
  type AnyPgColumn,
  check,
  foreignKey,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  unique,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { enumCheck, idPk, timestamps } from "./_helpers.ts";
import { applicationSubmissions } from "./application.ts";
import { adminUsers, members, memberUsers, partners, partnerUsers } from "./identity.ts";

export const reviews = pgTable(
  "reviews",
  {
    id: idPk(),
    applicationSubmissionId: text(),
    reviewerAdminUserId: text()
      .notNull()
      .references(() => adminUsers.id),
    reviewStage: text(),
    reviewResult: text().notNull(),
    reviewReason: text(),
    reviewComment: text(),
    reviewedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    // 既定の名前は Postgres の識別子の上限 63 バイトちょうどになるため短く付ける
    foreignKey({
      name: "reviews_application_submission_fk",
      columns: [t.applicationSubmissionId],
      foreignColumns: [applicationSubmissions.id],
    }),
    unique("reviews_submission_stage_unique").on(t.applicationSubmissionId, t.reviewStage),
    index().on(t.reviewerAdminUserId),
    enumCheck("reviews_review_stage_check", t.reviewStage, REVIEW_STAGES),
    enumCheck("reviews_review_result_check", t.reviewResult, REVIEW_RESULTS),
    check(
      "reviews_stage_check",
      sql`(${t.applicationSubmissionId} is null) = (${t.reviewStage} is null)`,
    ),
    check(
      "reviews_review_reason_check",
      sql`(${t.reviewResult} = 'APPROVED') = (${t.reviewReason} is null)`,
    ),
  ],
);

const requestStatusChecks = (
  table: string,
  t: { requestStatus: AnyPgColumn; reviewId: AnyPgColumn },
) => [
  enumCheck(`${table}_request_status_check`, t.requestStatus, INFO_REQUEST_STATUSES),
  check(`${table}_review_check`, sql`(${t.requestStatus} = 'SUBMITTED') = (${t.reviewId} is null)`),
];

export const memberBasicInfoRequests = pgTable(
  "member_basic_info_requests",
  {
    id: idPk(),
    memberId: text()
      .notNull()
      .references(() => members.id),
    reviewId: text()
      .references(() => reviews.id)
      .unique("member_basic_info_requests_review_id_unique"),
    memberUserId: text()
      .notNull()
      .references(() => memberUsers.id),
    requestType: text().notNull(),
    requestStatus: text().notNull().default("SUBMITTED"),
    submittedContent: jsonb().notNull(),
    submittedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("member_basic_info_requests_submitted_unique")
      .on(t.memberId)
      .where(sql`${t.requestStatus} = 'SUBMITTED'`),
    index().on(t.memberId),
    index().on(t.memberUserId),
    enumCheck(
      "member_basic_info_requests_request_type_check",
      t.requestType,
      MEMBER_BASIC_INFO_REQUEST_TYPES,
    ),
    ...requestStatusChecks("member_basic_info_requests", t),
  ],
);

export const partnerInfoRequests = pgTable(
  "partner_info_requests",
  {
    id: idPk(),
    partnerId: text()
      .notNull()
      .references(() => partners.id),
    reviewId: text()
      .references(() => reviews.id)
      .unique("partner_info_requests_review_id_unique"),
    partnerUserId: text()
      .notNull()
      .references(() => partnerUsers.id),
    requestStatus: text().notNull().default("SUBMITTED"),
    submittedContent: jsonb().notNull(),
    changeReason: text(),
    submittedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("partner_info_requests_submitted_unique")
      .on(t.partnerId)
      .where(sql`${t.requestStatus} = 'SUBMITTED'`),
    index().on(t.partnerId),
    index().on(t.partnerUserId),
    ...requestStatusChecks("partner_info_requests", t),
  ],
);
