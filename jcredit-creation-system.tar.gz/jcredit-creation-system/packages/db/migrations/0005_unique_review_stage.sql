DROP INDEX "reviews_application_submission_id_index";--> statement-breakpoint
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_submission_stage_unique" UNIQUE("application_submission_id","review_stage");