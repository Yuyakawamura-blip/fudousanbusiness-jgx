CREATE TABLE "application_confirmations" (
	"id" text PRIMARY KEY NOT NULL,
	"project_application_id" text NOT NULL,
	"has_agreed_all_terms" boolean DEFAULT false NOT NULL,
	"is_keidanren_cn_plan_participant" boolean,
	"is_specified_emitter" boolean,
	"specified_emitter_code" text,
	"energy_conservation_status" text,
	"energy_business_number" text,
	"energy_factory_number" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "application_confirmations_project_application_id_unique" UNIQUE("project_application_id")
);
--> statement-breakpoint
CREATE TABLE "application_submissions" (
	"id" text PRIMARY KEY NOT NULL,
	"project_application_id" text NOT NULL,
	"member_user_id" text NOT NULL,
	"submitted_content" jsonb NOT NULL,
	"submitted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "consent_records" (
	"id" text PRIMARY KEY NOT NULL,
	"terms_version_id" text NOT NULL,
	"member_id" text,
	"project_application_id" text,
	"consented_by_user_type" text NOT NULL,
	"consented_by_user_id" text NOT NULL,
	"agreed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "consent_records_consented_by_user_type_check" CHECK ("consent_records"."consented_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'))
);
--> statement-breakpoint
CREATE TABLE "participation_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"member_id" text NOT NULL,
	"project_id" text NOT NULL,
	"member_user_id" text NOT NULL,
	"status" text DEFAULT 'PENDING' NOT NULL,
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL,
	"decided_by_user_type" text,
	"decided_by_user_id" text,
	"decided_at" timestamp with time zone,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "participation_requests_status_check" CHECK ("participation_requests"."status" in ('PENDING', 'ACCEPTED', 'REJECTED')),
	CONSTRAINT "participation_requests_decided_by_user_type_check" CHECK ("participation_requests"."decided_by_user_type" in ('PARTNER', 'ALLIANCE_HEADQUARTERS')),
	CONSTRAINT "participation_requests_decision_check" CHECK (num_nonnulls("participation_requests"."decided_by_user_type", "participation_requests"."decided_by_user_id", "participation_requests"."decided_at") = case when "participation_requests"."status" = 'PENDING' then 0 else 3 end),
	CONSTRAINT "participation_requests_rejection_reason_check" CHECK (("participation_requests"."status" = 'REJECTED') = ("participation_requests"."rejection_reason" is not null))
);
--> statement-breakpoint
CREATE TABLE "project_applications" (
	"id" text PRIMARY KEY NOT NULL,
	"participation_request_id" text NOT NULL,
	"recruitment_period_id" text,
	"member_user_id" text NOT NULL,
	"application_number" text NOT NULL,
	"application_status" text DEFAULT 'DRAFT' NOT NULL,
	"submitted_at" timestamp with time zone,
	"joined_on" date,
	"effective_to" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "project_applications_application_number_unique" UNIQUE("application_number"),
	CONSTRAINT "project_applications_application_status_check" CHECK ("project_applications"."application_status" in ('DRAFT', 'UNDER_REVIEW', 'RETURNED', 'PARTICIPATING', 'REJECTED', 'EXPIRED', 'WITHDRAWN')),
	CONSTRAINT "project_applications_submitted_check" CHECK (("project_applications"."application_status" = 'DRAFT') = ("project_applications"."submitted_at" is null) and ("project_applications"."application_status" = 'DRAFT' or "project_applications"."recruitment_period_id" is not null)),
	CONSTRAINT "project_applications_joined_check" CHECK (("project_applications"."application_status" in ('PARTICIPATING', 'WITHDRAWN')) = ("project_applications"."joined_on" is not null)),
	CONSTRAINT "project_applications_effective_range_check" CHECK ("project_applications"."joined_on" <= "project_applications"."effective_to")
);
--> statement-breakpoint
ALTER TABLE "application_confirmations" ADD CONSTRAINT "application_confirmations_project_application_fk" FOREIGN KEY ("project_application_id") REFERENCES "public"."project_applications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "application_submissions" ADD CONSTRAINT "application_submissions_member_user_id_member_users_id_fk" FOREIGN KEY ("member_user_id") REFERENCES "public"."member_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "application_submissions" ADD CONSTRAINT "application_submissions_project_application_fk" FOREIGN KEY ("project_application_id") REFERENCES "public"."project_applications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "consent_records" ADD CONSTRAINT "consent_records_terms_version_id_terms_versions_id_fk" FOREIGN KEY ("terms_version_id") REFERENCES "public"."terms_versions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "consent_records" ADD CONSTRAINT "consent_records_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "consent_records" ADD CONSTRAINT "consent_records_project_application_fk" FOREIGN KEY ("project_application_id") REFERENCES "public"."project_applications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_member_user_id_member_users_id_fk" FOREIGN KEY ("member_user_id") REFERENCES "public"."member_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_applications" ADD CONSTRAINT "project_applications_member_user_id_member_users_id_fk" FOREIGN KEY ("member_user_id") REFERENCES "public"."member_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_applications" ADD CONSTRAINT "project_applications_participation_request_fk" FOREIGN KEY ("participation_request_id") REFERENCES "public"."participation_requests"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_applications" ADD CONSTRAINT "project_applications_recruitment_period_fk" FOREIGN KEY ("recruitment_period_id") REFERENCES "public"."recruitment_periods"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "application_submissions_project_application_id_index" ON "application_submissions" USING btree ("project_application_id");--> statement-breakpoint
CREATE INDEX "application_submissions_member_user_id_index" ON "application_submissions" USING btree ("member_user_id");--> statement-breakpoint
CREATE INDEX "consent_records_terms_version_id_index" ON "consent_records" USING btree ("terms_version_id");--> statement-breakpoint
CREATE INDEX "consent_records_member_id_index" ON "consent_records" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "consent_records_project_application_id_index" ON "consent_records" USING btree ("project_application_id");--> statement-breakpoint
CREATE INDEX "consent_records_consented_by_index" ON "consent_records" USING btree ("consented_by_user_type","consented_by_user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "participation_requests_pending_unique" ON "participation_requests" USING btree ("member_id","project_id") WHERE "participation_requests"."status" = 'PENDING';--> statement-breakpoint
CREATE INDEX "participation_requests_member_id_index" ON "participation_requests" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "participation_requests_project_id_index" ON "participation_requests" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "participation_requests_member_user_id_index" ON "participation_requests" USING btree ("member_user_id");--> statement-breakpoint
CREATE INDEX "project_applications_participation_request_id_index" ON "project_applications" USING btree ("participation_request_id");--> statement-breakpoint
CREATE INDEX "project_applications_recruitment_period_id_index" ON "project_applications" USING btree ("recruitment_period_id");--> statement-breakpoint
CREATE INDEX "project_applications_member_user_id_index" ON "project_applications" USING btree ("member_user_id");