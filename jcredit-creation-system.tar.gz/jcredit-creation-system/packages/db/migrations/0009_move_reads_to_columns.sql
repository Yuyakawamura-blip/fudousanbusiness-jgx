ALTER TABLE "inquiry_reads" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "inquiry_reads" CASCADE;--> statement-breakpoint
ALTER TABLE "inquiries" ADD COLUMN "recipient_last_read_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "read_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_recipient_last_read_at_check" CHECK ("inquiries"."recipient_user_id" is not null or "inquiries"."recipient_last_read_at" is null);--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_read_at_check" CHECK ("notifications"."audience_type" = 'INDIVIDUAL' or "notifications"."read_at" is null);