CREATE TABLE "partner_branches" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_id" text NOT NULL,
	"branch_name" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_branches_partner_branch_name_unique" UNIQUE("partner_id","branch_name")
);
--> statement-breakpoint
ALTER TABLE "alliance_headquarters" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_user_roles" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_users" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_invitations" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_project_definitions" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "alliance_headquarters" CASCADE;--> statement-breakpoint
DROP TABLE "alliance_headquarters_user_roles" CASCADE;--> statement-breakpoint
DROP TABLE "alliance_headquarters_users" CASCADE;--> statement-breakpoint
DROP TABLE "alliance_headquarters_invitations" CASCADE;--> statement-breakpoint
DROP TABLE "alliance_headquarters_project_definitions" CASCADE;--> statement-breakpoint
ALTER TABLE "consent_records" DROP CONSTRAINT "consent_records_consented_by_user_type_check";--> statement-breakpoint
ALTER TABLE "document_slots" DROP CONSTRAINT "document_slots_not_applicable_selected_by_user_type_check";--> statement-breakpoint
ALTER TABLE "evidence_documents" DROP CONSTRAINT "evidence_documents_uploaded_by_user_type_check";--> statement-breakpoint
ALTER TABLE "member_invitations" DROP CONSTRAINT "member_invitations_invited_by_user_type_check";--> statement-breakpoint
ALTER TABLE "partner_invitations" DROP CONSTRAINT "partner_invitations_invited_by_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_opened_by_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_recipient_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiry_messages" DROP CONSTRAINT "inquiry_messages_posted_by_user_type_check";--> statement-breakpoint
ALTER TABLE "notification_reads" DROP CONSTRAINT "notification_reads_user_type_check";--> statement-breakpoint
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_recipient_user_type_check";--> statement-breakpoint
ALTER TABLE "partner_info_requests" DROP CONSTRAINT "partner_info_requests_requested_by_user_type_check";--> statement-breakpoint
DROP INDEX "partner_info_requests_requested_by_index";--> statement-breakpoint
ALTER TABLE "participation_requests" ADD COLUMN "partner_branch_id" text;--> statement-breakpoint
ALTER TABLE "partner_info_requests" ADD COLUMN "partner_user_id" text NOT NULL;--> statement-breakpoint
ALTER TABLE "partner_branches" ADD CONSTRAINT "partner_branches_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_partner_branch_id_partner_branches_id_fk" FOREIGN KEY ("partner_branch_id") REFERENCES "public"."partner_branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_info_requests" ADD CONSTRAINT "partner_info_requests_partner_user_id_partner_users_id_fk" FOREIGN KEY ("partner_user_id") REFERENCES "public"."partner_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "participation_requests_partner_branch_id_index" ON "participation_requests" USING btree ("partner_branch_id");--> statement-breakpoint
CREATE INDEX "partner_info_requests_partner_user_id_index" ON "partner_info_requests" USING btree ("partner_user_id");--> statement-breakpoint
ALTER TABLE "partner_info_requests" DROP COLUMN "requested_by_user_type";--> statement-breakpoint
ALTER TABLE "partner_info_requests" DROP COLUMN "requested_by_user_id";--> statement-breakpoint
ALTER TABLE "consent_records" ADD CONSTRAINT "consent_records_consented_by_user_type_check" CHECK ("consent_records"."consented_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_not_applicable_selected_by_user_type_check" CHECK ("document_slots"."not_applicable_selected_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "evidence_documents" ADD CONSTRAINT "evidence_documents_uploaded_by_user_type_check" CHECK ("evidence_documents"."uploaded_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "member_invitations" ADD CONSTRAINT "member_invitations_invited_by_user_type_check" CHECK ("member_invitations"."invited_by_user_type" in ('MEMBER', 'PARTNER'));--> statement-breakpoint
ALTER TABLE "partner_invitations" ADD CONSTRAINT "partner_invitations_invited_by_user_type_check" CHECK ("partner_invitations"."invited_by_user_type" in ('PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_opened_by_user_type_check" CHECK ("inquiries"."opened_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_recipient_user_type_check" CHECK ("inquiries"."recipient_user_type" in ('MEMBER', 'PARTNER'));--> statement-breakpoint
ALTER TABLE "inquiry_messages" ADD CONSTRAINT "inquiry_messages_posted_by_user_type_check" CHECK ("inquiry_messages"."posted_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "notification_reads" ADD CONSTRAINT "notification_reads_user_type_check" CHECK ("notification_reads"."user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_recipient_user_type_check" CHECK ("notifications"."recipient_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'));