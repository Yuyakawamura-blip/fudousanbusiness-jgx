CREATE TABLE "alliance_headquarters_project_definitions" (
	"id" text PRIMARY KEY NOT NULL,
	"alliance_headquarters_id" text NOT NULL,
	"project_definition_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "alliance_headquarters_project_definitions_unique" UNIQUE("alliance_headquarters_id","project_definition_id")
);
--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_recipient_last_read_at_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_opened_by_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_recipient_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_counterpart_check";--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_recipient_check";--> statement-breakpoint
ALTER TABLE "inquiry_messages" DROP CONSTRAINT "inquiry_messages_posted_by_user_type_check";--> statement-breakpoint
ALTER TABLE "inquiries" ALTER COLUMN "recipient_user_type" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "inquiries" ALTER COLUMN "recipient_user_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "inquiries" ADD COLUMN "alliance_headquarters_id" text;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_project_definitions" ADD CONSTRAINT "alliance_headquarters_project_definitions_headquarters_fk" FOREIGN KEY ("alliance_headquarters_id") REFERENCES "public"."alliance_headquarters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_project_definitions" ADD CONSTRAINT "alliance_headquarters_project_definitions_definition_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "alliance_headquarters_project_definitions_definition_index" ON "alliance_headquarters_project_definitions" USING btree ("project_definition_id");--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_alliance_headquarters_id_alliance_headquarters_id_fk" FOREIGN KEY ("alliance_headquarters_id") REFERENCES "public"."alliance_headquarters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "inquiries_alliance_headquarters_id_index" ON "inquiries" USING btree ("alliance_headquarters_id");--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_opened_by_user_type_check" CHECK ("inquiries"."opened_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'));--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_recipient_user_type_check" CHECK ("inquiries"."recipient_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS'));--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_counterpart_check" CHECK (num_nonnulls("inquiries"."member_id", "inquiries"."partner_id", "inquiries"."alliance_headquarters_id") <= 1);--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_recipient_check" CHECK ("inquiries"."opened_by_user_type" = 'ADMIN' or ("inquiries"."recipient_user_type" = "inquiries"."opened_by_user_type" and "inquiries"."recipient_user_id" = "inquiries"."opened_by_user_id"));--> statement-breakpoint
ALTER TABLE "inquiry_messages" ADD CONSTRAINT "inquiry_messages_posted_by_user_type_check" CHECK ("inquiry_messages"."posted_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'));