CREATE TABLE "admin_invitations" (
	"id" text PRIMARY KEY NOT NULL,
	"admin_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"token_hash" text NOT NULL,
	"invitee_email" text NOT NULL,
	"invitee_last_name" text,
	"invitee_first_name" text,
	"invitee_last_name_kana" text,
	"invitee_first_name_kana" text,
	"invited_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'INVITED' NOT NULL,
	"registration_completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "admin_invitations_token_hash_unique" UNIQUE("token_hash"),
	CONSTRAINT "admin_invitations_status_check" CHECK ("admin_invitations"."status" in ('INVITED', 'REGISTERED', 'CANCELLED')),
	CONSTRAINT "admin_invitations_registration_check" CHECK (("admin_invitations"."status" = 'REGISTERED') = ("admin_invitations"."registration_completed_at" is not null))
);
--> statement-breakpoint
CREATE TABLE "alliance_headquarters_invitations" (
	"id" text PRIMARY KEY NOT NULL,
	"alliance_headquarters_id" text NOT NULL,
	"invited_by_user_type" text NOT NULL,
	"invited_by_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"token_hash" text NOT NULL,
	"invitee_email" text NOT NULL,
	"invitee_last_name" text,
	"invitee_first_name" text,
	"invitee_last_name_kana" text,
	"invitee_first_name_kana" text,
	"invited_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'INVITED' NOT NULL,
	"registration_completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "alliance_headquarters_invitations_token_hash_unique" UNIQUE("token_hash"),
	CONSTRAINT "alliance_headquarters_invitations_invited_by_user_type_check" CHECK ("alliance_headquarters_invitations"."invited_by_user_type" in ('ALLIANCE_HEADQUARTERS', 'ADMIN')),
	CONSTRAINT "alliance_headquarters_invitations_status_check" CHECK ("alliance_headquarters_invitations"."status" in ('INVITED', 'REGISTERED', 'CANCELLED')),
	CONSTRAINT "alliance_headquarters_invitations_registration_check" CHECK (("alliance_headquarters_invitations"."status" = 'REGISTERED') = ("alliance_headquarters_invitations"."registration_completed_at" is not null))
);
--> statement-breakpoint
CREATE TABLE "member_invitations" (
	"id" text PRIMARY KEY NOT NULL,
	"member_id" text,
	"project_id" text,
	"invited_by_user_type" text NOT NULL,
	"invited_by_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"token_hash" text NOT NULL,
	"invitee_email" text NOT NULL,
	"invitee_last_name" text,
	"invitee_first_name" text,
	"invitee_last_name_kana" text,
	"invitee_first_name_kana" text,
	"invited_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'INVITED' NOT NULL,
	"registration_completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "member_invitations_token_hash_unique" UNIQUE("token_hash"),
	CONSTRAINT "member_invitations_invited_by_user_type_check" CHECK ("member_invitations"."invited_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS')),
	CONSTRAINT "member_invitations_status_check" CHECK ("member_invitations"."status" in ('INVITED', 'REGISTERED', 'CANCELLED')),
	CONSTRAINT "member_invitations_registration_check" CHECK (("member_invitations"."status" = 'REGISTERED') = ("member_invitations"."registration_completed_at" is not null)),
	CONSTRAINT "member_invitations_target_check" CHECK (case when "member_invitations"."invited_by_user_type" = 'MEMBER' then "member_invitations"."member_id" is not null and "member_invitations"."project_id" is null else "member_invitations"."project_id" is not null end)
);
--> statement-breakpoint
CREATE TABLE "partner_invitations" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_id" text NOT NULL,
	"invited_by_user_type" text NOT NULL,
	"invited_by_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"token_hash" text NOT NULL,
	"invitee_email" text NOT NULL,
	"invitee_last_name" text,
	"invitee_first_name" text,
	"invitee_last_name_kana" text,
	"invitee_first_name_kana" text,
	"invited_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'INVITED' NOT NULL,
	"registration_completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_invitations_token_hash_unique" UNIQUE("token_hash"),
	CONSTRAINT "partner_invitations_invited_by_user_type_check" CHECK ("partner_invitations"."invited_by_user_type" in ('PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN')),
	CONSTRAINT "partner_invitations_status_check" CHECK ("partner_invitations"."status" in ('INVITED', 'REGISTERED', 'CANCELLED')),
	CONSTRAINT "partner_invitations_registration_check" CHECK (("partner_invitations"."status" = 'REGISTERED') = ("partner_invitations"."registration_completed_at" is not null))
);
--> statement-breakpoint
ALTER TABLE "admin_invitations" ADD CONSTRAINT "admin_invitations_admin_user_id_admin_users_id_fk" FOREIGN KEY ("admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "admin_invitations" ADD CONSTRAINT "admin_invitations_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_invitations" ADD CONSTRAINT "alliance_headquarters_invitations_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_invitations" ADD CONSTRAINT "alliance_headquarters_invitations_headquarters_fk" FOREIGN KEY ("alliance_headquarters_id") REFERENCES "public"."alliance_headquarters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_invitations" ADD CONSTRAINT "member_invitations_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_invitations" ADD CONSTRAINT "member_invitations_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_invitations" ADD CONSTRAINT "member_invitations_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_invitations" ADD CONSTRAINT "partner_invitations_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_invitations" ADD CONSTRAINT "partner_invitations_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "admin_invitations_admin_user_id_index" ON "admin_invitations" USING btree ("admin_user_id");--> statement-breakpoint
CREATE INDEX "alliance_headquarters_invitations_headquarters_index" ON "alliance_headquarters_invitations" USING btree ("alliance_headquarters_id");--> statement-breakpoint
CREATE INDEX "member_invitations_member_id_index" ON "member_invitations" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "member_invitations_project_id_index" ON "member_invitations" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "partner_invitations_partner_id_index" ON "partner_invitations" USING btree ("partner_id");