CREATE TABLE "faqs" (
	"id" text PRIMARY KEY NOT NULL,
	"question" text NOT NULL,
	"answer" text NOT NULL,
	"audience_scope" text DEFAULT 'COMMON' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "faqs_audience_scope_check" CHECK ("faqs"."audience_scope" in ('COMMON', 'MEMBER', 'PARTNER'))
);
--> statement-breakpoint
CREATE TABLE "inquiries" (
	"id" text PRIMARY KEY NOT NULL,
	"inquiry_number" text NOT NULL,
	"member_id" text,
	"partner_id" text,
	"assigned_admin_user_id" text,
	"inquiry_type" text NOT NULL,
	"subject" text NOT NULL,
	"body" text NOT NULL,
	"inquiry_status" text DEFAULT 'OPEN' NOT NULL,
	"opened_by_user_type" text NOT NULL,
	"opened_by_user_id" text NOT NULL,
	"recipient_user_type" text,
	"recipient_user_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "inquiries_inquiry_number_unique" UNIQUE("inquiry_number"),
	CONSTRAINT "inquiries_inquiry_status_check" CHECK ("inquiries"."inquiry_status" in ('OPEN', 'IN_PROGRESS', 'ANSWERED', 'COMPLETED')),
	CONSTRAINT "inquiries_opened_by_user_type_check" CHECK ("inquiries"."opened_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN')),
	CONSTRAINT "inquiries_recipient_user_type_check" CHECK ("inquiries"."recipient_user_type" in ('MEMBER', 'PARTNER')),
	CONSTRAINT "inquiries_counterpart_check" CHECK (num_nonnulls("inquiries"."member_id", "inquiries"."partner_id") <= 1),
	CONSTRAINT "inquiries_recipient_check" CHECK (num_nonnulls("inquiries"."recipient_user_type", "inquiries"."recipient_user_id") = case when "inquiries"."opened_by_user_type" = 'ADMIN' then 2 else 0 end)
);
--> statement-breakpoint
CREATE TABLE "inquiry_messages" (
	"id" text PRIMARY KEY NOT NULL,
	"inquiry_id" text NOT NULL,
	"posted_by_user_type" text NOT NULL,
	"posted_by_user_id" text NOT NULL,
	"body" text NOT NULL,
	"posted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "inquiry_messages_posted_by_user_type_check" CHECK ("inquiry_messages"."posted_by_user_type" in ('MEMBER', 'PARTNER', 'ADMIN'))
);
--> statement-breakpoint
CREATE TABLE "inquiry_reads" (
	"id" text PRIMARY KEY NOT NULL,
	"inquiry_id" text NOT NULL,
	"user_type" text NOT NULL,
	"user_id" text NOT NULL,
	"last_read_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "inquiry_reads_inquiry_user_unique" UNIQUE("inquiry_id","user_type","user_id"),
	CONSTRAINT "inquiry_reads_user_type_check" CHECK ("inquiry_reads"."user_type" in ('MEMBER', 'PARTNER'))
);
--> statement-breakpoint
CREATE TABLE "notification_read_cursors" (
	"id" text PRIMARY KEY NOT NULL,
	"user_type" text NOT NULL,
	"user_id" text NOT NULL,
	"read_until" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "notification_read_cursors_user_unique" UNIQUE("user_type","user_id"),
	CONSTRAINT "notification_read_cursors_user_type_check" CHECK ("notification_read_cursors"."user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'))
);
--> statement-breakpoint
CREATE TABLE "notification_reads" (
	"id" text PRIMARY KEY NOT NULL,
	"notification_id" text NOT NULL,
	"user_type" text NOT NULL,
	"user_id" text NOT NULL,
	"read_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "notification_reads_notification_user_unique" UNIQUE("notification_id","user_type","user_id"),
	CONSTRAINT "notification_reads_user_type_check" CHECK ("notification_reads"."user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'))
);
--> statement-breakpoint
CREATE TABLE "notification_types" (
	"id" text PRIMARY KEY NOT NULL,
	"category" text NOT NULL,
	"type_name" text NOT NULL,
	"delivery_destination" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "notification_types_type_name_unique" UNIQUE("type_name"),
	CONSTRAINT "notification_types_delivery_destination_check" CHECK ("notification_types"."delivery_destination" in ('EMAIL_AND_SYSTEM', 'SYSTEM_ONLY'))
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" text PRIMARY KEY NOT NULL,
	"notification_type_id" text NOT NULL,
	"admin_user_id" text,
	"project_id" text,
	"project_definition_id" text,
	"subject" text NOT NULL,
	"body" text NOT NULL,
	"audience_type" text NOT NULL,
	"recipient_user_type" text,
	"recipient_user_id" text,
	"status" text NOT NULL,
	"scheduled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "notifications_audience_type_check" CHECK ("notifications"."audience_type" in ('ALL', 'PROJECT', 'INDIVIDUAL')),
	CONSTRAINT "notifications_recipient_user_type_check" CHECK ("notifications"."recipient_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN')),
	CONSTRAINT "notifications_status_check" CHECK ("notifications"."status" in ('DRAFT', 'SCHEDULED', 'SENT', 'WITHDRAWN')),
	CONSTRAINT "notifications_recipient_check" CHECK (num_nonnulls("notifications"."recipient_user_type", "notifications"."recipient_user_id") = case when "notifications"."audience_type" = 'INDIVIDUAL' then 2 else 0 end),
	CONSTRAINT "notifications_project_check" CHECK (num_nonnulls("notifications"."project_id", "notifications"."project_definition_id") = case when "notifications"."audience_type" = 'PROJECT' then 1 else 0 end),
	CONSTRAINT "notifications_scheduled_at_check" CHECK ("notifications"."status" = 'DRAFT' or "notifications"."scheduled_at" is not null),
	CONSTRAINT "notifications_withdrawn_check" CHECK ("notifications"."status" <> 'WITHDRAWN' or "notifications"."audience_type" <> 'INDIVIDUAL')
);
--> statement-breakpoint
CREATE TABLE "site_maintenance_modes" (
	"id" text PRIMARY KEY NOT NULL,
	"target_site" text NOT NULL,
	"is_under_maintenance" boolean DEFAULT false NOT NULL,
	"display_text" text,
	"starts_at" timestamp with time zone,
	"ends_at" timestamp with time zone,
	"switched_by_admin_user_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "site_maintenance_modes_target_site_unique" UNIQUE("target_site"),
	CONSTRAINT "site_maintenance_modes_target_site_check" CHECK ("site_maintenance_modes"."target_site" in ('MEMBER_PORTAL', 'PARTNER_CONSOLE')),
	CONSTRAINT "site_maintenance_modes_starts_at_check" CHECK (not "site_maintenance_modes"."is_under_maintenance" or "site_maintenance_modes"."starts_at" is not null),
	CONSTRAINT "site_maintenance_modes_period_check" CHECK ("site_maintenance_modes"."ends_at" > "site_maintenance_modes"."starts_at")
);
--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_assigned_admin_user_id_admin_users_id_fk" FOREIGN KEY ("assigned_admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inquiry_messages" ADD CONSTRAINT "inquiry_messages_inquiry_id_inquiries_id_fk" FOREIGN KEY ("inquiry_id") REFERENCES "public"."inquiries"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inquiry_reads" ADD CONSTRAINT "inquiry_reads_inquiry_id_inquiries_id_fk" FOREIGN KEY ("inquiry_id") REFERENCES "public"."inquiries"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_reads" ADD CONSTRAINT "notification_reads_notification_id_notifications_id_fk" FOREIGN KEY ("notification_id") REFERENCES "public"."notifications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_notification_type_id_notification_types_id_fk" FOREIGN KEY ("notification_type_id") REFERENCES "public"."notification_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_admin_user_id_admin_users_id_fk" FOREIGN KEY ("admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_project_definition_id_project_definitions_id_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "site_maintenance_modes" ADD CONSTRAINT "site_maintenance_modes_switched_by_fk" FOREIGN KEY ("switched_by_admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "inquiries_member_id_index" ON "inquiries" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "inquiries_partner_id_index" ON "inquiries" USING btree ("partner_id");--> statement-breakpoint
CREATE INDEX "inquiries_assigned_admin_user_id_index" ON "inquiries" USING btree ("assigned_admin_user_id");--> statement-breakpoint
CREATE INDEX "inquiries_opened_by_index" ON "inquiries" USING btree ("opened_by_user_type","opened_by_user_id");--> statement-breakpoint
CREATE INDEX "inquiries_recipient_index" ON "inquiries" USING btree ("recipient_user_type","recipient_user_id");--> statement-breakpoint
CREATE INDEX "inquiry_messages_inquiry_id_index" ON "inquiry_messages" USING btree ("inquiry_id");--> statement-breakpoint
CREATE INDEX "notifications_notification_type_id_index" ON "notifications" USING btree ("notification_type_id");--> statement-breakpoint
CREATE INDEX "notifications_admin_user_id_index" ON "notifications" USING btree ("admin_user_id");--> statement-breakpoint
CREATE INDEX "notifications_project_id_index" ON "notifications" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "notifications_project_definition_id_index" ON "notifications" USING btree ("project_definition_id");--> statement-breakpoint
CREATE INDEX "notifications_recipient_index" ON "notifications" USING btree ("recipient_user_type","recipient_user_id");--> statement-breakpoint
CREATE INDEX "site_maintenance_modes_switched_by_admin_user_id_index" ON "site_maintenance_modes" USING btree ("switched_by_admin_user_id");