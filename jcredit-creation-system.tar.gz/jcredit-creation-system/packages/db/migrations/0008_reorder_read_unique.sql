ALTER TABLE "inquiry_reads" DROP CONSTRAINT "inquiry_reads_inquiry_user_unique";--> statement-breakpoint
ALTER TABLE "notification_reads" DROP CONSTRAINT "notification_reads_notification_user_unique";--> statement-breakpoint
DROP INDEX "inquiry_messages_inquiry_id_index";--> statement-breakpoint
CREATE INDEX "inquiry_messages_inquiry_id_posted_at_index" ON "inquiry_messages" USING btree ("inquiry_id","posted_at");--> statement-breakpoint
ALTER TABLE "inquiry_reads" ADD CONSTRAINT "inquiry_reads_user_inquiry_unique" UNIQUE("user_type","user_id","inquiry_id");--> statement-breakpoint
ALTER TABLE "notification_reads" ADD CONSTRAINT "notification_reads_user_notification_unique" UNIQUE("user_type","user_id","notification_id");