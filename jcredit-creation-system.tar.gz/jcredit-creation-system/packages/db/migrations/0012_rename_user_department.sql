ALTER TABLE "admin_users" RENAME COLUMN "department_title" TO "department";--> statement-breakpoint
ALTER TABLE "alliance_headquarters_users" RENAME COLUMN "department_title" TO "department";--> statement-breakpoint
ALTER TABLE "member_users" RENAME COLUMN "department_title" TO "department";--> statement-breakpoint
ALTER TABLE "partner_users" RENAME COLUMN "department_title" TO "department";