ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_counterpart_check";--> statement-breakpoint
ALTER TABLE "partners" DROP CONSTRAINT "partners_alliance_headquarters_id_alliance_headquarters_id_fk";
--> statement-breakpoint
ALTER TABLE "inquiries" DROP CONSTRAINT "inquiries_alliance_headquarters_id_alliance_headquarters_id_fk";
--> statement-breakpoint
DROP INDEX "partners_alliance_headquarters_id_index";--> statement-breakpoint
DROP INDEX "inquiries_alliance_headquarters_id_index";--> statement-breakpoint
ALTER TABLE "partners" DROP COLUMN "alliance_headquarters_id";--> statement-breakpoint
ALTER TABLE "inquiries" DROP COLUMN "alliance_headquarters_id";--> statement-breakpoint
ALTER TABLE "inquiries" ADD CONSTRAINT "inquiries_counterpart_check" CHECK (num_nonnulls("inquiries"."member_id", "inquiries"."partner_id") <= 1);