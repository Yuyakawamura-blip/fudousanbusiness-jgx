CREATE TABLE "admin_user_roles" (
	"id" text PRIMARY KEY NOT NULL,
	"admin_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"assigned_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "admin_user_roles_user_role_unique" UNIQUE("admin_user_id","role_id")
);
--> statement-breakpoint
CREATE TABLE "admin_users" (
	"id" text PRIMARY KEY NOT NULL,
	"auth_subject_id" text NOT NULL,
	"email" text,
	"pending_email" text,
	"phone_number" text,
	"last_name" text,
	"first_name" text,
	"last_name_kana" text,
	"first_name_kana" text,
	"department_title" text,
	"account_status" text DEFAULT 'ACTIVE' NOT NULL,
	"is_email_undeliverable" boolean DEFAULT false NOT NULL,
	"failed_login_count" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"last_login_at" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "admin_users_auth_subject_id_unique" UNIQUE("auth_subject_id"),
	CONSTRAINT "admin_users_email_unique" UNIQUE("email"),
	CONSTRAINT "admin_users_account_status_check" CHECK ("admin_users"."account_status" in ('ACTIVE', 'DISABLED'))
);
--> statement-breakpoint
CREATE TABLE "alliance_headquarters" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text,
	"name_kana" text,
	"postal_code" text,
	"prefecture" text,
	"city" text,
	"street_address" text,
	"building_name" text,
	"representative_phone_number" text,
	"representative_contact_email" text,
	"contact_person_name" text,
	"alliance_headquarters_status" text DEFAULT 'ACTIVE' NOT NULL,
	"terminated_at" timestamp with time zone,
	"termination_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "alliance_headquarters_status_check" CHECK ("alliance_headquarters"."alliance_headquarters_status" in ('INVITED', 'ACTIVE', 'TERMINATED')),
	CONSTRAINT "alliance_headquarters_termination_check" CHECK (("alliance_headquarters"."alliance_headquarters_status" = 'TERMINATED') = ("alliance_headquarters"."terminated_at" is not null and "alliance_headquarters"."termination_reason" is not null))
);
--> statement-breakpoint
CREATE TABLE "alliance_headquarters_user_roles" (
	"id" text PRIMARY KEY NOT NULL,
	"alliance_headquarters_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"assigned_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "alliance_headquarters_user_roles_user_role_unique" UNIQUE("alliance_headquarters_user_id","role_id")
);
--> statement-breakpoint
CREATE TABLE "alliance_headquarters_users" (
	"id" text PRIMARY KEY NOT NULL,
	"alliance_headquarters_id" text NOT NULL,
	"auth_subject_id" text NOT NULL,
	"email" text,
	"pending_email" text,
	"phone_number" text,
	"last_name" text,
	"first_name" text,
	"last_name_kana" text,
	"first_name_kana" text,
	"department_title" text,
	"account_status" text DEFAULT 'ACTIVE' NOT NULL,
	"is_email_undeliverable" boolean DEFAULT false NOT NULL,
	"failed_login_count" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"last_login_at" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "alliance_headquarters_users_auth_subject_id_unique" UNIQUE("auth_subject_id"),
	CONSTRAINT "alliance_headquarters_users_email_unique" UNIQUE("email"),
	CONSTRAINT "alliance_headquarters_users_account_status_check" CHECK ("alliance_headquarters_users"."account_status" in ('ACTIVE', 'DISABLED'))
);
--> statement-breakpoint
CREATE TABLE "member_user_roles" (
	"id" text PRIMARY KEY NOT NULL,
	"member_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"assigned_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "member_user_roles_user_role_unique" UNIQUE("member_user_id","role_id")
);
--> statement-breakpoint
CREATE TABLE "member_users" (
	"id" text PRIMARY KEY NOT NULL,
	"member_id" text NOT NULL,
	"auth_subject_id" text,
	"email" text,
	"pending_email" text,
	"phone_number" text,
	"last_name" text,
	"first_name" text,
	"last_name_kana" text,
	"first_name_kana" text,
	"department_title" text,
	"account_status" text DEFAULT 'ACTIVE' NOT NULL,
	"is_email_undeliverable" boolean DEFAULT false NOT NULL,
	"failed_login_count" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"last_login_at" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "member_users_auth_subject_id_unique" UNIQUE("auth_subject_id"),
	CONSTRAINT "member_users_email_unique" UNIQUE("email"),
	CONSTRAINT "member_users_account_status_check" CHECK ("member_users"."account_status" in ('ACTIVE', 'DISABLED'))
);
--> statement-breakpoint
CREATE TABLE "members" (
	"id" text PRIMARY KEY NOT NULL,
	"member_type" text,
	"member_status" text DEFAULT 'PRE_REGISTERED' NOT NULL,
	"corporate_name" text,
	"corporate_name_kana" text,
	"representative_title" text,
	"representative_last_name" text,
	"representative_first_name" text,
	"representative_last_name_kana" text,
	"representative_first_name_kana" text,
	"corporate_number" text,
	"postal_code" text,
	"prefecture" text,
	"city" text,
	"street_address" text,
	"building_name" text,
	"representative_phone_number" text,
	"representative_contact_email" text,
	"fax_number" text,
	"brand_type" text DEFAULT 'GENERAL' NOT NULL,
	"acquisition_channel" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "members_member_type_check" CHECK ("members"."member_type" in ('INDIVIDUAL', 'CORPORATE')),
	CONSTRAINT "members_member_status_check" CHECK ("members"."member_status" in ('PRE_REGISTERED', 'PROVISIONAL', 'ACTIVE', 'WITHDRAWN')),
	CONSTRAINT "members_brand_type_check" CHECK ("members"."brand_type" in ('GENERAL', 'TOKYO_CCI', 'JCCI')),
	CONSTRAINT "members_registered_fields_check" CHECK ("members"."member_status" = 'PRE_REGISTERED' or ("members"."member_type" is not null and "members"."postal_code" is not null and "members"."prefecture" is not null and "members"."city" is not null and "members"."street_address" is not null and "members"."representative_phone_number" is not null and "members"."representative_last_name" is not null and "members"."representative_first_name" is not null and "members"."representative_last_name_kana" is not null and "members"."representative_first_name_kana" is not null)),
	CONSTRAINT "members_corporate_name_check" CHECK (("members"."member_type" is distinct from 'CORPORATE' or "members"."member_status" = 'PRE_REGISTERED' or "members"."corporate_name" is not null) and ("members"."member_type" is distinct from 'INDIVIDUAL' or ("members"."corporate_name" is null and "members"."representative_title" is null)))
);
--> statement-breakpoint
CREATE TABLE "partner_user_roles" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_user_id" text NOT NULL,
	"role_id" text NOT NULL,
	"assigned_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_user_roles_user_role_unique" UNIQUE("partner_user_id","role_id")
);
--> statement-breakpoint
CREATE TABLE "partner_users" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_id" text NOT NULL,
	"auth_subject_id" text NOT NULL,
	"email" text,
	"pending_email" text,
	"phone_number" text,
	"last_name" text,
	"first_name" text,
	"last_name_kana" text,
	"first_name_kana" text,
	"department_title" text,
	"account_status" text DEFAULT 'ACTIVE' NOT NULL,
	"is_email_undeliverable" boolean DEFAULT false NOT NULL,
	"failed_login_count" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"last_login_at" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"deleted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_users_auth_subject_id_unique" UNIQUE("auth_subject_id"),
	CONSTRAINT "partner_users_email_unique" UNIQUE("email"),
	CONSTRAINT "partner_users_account_status_check" CHECK ("partner_users"."account_status" in ('ACTIVE', 'DISABLED'))
);
--> statement-breakpoint
CREATE TABLE "partners" (
	"id" text PRIMARY KEY NOT NULL,
	"alliance_headquarters_id" text,
	"name" text,
	"name_kana" text,
	"postal_code" text,
	"prefecture" text,
	"city" text,
	"street_address" text,
	"building_name" text,
	"representative_phone_number" text,
	"representative_contact_email" text,
	"contact_person_name" text,
	"partner_status" text DEFAULT 'ACTIVE' NOT NULL,
	"terminated_at" timestamp with time zone,
	"termination_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partners_partner_status_check" CHECK ("partners"."partner_status" in ('INVITED', 'ACTIVE', 'TERMINATED')),
	CONSTRAINT "partners_termination_check" CHECK (("partners"."partner_status" = 'TERMINATED') = ("partners"."terminated_at" is not null and "partners"."termination_reason" is not null))
);
--> statement-breakpoint
CREATE TABLE "roles" (
	"id" text PRIMARY KEY NOT NULL,
	"role_name" text NOT NULL,
	"description" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "roles_role_name_unique" UNIQUE("role_name"),
	CONSTRAINT "roles_role_name_check" CHECK ("roles"."role_name" in ('MANAGER', 'STAFF'))
);
--> statement-breakpoint
ALTER TABLE "admin_user_roles" ADD CONSTRAINT "admin_user_roles_admin_user_id_admin_users_id_fk" FOREIGN KEY ("admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "admin_user_roles" ADD CONSTRAINT "admin_user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_user_roles" ADD CONSTRAINT "alliance_headquarters_user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_user_roles" ADD CONSTRAINT "alliance_headquarters_user_roles_user_fk" FOREIGN KEY ("alliance_headquarters_user_id") REFERENCES "public"."alliance_headquarters_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "alliance_headquarters_users" ADD CONSTRAINT "alliance_headquarters_users_headquarters_fk" FOREIGN KEY ("alliance_headquarters_id") REFERENCES "public"."alliance_headquarters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_user_roles" ADD CONSTRAINT "member_user_roles_member_user_id_member_users_id_fk" FOREIGN KEY ("member_user_id") REFERENCES "public"."member_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_user_roles" ADD CONSTRAINT "member_user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_users" ADD CONSTRAINT "member_users_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_user_roles" ADD CONSTRAINT "partner_user_roles_partner_user_id_partner_users_id_fk" FOREIGN KEY ("partner_user_id") REFERENCES "public"."partner_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_user_roles" ADD CONSTRAINT "partner_user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_users" ADD CONSTRAINT "partner_users_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partners" ADD CONSTRAINT "partners_alliance_headquarters_id_alliance_headquarters_id_fk" FOREIGN KEY ("alliance_headquarters_id") REFERENCES "public"."alliance_headquarters"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "alliance_headquarters_users_alliance_headquarters_id_index" ON "alliance_headquarters_users" USING btree ("alliance_headquarters_id");--> statement-breakpoint
CREATE INDEX "member_users_member_id_index" ON "member_users" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "partner_users_partner_id_index" ON "partner_users" USING btree ("partner_id");--> statement-breakpoint
CREATE INDEX "partners_alliance_headquarters_id_index" ON "partners" USING btree ("alliance_headquarters_id");