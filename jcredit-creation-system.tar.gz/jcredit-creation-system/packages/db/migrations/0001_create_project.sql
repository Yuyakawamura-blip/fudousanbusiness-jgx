CREATE TABLE "document_requirements" (
	"id" text PRIMARY KEY NOT NULL,
	"project_definition_id" text NOT NULL,
	"document_type" text NOT NULL,
	"requirement_type" text NOT NULL,
	"description" text,
	"is_not_applicable_allowed" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "document_requirements_definition_document_type_unique" UNIQUE("project_definition_id","document_type"),
	CONSTRAINT "document_requirements_requirement_type_check" CHECK ("document_requirements"."requirement_type" in ('REQUIRED', 'OPTIONAL'))
);
--> statement-breakpoint
CREATE TABLE "equipment_types" (
	"id" text PRIMARY KEY NOT NULL,
	"equipment_type_code" text NOT NULL,
	"type_name" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "equipment_types_equipment_type_code_unique" UNIQUE("equipment_type_code"),
	CONSTRAINT "equipment_types_equipment_type_code_check" CHECK ("equipment_types"."equipment_type_code" in ('SOLAR', 'LED'))
);
--> statement-breakpoint
CREATE TABLE "project_definitions" (
	"id" text PRIMARY KEY NOT NULL,
	"equipment_type_id" text NOT NULL,
	"project_definition_name" text NOT NULL,
	"methodology_code" text NOT NULL,
	"recruitment_status" text DEFAULT 'DRAFT' NOT NULL,
	"description" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "project_definitions_recruitment_status_check" CHECK ("project_definitions"."recruitment_status" in ('DRAFT', 'OPEN', 'SUSPENDED', 'CLOSED'))
);
--> statement-breakpoint
CREATE TABLE "projects" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_id" text NOT NULL,
	"project_definition_id" text NOT NULL,
	"project_code" text NOT NULL,
	"display_name" text NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "projects_project_code_unique" UNIQUE("project_code"),
	CONSTRAINT "projects_partner_definition_unique" UNIQUE("partner_id","project_definition_id"),
	CONSTRAINT "projects_status_check" CHECK ("projects"."status" in ('ACTIVE', 'CLOSED'))
);
--> statement-breakpoint
CREATE TABLE "recruitment_periods" (
	"id" text PRIMARY KEY NOT NULL,
	"project_definition_id" text NOT NULL,
	"period_name" text NOT NULL,
	"recruitment_start_at" timestamp with time zone NOT NULL,
	"recruitment_end_at" timestamp with time zone NOT NULL,
	"target_fiscal_year" smallint NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "recruitment_periods_range_check" CHECK ("recruitment_periods"."recruitment_start_at" < "recruitment_periods"."recruitment_end_at")
);
--> statement-breakpoint
CREATE TABLE "terms_versions" (
	"id" text PRIMARY KEY NOT NULL,
	"project_definition_id" text,
	"terms_type" text NOT NULL,
	"item_code" text NOT NULL,
	"version" text NOT NULL,
	"content" text NOT NULL,
	"effective_from" date NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "terms_versions_item_version_unique" UNIQUE NULLS NOT DISTINCT("terms_type","item_code","project_definition_id","version"),
	CONSTRAINT "terms_versions_terms_type_check" CHECK ("terms_versions"."terms_type" in ('TERMS_OF_USE', 'PRIVACY_POLICY', 'MEMBER_AGREEMENT', 'SERVICE_CONSENT', 'DECLARATION')),
	CONSTRAINT "terms_versions_scope_check" CHECK (("terms_versions"."project_definition_id" is null) = ("terms_versions"."terms_type" in ('TERMS_OF_USE', 'PRIVACY_POLICY')))
);
--> statement-breakpoint
ALTER TABLE "document_requirements" ADD CONSTRAINT "document_requirements_project_definition_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_definitions" ADD CONSTRAINT "project_definitions_equipment_type_id_equipment_types_id_fk" FOREIGN KEY ("equipment_type_id") REFERENCES "public"."equipment_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_project_definition_id_project_definitions_id_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recruitment_periods" ADD CONSTRAINT "recruitment_periods_project_definition_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "terms_versions" ADD CONSTRAINT "terms_versions_project_definition_id_project_definitions_id_fk" FOREIGN KEY ("project_definition_id") REFERENCES "public"."project_definitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "project_definitions_equipment_type_id_index" ON "project_definitions" USING btree ("equipment_type_id");--> statement-breakpoint
CREATE INDEX "projects_project_definition_id_index" ON "projects" USING btree ("project_definition_id");--> statement-breakpoint
CREATE INDEX "recruitment_periods_project_definition_id_index" ON "recruitment_periods" USING btree ("project_definition_id");--> statement-breakpoint
CREATE INDEX "terms_versions_project_definition_id_index" ON "terms_versions" USING btree ("project_definition_id");