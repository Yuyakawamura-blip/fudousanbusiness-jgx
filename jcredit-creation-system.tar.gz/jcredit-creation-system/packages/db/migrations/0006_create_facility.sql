CREATE TABLE "document_slots" (
	"id" text PRIMARY KEY NOT NULL,
	"project_application_id" text NOT NULL,
	"document_requirement_id" text,
	"facility_id" text,
	"solar_generation_system_id" text,
	"subsidy_id" text,
	"document_type" text NOT NULL,
	"requirement_type" text NOT NULL,
	"slot_status" text DEFAULT 'NOT_SUBMITTED' NOT NULL,
	"not_applicable_reason" text,
	"not_applicable_selected_at" timestamp with time zone,
	"not_applicable_selected_by_user_type" text,
	"not_applicable_selected_by_user_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "document_slots_requirement_type_check" CHECK ("document_slots"."requirement_type" in ('REQUIRED', 'OPTIONAL')),
	CONSTRAINT "document_slots_slot_status_check" CHECK ("document_slots"."slot_status" in ('NOT_SUBMITTED', 'SUBMITTED', 'NOT_APPLICABLE')),
	CONSTRAINT "document_slots_not_applicable_selected_by_user_type_check" CHECK ("document_slots"."not_applicable_selected_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN')),
	CONSTRAINT "document_slots_target_check" CHECK (num_nonnulls("document_slots"."facility_id", "document_slots"."solar_generation_system_id", "document_slots"."subsidy_id") <= 1),
	CONSTRAINT "document_slots_not_applicable_check" CHECK (num_nonnulls("document_slots"."not_applicable_reason", "document_slots"."not_applicable_selected_at", "document_slots"."not_applicable_selected_by_user_type", "document_slots"."not_applicable_selected_by_user_id") = case when "document_slots"."slot_status" = 'NOT_APPLICABLE' then 4 else 0 end)
);
--> statement-breakpoint
CREATE TABLE "evidence_documents" (
	"id" text PRIMARY KEY NOT NULL,
	"document_slot_id" text NOT NULL,
	"replaced_evidence_document_id" text,
	"storage_object_key" text NOT NULL,
	"file_name" text NOT NULL,
	"mime_type" text NOT NULL,
	"file_size_bytes" bigint NOT NULL,
	"file_hash" text,
	"reference_note" text,
	"verification_status" text DEFAULT 'UNVERIFIED' NOT NULL,
	"uploaded_at" timestamp with time zone DEFAULT now() NOT NULL,
	"uploaded_by_user_type" text NOT NULL,
	"uploaded_by_user_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "evidence_documents_storage_object_key_unique" UNIQUE("storage_object_key"),
	CONSTRAINT "evidence_documents_verification_status_check" CHECK ("evidence_documents"."verification_status" in ('UNVERIFIED', 'VERIFIED')),
	CONSTRAINT "evidence_documents_uploaded_by_user_type_check" CHECK ("evidence_documents"."uploaded_by_user_type" in ('MEMBER', 'PARTNER', 'ALLIANCE_HEADQUARTERS', 'ADMIN'))
);
--> statement-breakpoint
CREATE TABLE "facilities" (
	"id" text PRIMARY KEY NOT NULL,
	"project_application_id" text NOT NULL,
	"equipment_type_code" text NOT NULL,
	"facility_name" text,
	"postal_code" text,
	"prefecture" text,
	"city" text,
	"street_address" text,
	"building_name" text,
	"operation_start_date" date NOT NULL,
	"total_investment_amount" numeric(15, 0) NOT NULL,
	"purchased_electricity_unit_price" numeric(10, 4) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "facilities_id_equipment_type_code_unique" UNIQUE("id","equipment_type_code")
);
--> statement-breakpoint
CREATE TABLE "led_fixtures" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"installation_location" text NOT NULL,
	"model_number" text NOT NULL,
	"serial_number" text,
	"rated_output_w" numeric(10, 3) NOT NULL,
	"efficiency_lm_per_w" numeric(12, 3),
	"quantity" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "lighting_facility_details" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"equipment_type_code" text DEFAULT 'LED' NOT NULL,
	"total_floors" smallint NOT NULL,
	"target_floors" text NOT NULL,
	"prior_lighting_installed_on" date,
	"building_completed_on" date,
	"construction_start_fiscal_year" smallint NOT NULL,
	"construction_end_fiscal_year" smallint NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "lighting_facility_details_facility_id_unique" UNIQUE("facility_id"),
	CONSTRAINT "lighting_facility_details_equipment_type_check" CHECK ("lighting_facility_details"."equipment_type_code" = 'LED'),
	CONSTRAINT "lighting_facility_details_installed_check" CHECK (num_nonnulls("lighting_facility_details"."prior_lighting_installed_on", "lighting_facility_details"."building_completed_on") >= 1),
	CONSTRAINT "lighting_facility_details_construction_range_check" CHECK ("lighting_facility_details"."construction_start_fiscal_year" <= "lighting_facility_details"."construction_end_fiscal_year")
);
--> statement-breakpoint
CREATE TABLE "power_conditioner_units" (
	"id" text PRIMARY KEY NOT NULL,
	"power_conditioner_id" text NOT NULL,
	"serial_number" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "power_conditioners" (
	"id" text PRIMARY KEY NOT NULL,
	"solar_generation_system_id" text NOT NULL,
	"manufacturer" text NOT NULL,
	"model_number" text NOT NULL,
	"night_standby_power_w" numeric(10, 3) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "prior_equipment_types" (
	"id" text PRIMARY KEY NOT NULL,
	"equipment_type_id" text NOT NULL,
	"type_name" text NOT NULL,
	"legal_useful_life_years" smallint NOT NULL,
	"application_deadline" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "prior_lighting_fixtures" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"prior_equipment_type_id" text NOT NULL,
	"installation_location" text NOT NULL,
	"model_number" text NOT NULL,
	"serial_number" text,
	"rated_output_w" numeric(10, 3) NOT NULL,
	"efficiency_lm_per_w" numeric(12, 3),
	"quantity" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "solar_facility_details" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"equipment_type_code" text DEFAULT 'SOLAR' NOT NULL,
	"self_consumption_kwh" numeric(18, 3) NOT NULL,
	"sold_electricity_kwh" numeric(18, 3) NOT NULL,
	"sold_electricity_unit_price" numeric(10, 4) NOT NULL,
	"maintenance_cost" numeric(15, 0) NOT NULL,
	"measurement_device_status" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "solar_facility_details_facility_id_unique" UNIQUE("facility_id"),
	CONSTRAINT "solar_facility_details_equipment_type_check" CHECK ("solar_facility_details"."equipment_type_code" = 'SOLAR')
);
--> statement-breakpoint
CREATE TABLE "solar_generation_systems" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"manufacturer" text NOT NULL,
	"model_number" text NOT NULL,
	"serial_number" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "solar_panels" (
	"id" text PRIMARY KEY NOT NULL,
	"solar_generation_system_id" text NOT NULL,
	"rated_max_output_kw" numeric(12, 3) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "storage_batteries" (
	"id" text PRIMARY KEY NOT NULL,
	"solar_generation_system_id" text NOT NULL,
	"manufacturer" text NOT NULL,
	"model_number" text NOT NULL,
	"capacity_kw" numeric(12, 3) NOT NULL,
	"efficiency_rate" numeric(5, 2) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subsidies" (
	"id" text PRIMARY KEY NOT NULL,
	"facility_id" text NOT NULL,
	"subsidy_name" text NOT NULL,
	"amount" numeric(15, 0) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_facility_id_facilities_id_fk" FOREIGN KEY ("facility_id") REFERENCES "public"."facilities"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_subsidy_id_subsidies_id_fk" FOREIGN KEY ("subsidy_id") REFERENCES "public"."subsidies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_project_application_fk" FOREIGN KEY ("project_application_id") REFERENCES "public"."project_applications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_document_requirement_fk" FOREIGN KEY ("document_requirement_id") REFERENCES "public"."document_requirements"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_slots" ADD CONSTRAINT "document_slots_solar_generation_system_fk" FOREIGN KEY ("solar_generation_system_id") REFERENCES "public"."solar_generation_systems"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "evidence_documents" ADD CONSTRAINT "evidence_documents_document_slot_id_document_slots_id_fk" FOREIGN KEY ("document_slot_id") REFERENCES "public"."document_slots"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "evidence_documents" ADD CONSTRAINT "evidence_documents_replaced_evidence_document_fk" FOREIGN KEY ("replaced_evidence_document_id") REFERENCES "public"."evidence_documents"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "facilities" ADD CONSTRAINT "facilities_project_application_id_project_applications_id_fk" FOREIGN KEY ("project_application_id") REFERENCES "public"."project_applications"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "facilities" ADD CONSTRAINT "facilities_equipment_type_code_fk" FOREIGN KEY ("equipment_type_code") REFERENCES "public"."equipment_types"("equipment_type_code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "led_fixtures" ADD CONSTRAINT "led_fixtures_facility_fk" FOREIGN KEY ("facility_id") REFERENCES "public"."lighting_facility_details"("facility_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lighting_facility_details" ADD CONSTRAINT "lighting_facility_details_facility_fk" FOREIGN KEY ("facility_id","equipment_type_code") REFERENCES "public"."facilities"("id","equipment_type_code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "power_conditioner_units" ADD CONSTRAINT "power_conditioner_units_power_conditioner_fk" FOREIGN KEY ("power_conditioner_id") REFERENCES "public"."power_conditioners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "power_conditioners" ADD CONSTRAINT "power_conditioners_solar_generation_system_fk" FOREIGN KEY ("solar_generation_system_id") REFERENCES "public"."solar_generation_systems"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prior_equipment_types" ADD CONSTRAINT "prior_equipment_types_equipment_type_id_equipment_types_id_fk" FOREIGN KEY ("equipment_type_id") REFERENCES "public"."equipment_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prior_lighting_fixtures" ADD CONSTRAINT "prior_lighting_fixtures_facility_fk" FOREIGN KEY ("facility_id") REFERENCES "public"."lighting_facility_details"("facility_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prior_lighting_fixtures" ADD CONSTRAINT "prior_lighting_fixtures_prior_equipment_type_fk" FOREIGN KEY ("prior_equipment_type_id") REFERENCES "public"."prior_equipment_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "solar_facility_details" ADD CONSTRAINT "solar_facility_details_facility_fk" FOREIGN KEY ("facility_id","equipment_type_code") REFERENCES "public"."facilities"("id","equipment_type_code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "solar_generation_systems" ADD CONSTRAINT "solar_generation_systems_facility_fk" FOREIGN KEY ("facility_id") REFERENCES "public"."solar_facility_details"("facility_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "solar_panels" ADD CONSTRAINT "solar_panels_solar_generation_system_fk" FOREIGN KEY ("solar_generation_system_id") REFERENCES "public"."solar_generation_systems"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "storage_batteries" ADD CONSTRAINT "storage_batteries_solar_generation_system_fk" FOREIGN KEY ("solar_generation_system_id") REFERENCES "public"."solar_generation_systems"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subsidies" ADD CONSTRAINT "subsidies_facility_id_facilities_id_fk" FOREIGN KEY ("facility_id") REFERENCES "public"."facilities"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "document_slots_project_application_id_index" ON "document_slots" USING btree ("project_application_id");--> statement-breakpoint
CREATE INDEX "document_slots_document_requirement_id_index" ON "document_slots" USING btree ("document_requirement_id");--> statement-breakpoint
CREATE INDEX "document_slots_facility_id_index" ON "document_slots" USING btree ("facility_id");--> statement-breakpoint
CREATE INDEX "document_slots_solar_generation_system_id_index" ON "document_slots" USING btree ("solar_generation_system_id");--> statement-breakpoint
CREATE INDEX "document_slots_subsidy_id_index" ON "document_slots" USING btree ("subsidy_id");--> statement-breakpoint
CREATE INDEX "evidence_documents_document_slot_id_index" ON "evidence_documents" USING btree ("document_slot_id");--> statement-breakpoint
CREATE INDEX "evidence_documents_replaced_evidence_document_id_index" ON "evidence_documents" USING btree ("replaced_evidence_document_id");--> statement-breakpoint
CREATE INDEX "evidence_documents_uploaded_by_index" ON "evidence_documents" USING btree ("uploaded_by_user_type","uploaded_by_user_id");--> statement-breakpoint
CREATE INDEX "facilities_project_application_id_index" ON "facilities" USING btree ("project_application_id");--> statement-breakpoint
CREATE INDEX "led_fixtures_facility_id_index" ON "led_fixtures" USING btree ("facility_id");--> statement-breakpoint
CREATE INDEX "power_conditioner_units_power_conditioner_id_index" ON "power_conditioner_units" USING btree ("power_conditioner_id");--> statement-breakpoint
CREATE INDEX "power_conditioner_units_serial_number_index" ON "power_conditioner_units" USING btree ("serial_number");--> statement-breakpoint
CREATE INDEX "power_conditioners_solar_generation_system_id_index" ON "power_conditioners" USING btree ("solar_generation_system_id");--> statement-breakpoint
CREATE INDEX "prior_equipment_types_equipment_type_id_index" ON "prior_equipment_types" USING btree ("equipment_type_id");--> statement-breakpoint
CREATE INDEX "prior_lighting_fixtures_facility_id_index" ON "prior_lighting_fixtures" USING btree ("facility_id");--> statement-breakpoint
CREATE INDEX "prior_lighting_fixtures_prior_equipment_type_id_index" ON "prior_lighting_fixtures" USING btree ("prior_equipment_type_id");--> statement-breakpoint
CREATE INDEX "solar_generation_systems_facility_id_index" ON "solar_generation_systems" USING btree ("facility_id");--> statement-breakpoint
CREATE INDEX "solar_generation_systems_serial_number_index" ON "solar_generation_systems" USING btree ("serial_number");--> statement-breakpoint
CREATE INDEX "solar_panels_solar_generation_system_id_index" ON "solar_panels" USING btree ("solar_generation_system_id");--> statement-breakpoint
CREATE INDEX "storage_batteries_solar_generation_system_id_index" ON "storage_batteries" USING btree ("solar_generation_system_id");--> statement-breakpoint
CREATE INDEX "subsidies_facility_id_index" ON "subsidies" USING btree ("facility_id");