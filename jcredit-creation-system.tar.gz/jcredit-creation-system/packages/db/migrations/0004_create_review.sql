CREATE TABLE "member_basic_info_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"member_id" text NOT NULL,
	"review_id" text,
	"member_user_id" text NOT NULL,
	"request_type" text NOT NULL,
	"request_status" text DEFAULT 'SUBMITTED' NOT NULL,
	"submitted_content" jsonb NOT NULL,
	"submitted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "member_basic_info_requests_review_id_unique" UNIQUE("review_id"),
	CONSTRAINT "member_basic_info_requests_request_type_check" CHECK ("member_basic_info_requests"."request_type" in ('REGISTRATION', 'CHANGE')),
	CONSTRAINT "member_basic_info_requests_request_status_check" CHECK ("member_basic_info_requests"."request_status" in ('SUBMITTED', 'APPROVED', 'REJECTED', 'RETURNED')),
	CONSTRAINT "member_basic_info_requests_review_check" CHECK (("member_basic_info_requests"."request_status" = 'SUBMITTED') = ("member_basic_info_requests"."review_id" is null))
);
--> statement-breakpoint
CREATE TABLE "partner_info_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"partner_id" text NOT NULL,
	"review_id" text,
	"requested_by_user_type" text NOT NULL,
	"requested_by_user_id" text NOT NULL,
	"request_status" text DEFAULT 'SUBMITTED' NOT NULL,
	"submitted_content" jsonb NOT NULL,
	"change_reason" text,
	"submitted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_info_requests_review_id_unique" UNIQUE("review_id"),
	CONSTRAINT "partner_info_requests_requested_by_user_type_check" CHECK ("partner_info_requests"."requested_by_user_type" in ('PARTNER', 'ALLIANCE_HEADQUARTERS')),
	CONSTRAINT "partner_info_requests_request_status_check" CHECK ("partner_info_requests"."request_status" in ('SUBMITTED', 'APPROVED', 'REJECTED', 'RETURNED')),
	CONSTRAINT "partner_info_requests_review_check" CHECK (("partner_info_requests"."request_status" = 'SUBMITTED') = ("partner_info_requests"."review_id" is null))
);
--> statement-breakpoint
CREATE TABLE "reviews" (
	"id" text PRIMARY KEY NOT NULL,
	"application_submission_id" text,
	"reviewer_admin_user_id" text NOT NULL,
	"review_stage" text,
	"review_result" text NOT NULL,
	"review_reason" text,
	"review_comment" text,
	"reviewed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reviews_review_stage_check" CHECK ("reviews"."review_stage" in ('FIRST', 'SECOND')),
	CONSTRAINT "reviews_review_result_check" CHECK ("reviews"."review_result" in ('APPROVED', 'REJECTED', 'RETURNED')),
	CONSTRAINT "reviews_stage_check" CHECK (("reviews"."application_submission_id" is null) = ("reviews"."review_stage" is null)),
	CONSTRAINT "reviews_review_reason_check" CHECK (("reviews"."review_result" = 'APPROVED') = ("reviews"."review_reason" is null))
);
--> statement-breakpoint
ALTER TABLE "member_basic_info_requests" ADD CONSTRAINT "member_basic_info_requests_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_basic_info_requests" ADD CONSTRAINT "member_basic_info_requests_review_id_reviews_id_fk" FOREIGN KEY ("review_id") REFERENCES "public"."reviews"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "member_basic_info_requests" ADD CONSTRAINT "member_basic_info_requests_member_user_id_member_users_id_fk" FOREIGN KEY ("member_user_id") REFERENCES "public"."member_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_info_requests" ADD CONSTRAINT "partner_info_requests_partner_id_partners_id_fk" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_info_requests" ADD CONSTRAINT "partner_info_requests_review_id_reviews_id_fk" FOREIGN KEY ("review_id") REFERENCES "public"."reviews"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_reviewer_admin_user_id_admin_users_id_fk" FOREIGN KEY ("reviewer_admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_application_submission_fk" FOREIGN KEY ("application_submission_id") REFERENCES "public"."application_submissions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "member_basic_info_requests_submitted_unique" ON "member_basic_info_requests" USING btree ("member_id") WHERE "member_basic_info_requests"."request_status" = 'SUBMITTED';--> statement-breakpoint
CREATE INDEX "member_basic_info_requests_member_id_index" ON "member_basic_info_requests" USING btree ("member_id");--> statement-breakpoint
CREATE INDEX "member_basic_info_requests_member_user_id_index" ON "member_basic_info_requests" USING btree ("member_user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "partner_info_requests_submitted_unique" ON "partner_info_requests" USING btree ("partner_id") WHERE "partner_info_requests"."request_status" = 'SUBMITTED';--> statement-breakpoint
CREATE INDEX "partner_info_requests_partner_id_index" ON "partner_info_requests" USING btree ("partner_id");--> statement-breakpoint
CREATE INDEX "partner_info_requests_requested_by_index" ON "partner_info_requests" USING btree ("requested_by_user_type","requested_by_user_id");--> statement-breakpoint
CREATE INDEX "reviews_application_submission_id_index" ON "reviews" USING btree ("application_submission_id");--> statement-breakpoint
CREATE INDEX "reviews_reviewer_admin_user_id_index" ON "reviews" USING btree ("reviewer_admin_user_id");