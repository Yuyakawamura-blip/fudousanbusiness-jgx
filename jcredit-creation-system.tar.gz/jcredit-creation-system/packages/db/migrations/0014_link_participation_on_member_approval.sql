ALTER TABLE "participation_requests" DROP CONSTRAINT "participation_requests_decided_by_user_type_check";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP CONSTRAINT "participation_requests_decision_check";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP CONSTRAINT "participation_requests_rejection_reason_check";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP CONSTRAINT "participation_requests_status_check";--> statement-breakpoint
DROP INDEX "participation_requests_pending_unique";--> statement-breakpoint
ALTER TABLE "participation_requests" ADD COLUMN "linked_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD COLUMN "removed_by_admin_user_id" text;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD COLUMN "removed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_removed_by_fk" FOREIGN KEY ("removed_by_admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "participation_requests_active_unique" ON "participation_requests" USING btree ("member_id","project_id") WHERE "participation_requests"."status" in ('PENDING', 'LINKED');--> statement-breakpoint
CREATE INDEX "participation_requests_removed_by_admin_user_id_index" ON "participation_requests" USING btree ("removed_by_admin_user_id");--> statement-breakpoint
ALTER TABLE "participation_requests" DROP COLUMN "decided_by_user_type";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP COLUMN "decided_by_user_id";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP COLUMN "decided_at";--> statement-breakpoint
ALTER TABLE "participation_requests" DROP COLUMN "rejection_reason";--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_linked_check" CHECK (("participation_requests"."status" = 'PENDING') = ("participation_requests"."linked_at" is null));--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_removed_check" CHECK (num_nonnulls("participation_requests"."removed_by_admin_user_id", "participation_requests"."removed_at") = case when "participation_requests"."status" = 'REMOVED' then 2 else 0 end);--> statement-breakpoint
ALTER TABLE "participation_requests" ADD CONSTRAINT "participation_requests_status_check" CHECK ("participation_requests"."status" in ('PENDING', 'LINKED', 'REMOVED'));