import { defineConfig } from "drizzle-kit";
import { loadRootEnvFiles, resolveDatabaseUrl } from "./src/env.ts";

// drizzle-kit はバイナリのため --env-file-if-exists を足せない。リポジトリルートの
// .env / .env.local をここで読み込み、apps/api と接続先を揃える。解決ロジックの正は src/env.ts。
loadRootEnvFiles();

export default defineConfig({
  dialect: "postgresql",
  schema: "./schema/index.ts",
  out: "./migrations",
  // schema は物理名を書かず casing で snake_case に解決する(client.ts と揃える)
  casing: "snake_case",
  dbCredentials: {
    url: resolveDatabaseUrl(),
  },
  strict: true,
  verbose: true,
});
