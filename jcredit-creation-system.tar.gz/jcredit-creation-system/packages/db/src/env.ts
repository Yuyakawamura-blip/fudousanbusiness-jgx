import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseEnv } from "node:util";

/**
 * DB 接続先の解決と、ローカル env ファイルの読み込み。**このファイルが唯一の正**。
 *
 * 接続先の入力は `DB_*` 個別 env のみで、接続 URL はそこから組み立てる(一方向)。
 * `DATABASE_URL` を env として受け付けると入力が二重化し「API と migration で接続先が違う」
 * 食い違いが起きるため受け付けない。
 */

/** ローカル docker compose(リポジトリルートの docker-compose.yml)に合わせた既定値 */
export const DB_DEFAULTS = {
  host: "localhost",
  port: 5432,
  name: "jcredit-db",
  user: "postgres",
  password: "postgres",
} as const;

function buildDatabaseUrl(env: NodeJS.ProcessEnv): string {
  const user = encodeURIComponent(env.DB_USER || DB_DEFAULTS.user);
  const password = encodeURIComponent(env.DB_PASSWORD || DB_DEFAULTS.password);
  const name = encodeURIComponent(env.DB_NAME || DB_DEFAULTS.name);
  const host = env.DB_HOST || DB_DEFAULTS.host;
  const port = env.DB_PORT || DB_DEFAULTS.port;
  const ssl = env.DB_SSL === "true" ? "?ssl=require" : "";
  return `postgres://${user}:${password}@${host}:${port}/${name}${ssl}`;
}

/** `DB_*` から接続 URL を組み立てる。未設定・空文字の項目は既定値で補う */
export function resolveDatabaseUrl(env: NodeJS.ProcessEnv = process.env): string {
  return buildDatabaseUrl(env);
}

/**
 * env ファイルを順に読み、`env` に無い変数だけを足す。優先順位は Node の `--env-file` と同じ:
 * 既に `env` にある値 > 後のファイル > 前のファイル。存在しないファイルは読み飛ばす。
 *
 * `process.loadEnvFile` を使わないのは、あれが「先に読んだファイルが勝つ」挙動で
 * `--env-file`(apps/api の dev スクリプト)と逆順になり、API と migration で接続先が食い違うため。
 */
export function applyEnvFiles(
  paths: readonly string[],
  env: NodeJS.ProcessEnv = process.env,
): void {
  const merged: Record<string, string> = {};
  for (const path of paths) {
    if (existsSync(path)) Object.assign(merged, parseEnv(readFileSync(path, "utf8")));
  }
  for (const [key, value] of Object.entries(merged)) {
    if (env[key] === undefined) env[key] = value;
  }
}

/**
 * リポジトリルートの `.env` → `.env.local` を読み込む(`.env.local` が勝つ)。
 * `pnpm test`(vitest)からは呼ばない — テストは常にローカル既定値へ接続させる。
 */
export function loadRootEnvFiles(): void {
  const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../../..");
  applyEnvFiles([".env", ".env.local"].map((file) => resolve(repoRoot, file)));
}
