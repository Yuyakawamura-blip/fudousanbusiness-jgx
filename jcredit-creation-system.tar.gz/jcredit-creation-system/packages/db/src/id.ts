import { uuidv7 } from "uuidv7";

/** 行 ID(主キー)の生成。アプリ生成 UUIDv7。セッショントークン等には使わない */
export const newId = (): string => uuidv7();
