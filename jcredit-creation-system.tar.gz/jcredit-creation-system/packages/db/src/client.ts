import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "../schema/index.ts";
import { resolveDatabaseUrl } from "./env.ts";

/**
 * DB クライアントの唯一の factory。
 * `drizzle()` を直接呼ばずに必ずこれを使う — casing: "snake_case" が欠けると
 * 実行時に column not found になる(schema は物理名を書かず casing で解決している)。
 */
export const createDb = (databaseUrl?: string) => {
  const client = postgres(databaseUrl ?? resolveDatabaseUrl());
  return drizzle(client, { schema, casing: "snake_case" });
};

export type Db = ReturnType<typeof createDb>;
