import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { applyEnvFiles, resolveDatabaseUrl } from "./env.ts";

describe("applyEnvFiles", () => {
  let dir: string;
  let first: string;
  let second: string;

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), "jcredit-env-"));
    first = join(dir, "first");
    second = join(dir, "second");
    writeFileSync(first, "DB_NAME=from_first\nDB_USER=only_in_first\n");
    writeFileSync(second, "DB_NAME=from_second\n");
  });

  afterEach(() => {
    rmSync(dir, { recursive: true, force: true });
  });

  it("後のファイルが前のファイルを上書きする(--env-file と同じ順序)", () => {
    const env: NodeJS.ProcessEnv = {};
    applyEnvFiles([first, second], env);
    expect(env.DB_NAME).toBe("from_second");
    expect(env.DB_USER).toBe("only_in_first");
  });

  it("既に環境にある変数はどのファイルでも上書きしない", () => {
    const env: NodeJS.ProcessEnv = { DB_NAME: "from_shell" };
    applyEnvFiles([first, second], env);
    expect(env.DB_NAME).toBe("from_shell");
  });

  it("存在しないファイルは読み飛ばす", () => {
    const env: NodeJS.ProcessEnv = {};
    applyEnvFiles([join(dir, "missing"), second], env);
    expect(env.DB_NAME).toBe("from_second");
  });
});

describe("resolveDatabaseUrl", () => {
  it("未設定の項目は既定値で補う", () => {
    expect(resolveDatabaseUrl({})).toBe("postgres://postgres:postgres@localhost:5432/jcredit-db");
  });

  it("DB_* から URL を組み立て、ユーザー名とパスワードはエンコードする", () => {
    const url = resolveDatabaseUrl({
      DB_HOST: "db.example",
      DB_PORT: "6543",
      DB_NAME: "app",
      DB_USER: "u@x",
      DB_PASSWORD: "p:w",
      DB_SSL: "true",
    });
    expect(url).toBe("postgres://u%40x:p%3Aw@db.example:6543/app?ssl=require");
  });
});
