# J-Credit Creation System

J-クレジット創出システム。Next.js 16 + Hono の Turborepo モノレポ(Web のみ)。

| パッケージ | 役割 | dev ポート |
| --- | --- | --- |
| `apps/member-portal` | 会員マイページ | 3000 |
| `apps/admin-console` | 運営者コンソール | 3001 |
| `apps/partner-console` | 創出PTマイページ | 3002 |
| `apps/api` | Hono API(admin / partner / member の 3 レーン)。API ドキュメント: Scalar `http://localhost:8787/docs` | 8787 |
| `packages/ui` | shadcn/ui + デザイントークン | — |
| `packages/shared` | 共通型・enum・RPC クライアント | — |
| `packages/db` | Drizzle スキーマ / migration | — |

## セットアップ

```bash
# Node 24 / pnpm 11(corepack または nvm)
pnpm install
cp .env.example .env            # 必要なら編集
docker compose up -d            # Postgres 17
pnpm --filter @jcredit/api dev  # http://localhost:8787/health/live / docs: http://localhost:8787/docs
pnpm --filter @jcredit/admin-console dev   # http://localhost:3001
```

詳細は [docs/development.md](docs/development.md)。

## ブランチと環境

`main`(本番)← `staging`(ステージング)← `develop`(開発)。作業ブランチは `develop` から切り、**PR は `develop` 向け**(stacked PR は例外 → docs/branching.md)。
`staging` / `main` へは promotion PR のみ。→ [docs/branching.md](docs/branching.md)

## PR のルール

- 画面(`apps/*/app/**` / `packages/ui/**`)を変更した PR は、**変更前 / 変更後のスクリーンショット**を PR 本文の `## Screenshots` に載せる(必須。CI と Claude Code のフックが検査)。
  撮影は **Claude in Chrome**(`/pr-screenshots`)で行う。→ [docs/design/adr/0002-pr-screenshot-gate.md](docs/design/adr/0002-pr-screenshot-gate.md)
- 品質ゲート: `pnpm check` / `pnpm typecheck` / `pnpm test`(CI の `ci.yml`)

## エディタ

`.vscode/settings.json` はチーム共有(Biome を既定フォーマッタに、ウィンドウ配色をブランド色 `#003399` / `#00B3FE` に)。clone した時点で全員に効く。

## エージェント向け規約

[AGENTS.md](AGENTS.md)(共通)/ [CLAUDE.md](CLAUDE.md)(Claude Code 固有)
