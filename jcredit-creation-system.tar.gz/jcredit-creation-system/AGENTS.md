# J-Credit Creation System — Agent Instructions

> このファイルは AI コーディングエージェント(Claude Code / Codex 等)向けの指示書です。規約の更新はこのファイルのみで行い、`CLAUDE.md` は本ファイルを import して Claude 固有の補足だけを持つ。

## Project
J-クレジット創出システム。Next.js 16 + Hono の Turborepo モノレポ。**Web のみ(モバイルアプリ無し)**。
利用者区分ごとに Web アプリを分け、API はレーンで分離する:

| アプリ | 利用者 | dev ポート | API レーン |
| --- | --- | --- | --- |
| `apps/admin-console` | 運営者 | 3001 | `admin`(`/api/admin`) |
| `apps/partner-console` | 創出PT | 3002 | `partner`(`/api/partner`) |
| `apps/member-portal` | 会員 | 3000 | `member`(`/api/member`) |
| `apps/api` | — | 8787 | 3 レーンを mount |

セキュリティ境界が異なるため Web アプリは別デプロイ・別バンドル(コードを相互 import しない)。

## Stack
- Node.js 24 / pnpm 11 / Turborepo
- TypeScript(strict、`tsconfig.base.json` を継承)
- Next.js 16 App Router(RSC 既定)/ React 19 / Tailwind v4 / shadcn(`packages/ui` に集約)
- Hono + zod(`@hono/zod-openapi` で OpenAPI 生成・RPC で型共有: クライアントは `packages/shared`、ルータ型は `@jcredit/api/app`)。API ドキュメントは **Scalar**(`http://localhost:8787/docs`、spec は `/openapi.json`)。Swagger UI は使わない
- Drizzle ORM(Postgres 17)
- Biome(format + lint)/ Vitest(unit)/ Playwright(E2E テスト専用)

## Commands
- `pnpm dev`            全アプリ起動(重い。通常は `pnpm --filter @jcredit/<app> dev` で必要なものだけ)
- `pnpm check`          Biome format + lint
- `pnpm --filter @jcredit/<pkg> typecheck`  変更したパッケージだけ tsc(`pnpm typecheck` 全体実行は PR 直前のみ — tsc は 1 本 3〜4GB 使う)
- `pnpm --filter @jcredit/<pkg> test`       Vitest
- `pnpm test:e2e`       Playwright
- `pnpm db:generate --name <意味名>` / `pnpm db:migrate` / `pnpm db:push`
- `pnpm db:docs`         DB 設計書(`docs/design/detailed/db/<cluster>.md`)の生成ブロックを schema から書き換える(`--check` は CI 用)
- `node scripts/figma/frames.mjs <get_metadata の結果>`  Figma のページのセクションと画面フレームを一覧にする(`--grep` / `--url`)。画面設計でフレームを漏れなく拾うため
- `node scripts/screenshots/cli.mjs <cmd>`  PR スクリーンショット・ハーネス(`plan` / `baseline start|stop` / `add` / `status` / `upload` / `check`)
- `pnpm project:setup`  GitHub Project のフィールド作成(冪等。定義は `docs/project-board.md`)
- `docker compose up -d`  ローカル Postgres

## Conventions
- **ブランチ**: `main`(本番)← `staging`(ステージング)← `develop`(開発)。作業ブランチは `develop` から切り、**PR は `develop` 向け**(大きな変更を分ける stacked PR だけ open な PR を持つ作業ブランチを base にできる)。`staging` / `main` へは promotion PR(develop→staging / staging→main)のみ。運用設計は長命の `operations` ブランチで `docs/operations/` の中だけを変える。詳細は [docs/branching.md](docs/branching.md)
- **PR / Issue 本文**: PR は `.github/PULL_REQUEST_TEMPLATE.md` の 5 セクション(`Summary` / `変更点` / `レビュー観点` / `Screenshots` / `動作確認`)。各セクションに分量の上限がある(**本文を書き足さず diff と設計書に任せる**)。コミットは日本語で「何をしたか」を 50 文字以内・prefix なし(type は PR タイトルで付ける)。Issue は `.github/ISSUE_TEMPLATE/` のフォーム。ラベルは `type:` を必ず 1 つ + `area:` を 0 個以上(定義は `.github/labels.yml`。CI が同期するので手で作らない)。詳細は [docs/pr-and-issues.md](docs/pr-and-issues.md)
- **PR スクリーンショット**: `apps/*/app/**` または `packages/ui/**` を変更した PR は、該当画面の **変更前 / 変更後** のスクリーンショットを PR 本文 `## Screenshots` に必ず載せる。**撮影は Claude in Chrome で行う(Playwright・ヘッドレス不可)**。デスクトップ幅のみ(スマホ幅は撮らない)。手順は `/pr-screenshots`、検証は `.claude/hooks/pr-guard.sh` と CI(`pr-screenshots.yml`)
- API は **Hono + zod-openapi**(`createRoute` + `openApiApp()`。`new OpenAPIHono()` 直書き禁止 — テストが弾く)。zod schema は `apps/api/src/schemas/<lane>/`、RPC 型は `AdminRouter` / `PartnerRouter` / `MemberRouter` を Web が `@jcredit/api/app` から **type import** する(`@jcredit/api` は Web の devDependencies。`packages/shared` は `apps/*` に依存しない — ADR-0005。`packages/shared/src/__tests__/no-app-dependency.test.ts` と各 Web の `lib/lane-router.test.ts` が弾く)。全エンドポイントが `/openapi.json` → Scalar `/docs` に載る
- API は **レーンごとに routes / services / repositories / schemas を完全分離**。他レーンのファイルを import しない(処理が同じでも複製する)。共有できるのは技術基盤(`env.ts` / `lib/*` / `middleware/*`)のみ。`apps/api/src/__tests__/lane-isolation.test.ts` が機械的に弾く
- 層の向きは `routes → services → repositories`。route に DB クエリを直書きしない
- 技術基盤(`env.ts` / `lib/*` / `middleware/*`)は**ドメインを知らない**: レーン層を import しない・`@jcredit/db` のテーブル定義を読まない(同テストが弾く — ADR-0006)。レーン間で共通化したい業務ロジックは `lib/` に逃がさず `services/<lane>/` に複製する
- Web の API 呼び出しは **サーバーサイド(RSC / Server Action)経由のみ**(`lib/api.ts`、`server-only` + `INTERNAL_API_URL`)。ブラウザから API を直接 fetch しない。CORS / `NEXT_PUBLIC_API_URL` を追加しない
- UI は **`packages/ui` の shadcn を必ず先に確認**してから作る。shadcn のファイル名は kebab-case(CLI 標準)
- コンポーネントは `_components/<Name>.client.tsx` / `<Name>.tsx`(**PascalCase**)、ロジックは `_hooks/useXxx.ts`(**camelCase**)。Biome が強制
- DB スキーマ変更は **`pnpm db:generate --name <snake_case>`**(手書き禁止・`--name` 省略禁止)
- import 順: 外部 → 内部(`@jcredit/*`)→ 相対
- エラーは Result 型ではなく **throw + try/catch**(Hono の onError で統一捕捉)
- 日時: DB `timestamptz`、API は UTC ISO(`Z`)、表示は `Asia/Tokyo` 固定
- 環境変数: API は `src/env.ts`(zod)、Web は `env.ts`(T3 env)経由でのみ参照
- コードを変更したら対応する設計書(`docs/design/`)を同じ PR で更新。設計判断は `docs/design/adr/`
- コメントは `docs/code-comments.md` に従う。書くのは **既定値の根拠 / マジックナンバーの根拠 / 落とし穴 / 「書かれていないコード」の理由 / `// TODO:`** など同ファイルの W-n に限る。自明な説明は書かない(方針は ADR-0003)

## Don'ts
- `main` / `staging` / `develop` への直 push 禁止(常に PR 経由)
- `.env` をコミットしない
- `pnpm publish` を実行しない
- migration ファイルを手で編集しない
- `any` を入れない(やむを得ない場合は `// FIXME(any):` コメント)
- コメントに **PR / Issue 番号・日付・変更履歴・作業ログ**を書かない。コメントアウトされたコードを残さない(`.claude/hooks/comment-guard.sh` が弾く。参照してよい番号は ADR のみ)
- Web アプリ同士のコードを import しない
- **PR スクリーンショットを Playwright で撮らない**(Claude in Chrome のみ)
- PR 本文にテンプレートに無いセクションを足さない。`## Screenshots` を本文の最後のセクションにしない(後ろに `## 動作確認` を置く)
- `pnpm typecheck` / `pnpm build` の全体実行を作業途中で回さない(メモリ)

## Where to find things
- 設計書: `docs/design/`(`basic/` 基本設計 / `detailed/` 詳細設計 / `adr/` 設計判断)
- 運用設計・業務マニュアル: `docs/operations/`(入口は `README.md`。作業は `/start-operations`)
- コメント・文書の規約: `docs/code-comments.md`
- PR / Issue / ラベルの運用: `docs/pr-and-issues.md`(テンプレートは `.github/`)
- Project(機能 / Phase / 工程 / Sprint / Storypoint)の運用: `docs/project-board.md`(セットアップは `scripts/project/setup.mjs`)
- 共通型・enum: `packages/shared/src/`
- DB スキーマ: `packages/db/schema/`
- API ルート: `apps/api/src/routes/<lane>/`(業務ロジック `services/<lane>/`、永続化 `repositories/<lane>/`、zod `schemas/<lane>/`)
- Web ページ: `apps/<app>/app/`
- UI 部品: `packages/ui/src/`
- 画面詳細設計の書き方の手順: `.claude/skills/add-screen-design/`(1 機能 1 ディレクトリ・1 画面 1 ファイル。見本は `docs/design/detailed/member-portal/signup/`)
- PR スクリーンショット: `scripts/screenshots/cli.mjs` / `.claude/skills/pr-screenshots/`
