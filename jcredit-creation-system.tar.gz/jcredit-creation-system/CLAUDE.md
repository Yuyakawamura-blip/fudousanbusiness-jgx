@AGENTS.md

# J-Credit Creation System — Claude Code 用追記

ルートの規約は @AGENTS.md を参照。以下は Claude Code 固有の補足。

## このプロジェクトでの作業フロー

1. 作業は **`develop` から切った feature ブランチ**で行う(`git switch -c feat/xxx develop`)。`main` / `staging` / `develop` 上では編集しない。stacked PR の上のブランチは親ブランチから切る(`docs/branching.md`)
2. タスクを受けたらまず `PLAN.md` を更新する(チェックボックス形式)
3. 大きなタスクは **explorer サブエージェント**で先に調査
4. 実装中は **format-on-write フック**が Biome で自動整形する
5. 品質ゲート(Biome / typecheck / Vitest)は **`/create-pr`** と CI で回す。完了前の Stop フックはコメント規約の検査(`comment-guard.sh`)だけ
6. PR は **`/create-pr`** で作る。画面(`apps/*/app/**` / `packages/ui/**`)を変更していたら **`/pr-screenshots`** で
   変更前後のスクリーンショットを **Claude in Chrome** で撮り、PR 本文に載せる。**pr-guard フックが PR 作成をブロック**する条件:
   base が develop 以外(promotion / stacked 以外)/ 画面変更があるのに `## Screenshots` に Before / After が揃っていない
7. セッション終了時に `PROGRESS.md` の末尾に「次回最初に読むファイル」を追記する

## Skill 一覧
- `/create-pr` — 品質ゲート → スクリーンショット → develop(stacked なら親ブランチ)への PR 作成
- `/pr-screenshots` — Claude in Chrome で変更前後のスクリーンショット → GitHub Release → PR 本文セクション生成
- `/add-page` — Next.js ページ追加
- `/add-api-route` — Hono エンドポイント追加(レーン内完結)
- `/add-db-migration` — Drizzle スキーマ変更
- `/add-screen-design` — 画面詳細設計を Issue から書く(基本設計・Figma(リンク + webp)の突き合わせ → テンプレート(画面項目定義は DB の項目を正にし、DB に無い項目は別 PR で申請)→ 報告)
- `/start-operations` — 運用設計・業務マニュアルの作業を始める(`operations` に最新の develop を取り込む → 必読 → `docs/operations/` の中だけ書く)

## サブエージェント
- `explorer`(Haiku)— 読み取り専用の調査
- `code-reviewer`(Sonnet)— diff レビュー
- `test-writer`(Sonnet)— テスト追加
- `screenshot-reviewer` — 撮影した before / after 画像の目視レビュー

## このマシンでの注意(M1 / 16GB)
- `pnpm typecheck` の全体実行は PR 直前のみ。作業中は `pnpm --filter @jcredit/<pkg> typecheck`
- dev サーバは必要なアプリだけ起動する。スクリーンショットの baseline サーバは 1 アプリずつ順に起動する

## IMPORTANT
- DB schema を直接書かず、必ず `pnpm db:generate --name <意味名>` を使う
- Web を触る時は **どのアプリか**(admin-console=運営者 / partner-console=創出PT / member-portal=会員)を先に確認。**App Router(RSC 既定)**
- shadcn コンポーネントを作る前に **必ず `packages/ui/src/` を見る**
- **PR スクリーンショットは Claude in Chrome で撮る。Playwright では撮らない**
