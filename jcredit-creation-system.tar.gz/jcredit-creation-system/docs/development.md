# 開発環境

## 必要なもの
- Node.js 24(`.node-version`)/ pnpm 11(`packageManager`)
- Docker(ローカル Postgres)
- GitHub CLI `gh`(PR 作成・スクリーンショットの upload に使う)
- Claude Code + Claude in Chrome 拡張(PR スクリーンショット撮影に使う)

## 初回
```bash
pnpm install
cp .env.example .env
docker compose up -d
```

## 日常
```bash
pnpm --filter @jcredit/api dev              # API      http://localhost:8787(docs: /docs)
pnpm --filter @jcredit/member-portal dev    # 会員     http://localhost:3000
pnpm --filter @jcredit/admin-console dev    # 運営者   http://localhost:3001
pnpm --filter @jcredit/partner-console dev  # 創出PT   http://localhost:3002
```
`pnpm dev` は全部まとめて起動する(メモリを食うので通常は個別起動)。

## 品質ゲート
```bash
pnpm check                                  # Biome format + lint
pnpm --filter @jcredit/<pkg> typecheck      # 変更したパッケージだけ
pnpm --filter @jcredit/<pkg> test           # Vitest
pnpm --filter @jcredit/<app> test:e2e       # Playwright(初回は test:e2e:install)
```

## DB
```bash
pnpm db:generate --name <snake_case_name>   # schema 変更 → migration 生成
pnpm db:migrate                             # 適用
```
接続先はルート `.env` の `DB_*`(既定はローカル docker compose)。`DATABASE_URL` は使わない。

## PR
0. 初回のみ `git config commit.template .gitmessage`(コミット規約は docs/pr-and-issues.md)
1. `develop` から feature ブランチを切る
2. 画面を変更したら `/pr-screenshots`(Claude Code)で変更前後のスクリーンショットを撮る
3. `/create-pr` → base は `develop`(stacked PR は親ブランチ)

### スクリーンショット・ハーネス(`scripts/screenshots/cli.mjs`)
| コマンド | 内容 |
| --- | --- |
| `plan` | 変更ファイルから撮影対象ルートを導出(`.screenshots/<branch>/plan.json`) |
| `baseline start` / `stop` | `develop` 断面の worktree を作り、対象アプリを **ポート + 1000** で起動 / 停止 |
| `add --phase before\|after --target <id> <image>` | Claude in Chrome で保存した画像(jpg / png)を取り込む |
| `status` | before / after の揃い具合 |
| `upload` | GitHub Release `screenshots-bucket` へ upload し、PR 本文の `## Screenshots` を生成 |
| `check` | PR 本文の検証(フック / CI が使う) |

動的ルート(`/projects/[id]` 等)は `apps/<app>/screenshots.config.json` の `routeParams` にサンプル URL を登録する。
