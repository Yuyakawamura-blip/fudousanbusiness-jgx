# GitHub Project(ボード)の運用

Issue の粒度・見積・スプリントは org の GitHub Project「J-Credit 創出システム」で管理する。
Issue そのもの(テンプレート・ラベル)の規約は [pr-and-issues.md](pr-and-issues.md)。
このファイルは **Project 側の定義**(フィールド / スプリント)と、その値の付け方。

フィールドの正は [scripts/project/setup.mjs](../scripts/project/setup.mjs) の `BOARD`。
定義を変えるときはそこを直して PR を出し、マージ後に `pnpm project:setup` を再実行する
(既存フィールドは変更しない。選択肢の追加・変更は Project の Settings → Fields で行う)。

## 単位

| 単位 | 実体 | Issue Type | テンプレート |
| --- | --- | --- | --- |
| **Story**(ユーザーストーリー) | Issue | `Feature` | 機能追加・改善 |
| **Task**(技術タスク) | Issue | `Task` | 技術タスク |
| **Bug** | Issue | `Bug` | バグ報告 |

- **Epic = Phase**(Phase1 / Phase2 / Phase3)。Epic を親 Issue にはせず、**Phase フィールド**で持つ(Epics ビューで見る)。
  機能・工程も同じく Project のフィールド(**機能 / 工程**)で持ち、ビューのグループ化で見る。親 Issue にすると、まとめるだけの Issue が
  機能 × 工程の数だけ増え、閉じ忘れや付け替えの手間が出る
- 1 つの作業を分割したときだけ sub-issue を使ってよい(親子は作業の分解であって、分類には使わない)
- Story は「`<誰>` として `<何>` がしたい。なぜなら `<理由>`」の形で書く(テンプレートの「解決したいこと」)。
  Size が XL になる Story は分割する
- Issue Type はテンプレートが自動で付ける(`type:` キー)。`gh issue create` から作るときは `--type` を付ける
- `type:` ラベルはこれまでどおり必ず 1 つ。Issue Type と二重に見えるが、ラベルは PR タイトルの語彙と
  `labels-sync.yml` に、Issue Type は Project のフィルタ / グルーピングに使う(役割が違う)

## フィールド

| フィールド | 型 | 値 | いつ付けるか |
| --- | --- | --- | --- |
| Status | 組み込み | Todo / In Progress / Done | 自動(workflow) |
| **機能** | Single select | 全体 / 会員マイページ / 創出PTマイページ / 運営者コンソール / API / DB / dev環境構築 / stg環境構築 / 本番環境構築 / テスト計画 / 脆弱性診断準備 / 総合テスト / UAT | Issue を作ったとき。全体に関わる作業は空でよい |
| **Phase** | Single select | Phase1 / Phase2 / Phase3 | Issue を作ったとき |
| **工程** | Single select | 基本設計 / 画面設計 / 詳細設計 / 開発 / フロントエンド開発 / バックエンド開発 / 内部結合テスト / テスト | Issue を作ったとき |
| **Size** | Single select | S / M / L / XL | Backlog 整理時(粗い当たり) |
| **Sprint** | Iteration | 月曜始まり **2 週間**。`Sprint 1`, `Sprint 2`, … | スプリント計画時 |
| **Storypoint** | Number | **1 / 2 / 3 / 5 / 8 / 13 のみ**(フィボナッチ) | スプリント計画時 |
| Priority | Single select | High / Medium / Low | Backlog 整理時 |
| **Start** / **end** | Date | 作業の開始予定日 / 終了予定日 | 段取りを決めたとき。Roadmap 系のビューの棒になる |

- 機能・Phase・工程は **Status を使わない**。Status は Board の列と「close → Done」の自動化に使っている
- 機能の選択肢は `docs/design/basic/scope.md` の機能一覧が決まったら見直す(工程と意味がかぶる名前にしない。
  例: 機能「API設計」は 機能「API」+ 工程「基本設計」に分ける)

### Size(T シャツ)と Storypoint の使い分け

同じ Issue に両方付くが、**タイミングが違う**。Size は Backlog に積む時点の当たり(見積会を経ていない)、
Storypoint はスプリントに入れる時点の合意値。Storypoint が付いたら Size は見ない。

| Size | 目安(担当者 1 人の作業量。待ち時間は含めない) |
| --- | --- |
| S | 半日以内 |
| M | 1〜2 日 |
| L | 3〜5 日 |
| XL | 6 日以上。分割する |

- Storypoint は相対値。基準は「**3 = 半日〜1 日で終わる、迷う要素が無い Story**」。時間ではなく不確実さと量で見る
- **13 は「分割してから着手」の印**。13 のまま Sprint に入れない
- Number 型なのでフィボナッチ以外も入力できてしまう。入っていたら見積の場で直す(single select にしないのは
  Insights と group-by の合計を使うため。single select は合計できない)
- 子 Issue を持つ親には Storypoint を付けない(子の合計と二重になる)

### Sprint

- Iteration フィールド。**Milestone は Sprint に使わない**(Milestone はリリース `v1.0` などの単位。
  開始日を持たず Project 横断もできない)
- スプリント計画で Story / Task / Bug に Sprint と Storypoint を付ける。付いていない Issue は Backlog
- 終わらなかった Issue は次の Sprint に**手で**動かす(自動で繰り越さない。繰り越しの多さを見るため)

### Start / end(予定日)

- 日単位の予定は **Start / end の 1 組だけ**で持つ(予定用の日付フィールドを別に作らない)
- 機能ごとの予定(先方と合意したスケジュールの帯)はフィールドに持てない(選択肢は日付を持たない)。
  進捗レポートは機能ごとに「Start の最小 〜 end の最大」を予定として出す。合意した帯とずれていないかは定例で見る
- 予定日は人が置く見込み値。**スプリント計画のたびに見直す**。ずれたこと自体を定例で報告する

## ビュー

`pnpm project:setup` はビューを作れない(API が無い)。UI(または Claude in Chrome)で作る。
機能・工程は table / board / roadmap を揃える(既存のビューを Duplicate して group by を変えると早い)。
Table / Roadmap で子 Issue を機能ごとに並べるときは **Show hierarchy を Off** にする(On だと親の下に畳まれる):

| ビュー | レイアウト | 設定 |
| --- | --- | --- |
| Board | Board | column: Status。filter: `sprint:@current sprint:@next` |
| Sprint_table | Table | group by: Sprint。field sum: Storypoint |
| Epics | Table | group by: Phase(Epic = Phase) |
| タスク予定 | Roadmap | 全体のタスクを Start → end で並べる |
| 機能_table | Table | group by: 機能。field sum: Storypoint |
| 機能_board | Board | column: Status。swimlanes: 機能 |
| 機能_roadmap | Roadmap | group by: 機能。dates: Start → end。markers: Sprint / Milestone |
| 工程_table | Table | group by: 工程 |
| 工程_board | Board | column: Status。swimlanes: 工程。slice by: 機能(左の一覧で機能を絞り込む) |
| 工程_roadmap | Roadmap | group by: 工程 |

## セットアップ

```bash
gh auth refresh -h github.com -s project   # 初回のみ(project スコープ)
pnpm project:setup --dry-run               # 何を作るか確認
pnpm project:setup                          # Project / フィールド / リポジトリ紐付け
```

- `gh` は **作業用アカウント**(org のメンバー)で実行する
- スクリプトが最後に表示する手動ステップ(組み込み workflow / ビュー)を済ませて完了:
  - Auto-add to project(このリポジトリの open Issue を自動で載せる)
  - Item closed → Done / Pull request merged → Done
  - Auto-archive(closed かつ 2 週間更新なし)
- Sprint の開始日は既定で「次の月曜」。ずらすなら `--sprint-start YYYY-MM-DD`

## 進捗レポート(先方向け)

定例で先方に見せる 1 枚の HTML を、この Project と GitHub から作る。実装は [scripts/progress/build.mjs](../scripts/progress/build.mjs)。

```bash
gh auth switch --user <作業用アカウント>
echo 'PROGRESS_PROJECT_NUMBER=7' >> .env   # 初回のみ。他の項目は .env.example
pnpm progress                 # .progress/progress-YYYY-MM-DD.html を出力(パスを表示)
```

対象はルートの `.env` / `.env.local`(またはシェルの環境変数)で切り替える。fork や別 Project で使い回すときもコードは触らない。

| 変数 | 既定 | 用途 |
| --- | --- | --- |
| `PROGRESS_PROJECT_NUMBER` | なし(**必須**) | 課題管理表の Project 番号。既定値を持たないのは、fork 先で設定し忘れたとき元の Project の数字を出さないため |
| `PROGRESS_PROJECT_OWNER` | リポジトリの owner | Project の所有者(org / ユーザー) |
| `PROGRESS_REPO` | 今いる git リポジトリ | Project の所有者の既定を決めるリポジトリ(`owner/name`) |
| `PROGRESS_TITLE` | J-クレジット創出システム | 見出しのシステム名 |

| 欄 | 取得元 |
| --- | --- |
| マイルストーン(現在地) | 並び(全体 / 会員マイページ / 創出PTマイページ / 運営者コンソール / API / DB / 環境構築 / テスト / 脆弱性診断 / リリースの枠と、その中の帯)と ▼(節目の名前と日付。図には「▼名前 M月D日」と、その日の縦の破線で出す)、図を最低どこまで描くか(`until`)は [scripts/progress/layout.json](../scripts/progress/layout.json) で固定。▼ は画面でドラッグして日付を動かせ、現在のマイルストーンの日付・残り日数・数字が連動する(このブラウザにだけ保存し、layout.json には反映しない)。▼ は GitHub の Milestone と照合しない(先方と合意した節目を、リポジトリの運用と切り離して持つ)。帯の日付は、機能が一致し(`processes` があれば工程も一致する)課題の Start の最小 〜 end の最大。layout.json の帯に `start` / `end` を書いたときはそちらを優先する(先方と合意した予定。課題を作らない脆弱性診断もこれで置き、件数は出さない)。開始予定が生成した日より後の帯に入る課題は、完了していても対応中として出す(予定より先に進んでいる分は先方に見せない。全体・現在のマイルストーンの数字、帯、課題一覧すべて)。日付のある課題が無い帯は枠の名前の下に「日付未設定」と出す。段は期間が重なるときだけ分け、帯に入らない名前は重ならない段に出す。今日に赤の縦線を引き、現在のマイルストーンを図の上に出す(工程ごとの進行中・予定超過は帯の色で読む)。帯の色は完了(全件完了)/ 進行中 / 予定超過(end を過ぎて残りあり)/ 予定。帯の左から完了率の長さだけ緑に塗る(画面で状態を変えると塗りも変わる) |
| 進捗サマリ(全体の完了率 / 現在のマイルストーンの完了率) | 全体は Project の Status。Done または closed を完了と数える。現在のマイルストーンは、課題の入った ▼ のうち、期日が今日以降か、期日を過ぎて課題が残っている最初のもの。その ▼ の完了率は、前の ▼ の翌日からその ▼ までに end が来る帯の課題の 完了 / 全件 |
| 帯ごとの予定(機能 / 工程 / 開始予定 / 完了予定 / 完了率) | マイルストーン図の帯と同じ並び(layout.json)の 1 行 1 帯。開始予定・完了予定の初期値は帯の Start〜end。日付はクリックで、またはマイルストーン図の帯のドラッグ(左右の端で伸縮、中で移動。1 日単位)で変えられ、どちらで変えても表の日付とマイルストーン図の帯の位置・段・色、図の上の進行中 / 予定超過、現在のマイルストーンの数字が連動する(このブラウザにだけ保存し、GitHub には反映しない)。完了予定を過ぎて終わっていない帯に「予定超過」を付ける |
| 課題一覧(親子課題) | 工程ごとの開閉式(上から 基本設計 / 詳細設計 / フロントエンド開発 / バックエンド開発 / テスト / その他。詳細設計は工程 画面設計を含み、バックエンド開発は工程 開発(API・DB の開発)を含む。工程が空の課題は機能で振り分ける。子課題は親と同じまとまり)。最初は終わっていない最初の工程だけ開く。工程の行には完了 / 全件・対応中の件数・予定期間(その工程の課題の Start の最小 〜 end の最大)・完了率を出す。印刷(先方に送る PDF)では課題を並べず工程の行だけを出し、end を生成した日より前に過ぎて残っている課題があるときだけ、その工程の下に「予定超過: #番号 課題名」を出す。列は No. / 課題 / 機能 / 状態 / 担当。中身は Project の Issue と sub-issue(孫以下も字下げして出す)。Project に載っていない子課題も親から補って出す(その子の先はたどらない)。状態(未着手 / 対応中 / 完了)は画面上のプルダウンで変えられる。変えた状態はブラウザの localStorage にだけ残り、GitHub には反映しない。変えた状態は、進捗サマリ(全体・現在のマイルストーン・帯ごとの予定)・工程ごとの件数・マイルストーン図の帯の件数と色・議題の状態にその場で反映する(最初の表示は GitHub の状態)。どの ▼ を現在のマイルストーンにするかは GitHub の状態で決めたまま |
| 議題 | 打ち合わせで取り上げる課題。課題一覧の課題を番号かタイトルで探して足す(課題に無い議題はタイトルを書いて足す)。1 件ごとに 議論したい内容 / 確定事項 を画面上で直接入力し、何件でも後から足せる。課題の議題には番号のリンクと、その上に課題の内容(Issue の本文。未記入欄は出さない。開閉でき、開閉もブラウザに残る)を出す。ブラウザの localStorage に日付ごとに保存される(共有はされない)。直近の対応内容(マージ済み PR)は出さない |
| 決定事項 / 宿題 / メモ | 右カラムに固定(スクロールしても見える。幅 1100px 未満と印刷では本文の下)。右上のボタンで 3 つまとめてしまえる(本文が全幅になる。しまったかどうかはブラウザに残り、印刷では常に出す)。画面上で直接入力。ブラウザの localStorage に日付ごとに保存される(共有はされない) |

- 対応しない理由(not planned / duplicate)で閉じた Issue は報告に出さない(完了と数えると完了率が上がるため)。外した件数と番号は `pnpm progress` の実行時に表示する
- 機能が環境構築(dev / stg / 本番)の課題はインフラ側の作業なので、課題一覧・全体の完了率・マイルストーンの件数に入れない(子課題ごと外す)。図の環境構築の帯は layout.json の日付だけで置く
- 数えるのは **Project に載っている課題だけ**(全体の完了率も帯ごとの予定も同じ。課題一覧だけは Project に無い子課題も親から補って出す)
- 集計は**親子を同列に数える**(件数で数え、Storypoint は使わない)
- マイルストーン図に帯が出ないときは、課題の 機能・工程・Start / end を見る。帯と 機能・工程の対応は layout.json(例: アプリの「詳細設計」は工程 画面設計 + 詳細設計、DB の開発は DB構築の帯、テスト・脆弱性診断は工程を問わない)。layout.json に無い 機能 × 工程の課題(例: 機能 テスト計画)は図に出ない
- 見出しの「YYYY-MM-DD 時点」はクリックで日付を変えられる(打ち合わせの日に合わせる用。見出し・PDF のファイル名・今日の縦線と赤い週が動く。集計・帯の色・予定超過の判定は生成した日のまま)
- 画面で変えた状態・予定日・入力はブラウザにだけ残るので、ファイルを渡しても相手には出ない。渡すときは「この状態で保存」で、今の状態を入れた HTML を書き出して渡す(開いた人にはその状態が最初に出る。GitHub の状態とずれた数字になるので、本当の状態は Project で直して作り直す)
- 「PDF 出力」はブラウザの印刷ダイアログを開く。送信先で「PDF に保存」を選ぶ(A4・ボタンや空の宿題行は印刷しない。Cmd+P でも同じ)
- 入力内容(議題・決定事項・宿題・メモ)はそのブラウザにしか残らない。議事録として残すのは PDF
- `--data <json>` で保存済みデータから描画、`--save-data <json>` で取得結果を保存できる(取得元に繋がらないときの確認用)
