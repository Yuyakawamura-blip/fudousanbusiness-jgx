# PR / Issue / ラベルの運用

PR 本文は基本 AI が書き、人がレビューする。**レビュアーが読む時間を最小にする**のが目的で、
網羅性は目的ではない。diff・`git log`・`docs/design/` にあることを本文へ転記しない。

## PR

テンプレート: [.github/PULL_REQUEST_TEMPLATE.md](../.github/PULL_REQUEST_TEMPLATE.md)

| セクション | 書くこと | 分量 |
| --- | --- | --- |
| `## Summary` | 何を・なぜ。関連 Issue は `Closes #123`。stacked PR は 1 行目に `Stack: #10 → **#11** → #12`([docs/branching.md](branching.md)) | 2〜3行(Stack 行を除く) |
| `## 変更点` | レビュー順序を決められる粒度の箇条書き | 3〜7項目 |
| `## レビュー観点` | 判断が割れうる設計選択 / 確信が持てなかった箇所 / 意図的に見送ったこと | 1〜3行(無ければ「特になし」) |
| `## Screenshots` | `/pr-screenshots` が出力した表 | 画面変更時のみ・デスクトップ幅のみ |
| `## 動作確認` | 実際に実行したものだけ `[x]` | チェックリスト |

- タイトルは `<type>: <日本語の要約>`(`type` は下のラベルと同じ語彙。例: `feat: 会員申込 API を追加`)
- `## 変更点` がファイル名の羅列になったら粒度が細かすぎる。「なぜその変更が要るか」で束ねる
- `## レビュー観点` を「特になし」で埋め続ける PR ばかりになったら、AI 側の指示を疑う。
  ここが実質的にレビューの入口になる
- 7項目に収まらない PR は分割を検討する(レーンやアプリを跨いだ変更は特に)
- `## Screenshots` を本文の最後のセクションにしない。後ろに `## 動作確認` を必ず置く
  (`scripts/screenshots/cli.mjs check` の本文解析が次の `##` を終端に使うため)

PR の作成者は CI(`.github/workflows/pr-assign.yml`)で自動的に Assignee になる。作成時に Assignee を指定した PR と bot の PR はそのまま。

画面変更の有無・Before / After の検査は `.claude/hooks/pr-guard.sh` と
`.github/workflows/pr-screenshots.yml` が機械的に行う。撮影は Claude in Chrome のみ(Playwright 不可)。

## コミット

- 1 行目は **日本語で「何をしたか」を 50 文字以内**、prefix なし(`会員申込 API を追加`)。`feat:` 等の type は PR タイトルで付ける
  (squash merge で `develop` に残るのは PR タイトルなので、そちらが正)
- 本文は任意。書くなら「なぜ」だけ。何を変えたかは diff にある。Issue / PR 番号・日付・作業ログは書かない
- 手でコミットする人は `git config commit.template .gitmessage` を一度設定すると、エディタにこの規約が出る
  (`git commit -m` や Claude Code が書くコミットには効かない。規約の正はこの節)

## Issue

テンプレート: [.github/ISSUE_TEMPLATE/](../.github/ISSUE_TEMPLATE/)

| テンプレート | 使うとき | 既定ラベル | Issue Type |
| --- | --- | --- | --- |
| バグ報告 | 動かない・想定と違う | `type: bug` | `Bug` |
| 機能追加・改善 | 新しい機能、既存機能の変更(ユーザーストーリー) | `type: feature` | `Feature` |
| 技術タスク | リファクタ / 基盤整備 / 依存更新 / ドキュメント | `type: chore` | `Task` |

機能 / Phase / 工程 / Sprint / Storypoint / Size / Start / end の付け方は [project-board.md](project-board.md)(まとめ用の親 Issue は作らない)。

- 技術タスクは種別を選んで作った後、`type: refactor` / `type: docs` へ付け替える
- **決定と理由は Issue に書かない**。それは `docs/design/adr/`(ADR にリンクする)
- 「関連」欄には ADR / 設計書 / 先行 Issue へのリンクだけを書く。理由の本文は書かない
- `gh issue create` はテンプレートを通らない。CLI から作るときは上の項目を本文に自分で並べ、`--type` で Issue Type を付ける

## ラベル

定義は [.github/labels.yml](../.github/labels.yml) が正。追加・変更・削除はこのファイルを直して PR を出す。
PR では `labels-sync.yml` が dry-run で差分を出し、`develop` にマージされると GitHub 側へ同期する
(**ファイルに無いラベルは削除される**)。`gh label create` で手動作成しない。

- `type:` を **必ず 1 つ**。Issue はテンプレートが自動で付ける。PR は作成時に付ける
- `area:` は **0 個以上**。変更したアプリ / パッケージ。跨ぐなら複数
- `breaking` は互換性を壊すとき。移行手順を PR 本文に書く
- `promotion` は develop→staging / staging→main の PR(通常の PR には付けない)
- `needs-screenshots` は人がレビュー中に貼り忘れを指摘するとき。ガードが弾く分には要らない
- `stacked` は base が作業ブランチの PR。CI が付け外しする(手で付けない)。付いている間はマージしない
- `blocked` は他の PR / 判断 / 外部要因待ち。何を待つかをコメントに書き、解消したら外す
