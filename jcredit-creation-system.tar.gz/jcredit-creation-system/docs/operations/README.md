# 運用設計・業務マニュアル

運用設計書と業務マニュアルを Markdown で置く。書き手は運用設計の担当で、開発の設計書(`docs/design/`)とは別に管理する。
システムの仕様は開発の設計書が正。ここでは「その仕様の上で、誰が・いつ・どう動くか」を書く。

## 必読(作業を始める前に)

1. このファイル
2. 書く章に対応する開発の設計書(下の「参照する開発の設計書」)
3. 用語: [domain.md](../design/basic/domain.md)

## 守ること

- **変更してよいのは `docs/operations/` の中だけ。** アプリのコード・開発の設計書・設定ファイルは変えない。
  `operations` ブランチで外を変えると CI(`Operations Scope`)が落ちる
- 開発の設計書と食い違いを見つけたら、ここで辻褄を合わせたり開発の設計書を直したりせず、Issue(ラベル `area: operations`)で開発へ渡す。
  返事を待つ間は該当の章の `## Open questions` に書いておく
- 開発の設計書の内容は書き写さず、相対リンクで参照する(書き写すと仕様が変わったときに古くなる)
- 用語は [domain.md](../design/basic/domain.md) に揃える。無い用語を作るときは Open questions に書く
- 要件定義資料の ID(機能要件や画面の番号)は書かない。言葉で書く(Claude Code のフックが弾く)
- 参考資料(Word・Excel・PowerPoint)はコミットしない。画像は `images/` に置く
- 変更履歴・日付・作業ログを本文に書かない(履歴は git が持つ)

## 構成

| ディレクトリ | 内容 | 単位 |
| --- | --- | --- |
| `design/` | 運用設計書 | 5 区分を 1 区分 1 ファイル。業務が多い区分(`02-business/`)はディレクトリにして業務ごとに 1 ファイル |
| `manual/` | 業務マニュアル | 6 編を 1 編 1 ディレクトリ。入口は各ディレクトリの `README.md`、手順ごとにファイルを足す |
| `images/` | 図・画面の切り抜き | 使う文書と同じ名前のサブディレクトリに置く |

ファイル名は英語の kebab-case(例: `member-signup.md`)、本文は日本語。

| 運用設計書 | 内容 |
| --- | --- |
| [01-policy.md](design/01-policy.md) | 運用方針・体制(範囲、役割分担、時間、対応水準) |
| [02-business/](design/02-business/README.md) | 通常業務(登録・審査・年間業務、権限・データ管理) |
| [03-inquiry-exceptions.md](design/03-inquiry-exceptions.md) | 問い合わせ・例外対応(受付・振分け・記録・引継ぎ、判断保留) |
| [04-maintenance-incident.md](design/04-maintenance-incident.md) | システム保守・障害対応(監視、障害レベル、連絡・対応フロー、復旧) |
| [05-go-live.md](design/05-go-live.md) | 運用開始準備(マニュアル、教育・引継ぎ、机上確認) |

| 業務マニュアル | 読む人 |
| --- | --- |
| [common/](manual/common/README.md) | 全員 |
| [creator-pt/](manual/creator-pt/README.md) | 創出PT |
| [call-center/](manual/call-center/README.md) | コールセンター |
| [operator/](manual/operator/README.md) | 運営者 |
| [exceptions/](manual/exceptions/README.md) | 全員(障害・トラブル時) |
| [faq/](manual/faq/README.md) | 全員 |

## 参照する開発の設計書

| 書くもの | 読む開発の設計書 |
| --- | --- |
| 対象範囲・システムで扱わない業務 | [scope.md](../design/basic/scope.md)(機能一覧・作らない機能) |
| 役割分担・権限 | [auth.md](../design/basic/auth.md)、[api-usecases/](../design/basic/api-usecases/)(利用者区分ごとにできること) |
| 通常業務の手順・マニュアルの画面操作 | [screen-flow/](../design/basic/screen-flow/)(アプリごとの画面と遷移)、`../design/detailed/<アプリ>/<機能>/`(画面ごとの項目・決まり) |
| 状態(審査中・差戻し 等)と通知 | [domain.md](../design/basic/domain.md)、[detailed/db/](../design/detailed/db/README.md)(状態遷移) |
| エラー時の利用者への見え方 | [error-handling.md](../design/basic/error-handling.md) |
| 障害・監視・環境 | [architecture.md](../design/basic/architecture.md) |

アプリは 3 つ: 運営者は `admin-console`、創出PT は `partner-console`、会員は `member-portal`。

## 予定

予定(工程・主担当・期間)は [schedule.json](schedule.json) に書く。GitHub の Milestone や Project には載せない。
`pnpm progress:operations` で、週単位のガントチャートを `.progress/operations-YYYY-MM-DD.html` に出す(今日に赤の縦線、開発側の節目に破線)。

- 画面で帯をドラッグして移動、両端で伸び縮み(1 日単位)。節目は名前をドラッグして移動。下の表で日付・節目の名前を直接変えてもよい
- 動かした結果はそのブラウザにだけ残る。確定したら「schedule.json を書き出す」で落としたファイルで `docs/operations/schedule.json` を置き換えてコミットする。「元に戻す」で schedule.json の内容に戻る
- schedule.json を変えて作り直すと、ブラウザに残っていた古い変更は使わない
- 見出しの「YYYY/MM/DD 時点」の日付を押すと基準日を変えられ、赤線がその日に動く(作った日以外は「今日」と出さない)。基準日は schedule.json に書き出さず、別の日に作り直すとその日に戻る
- 描く範囲は予定の前後 2 週まで。それより外へ動かすときは schedule.json を直して作り直す

| 項目 | 内容 |
| --- | --- |
| `tasks` | 工程。`label` / `owner`(主担当)/ `kind`(色分け)/ `start` / `end`(どちらも含む) |
| `kinds` | 色分けの名前(`design` 設計・作成 / `verify` 検証・UAT反映 / `approve` 承認 / `prepare` 研修・稼働準備) |
| `milestones` | 開発側の節目(`title` / `date`)。開発の予定が動いたら合わせる |

## 進め方

ブランチは `operations` 1 本(運用は [branching.md](../branching.md) の「運用設計(`operations`)」)。Claude Code では `/start-operations` で始める。

1. 最新の develop を `operations` に取り込む(`/start-operations` が行う)
2. 書いて `operations` にコミット・push
3. 章の初稿・レビュー依頼などの区切りで `operations` → `develop` の PR を出す。開発チームが整合を見る
