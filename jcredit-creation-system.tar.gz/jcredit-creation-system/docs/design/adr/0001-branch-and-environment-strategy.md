# ADR-0001: ブランチ = 環境の 3 段構成(main / staging / develop)と develop 向け PR

- Status: Accepted
- Last updated: 2026-10-06

## Context
参考にした c-platform は `develop` / `staging` / `release` の 3 ブランチをそれぞれ dev / stg / prd 環境に対応させ、
デプロイ先をブランチ名から自動決定している。本リポジトリでも同じ「ブランチ = 環境」の考え方を採る。
ブランチ名は環境名(`dev` / `stg` / `prd`)と揃えず、一般的な `develop` / `staging` / `main` にする。
`dev` は `pnpm dev` や dev サーバと同じ綴りで検索に混ざり、`main` → prd の時点で環境名とは揃っていなかったため。

## Decision
1. ブランチは `main`(prd)/ `staging`(stg)/ `develop`(dev)の 3 本を常設する
2. 作業ブランチは `develop` から切り、**PR は `develop` 向け**に出す。例外は stacked PR(base が open な PR を持つ作業ブランチ)のみ。
   ツールは入れず、命名(`feat/<topic>-2`)・本文の `Stack:` 行・ラベル `stacked` の約束で運用する(docs/branching.md)
3. `staging` へは `develop` から、`main` へは `staging` からの promotion PR のみを許可する
4. これを Claude Code のフック(`.claude/hooks/pr-guard.sh`)と GitHub Actions(`pr-base-branch.yml`)、
   ブランチ保護 ruleset の 3 層で機械的に守る。stacked PR は「base に open な PR があること」で機械判定する(`gh pr list --head`)
5. GitHub のデフォルトブランチは `develop` にする(`gh pr create` / GitHub UI の既定 base が develop になる)

## Consequences
- 環境に何が乗っているかがブランチの HEAD で常に分かる
- promotion PR の diff がそのままリリースノートになる
- hotfix は上流に入れたあと下流へ戻す運用が必要(docs/branching.md)
- stacked PR は下から順にマージし、親がマージされたら `git rebase --onto` で載せ替える手間が要る。
  head ブランチの自動削除(リポジトリ設定)が base 付け替えの前提

## Open questions
- デプロイ基盤(c-platform は API=ECS Fargate、Web=Amplify)。本リポジトリでは未決。起動方法(手動実行・ブランチ = 環境・コミット指定)は ADR-0007 で決め、`deploy-*.yml` はデプロイ処理が空の状態で置いてある。決まり次第 `_deploy.yml` とこの ADR を更新する
