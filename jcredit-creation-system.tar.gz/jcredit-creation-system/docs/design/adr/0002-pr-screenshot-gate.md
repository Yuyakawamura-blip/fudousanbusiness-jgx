# ADR-0002: 画面変更 PR には Claude in Chrome で撮った変更前後スクリーンショットを必須にする

- Status: Accepted
- Last updated: 2026-09-10

## Context
Web 3 アプリ(admin-console / partner-console / member-portal)の画面変更は、コードレビューだけでは
見た目の崩れや意図しない差分を見落としやすい。レビュアーが PR 上で「変更前」と「変更後」を並べて
見られる状態を、人の注意力に頼らず**仕組みで**保証したい。

制約:
- モバイルアプリは無く Web のみ。スマホ幅のスクリーンショットは不要
- 撮影は開発者の Chrome を Claude Code が操作して行う(Claude in Chrome)。Playwright は E2E テスト専用とし、
  スクリーンショット撮影には使わない(実ブラウザ・実データで、開発者が見ているものと同じ画面を撮るため)
- 画像をリポジトリにコミットしない(肥大化を避ける)

## Decision
1. `apps/*/app/**` または `packages/ui/src/**` を変更した PR は、影響する各画面の **Before / After** 画像を
   PR 本文の `## Screenshots` 表(`| <app> \`<route>\` | ![](before) | ![](after) |`)に載せることを必須にする
2. 撮影対象は変更ファイルから機械的に導出する(`scripts/screenshots/cli.mjs plan`)。
   動的ルートのサンプル URL と追加ルートは各アプリの `screenshots.config.json` で宣言する
3. 「変更前」は base ブランチ(develop)との merge-base 断面を git worktree で起動して撮る(ポート + 1000)
4. 撮影は Claude in Chrome の `screenshot`(`save_to_disk`。保存形式は jpg)で行い、`cli.mjs add` で取り込む。デスクトップ幅 1440×900 のみ
5. 画像は GitHub Release `screenshots-bucket`(prerelease)のアセットとしてホストし、PR 本文から参照する
6. 検証は 2 層: Claude Code の PreToolUse フック(`pr-guard.sh`)が PR 作成コマンドをブロックし、
   GitHub Actions(`pr-screenshots.yml`)が本文の編集・追加 push ごとに再検証する
7. 例外(escape hatch)は設けない。コメントのみの変更でも画面ファイルに触れていれば撮る

## Consequences
- レビューが「見た目」を含めて PR 上で完結する
- 画面変更 PR は撮影ぶんの手間が増える(1 画面あたり数十秒 × before / after)
- `plan` の導出はヒューリスティック(`page.tsx` の親ディレクトリ = ルート)。共通レイアウトや `packages/ui` の変更は
  代表として `/` を撮り、他は `extraRoutes` で補う
- 認証付き画面が増えたら、ログイン済みタブでの撮影手順を `/pr-screenshots` に追記する

## Open questions
- 撮影対象が多い PR(共通コンポーネント差し替え等)の上限・分割方針
