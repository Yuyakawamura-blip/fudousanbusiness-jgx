# ADR-0007: デプロイは手動実行のワークフローで、ブランチ = 環境・コミット指定可

- Status: Accepted
- Last updated: 2026-10-02

## Context
デプロイ基盤は未決(ADR-0001 の Open questions)だが、デプロイの起動方法と「どの断面を出すか」の決め方は基盤に依らず決められる。
参考にした c-platform は `deploy-<app>.yml` を workflow_dispatch で手動実行し、実行ブランチから環境を決め、
`commit_id` 入力でブランチ内の過去コミットも出せる(切り戻し・検証)。
ただしブランチと SHA の検証ジョブを 3 ファイルに複製しており、変更時に全ファイルを揃える手間がある。

制約:
- デプロイ単位は 4 つ(`api` / `admin-console` / `partner-console` / `member-portal`)。Web アプリは別デプロイ(AGENTS.md)
- workflow_dispatch のワークフローは、ファイルがデフォルトブランチ(`develop`)に入るまで Actions 画面に出ない

## Decision
1. デプロイはアプリごとの `deploy-<app>.yml`(workflow_dispatch)から手動で起動する。push での自動デプロイはしない
2. デプロイ先の環境は実行時に選んだブランチで決める: `develop` → dev / `staging` → stg / `main` → prd。完全一致のみ受け付け、作業ブランチ・タグからは実行できない
3. `commit_id`(7〜40 桁の SHA、任意)で過去のコミットを出せる。選んだブランチの祖先に限る — 別ブランチのコミットを出すと「ブランチの HEAD = 環境の中身」(ADR-0001)が崩れるため
4. ブランチ・SHA の検証、同一アプリ・同一環境の直列化(`concurrency`、実行中は取り消さない)、Job Summary への記録(ブランチ・SHA・実行者)は
   再利用ワークフロー `.github/workflows/_deploy.yml` に 1 つだけ置き、`deploy-<app>.yml` は `app` を渡して呼ぶだけにする
5. デプロイ処理の本体は基盤が決まるまで空にする。実行すると warning と Summary で「何もデプロイしていない」と示す

## Consequences
- Actions 画面にアプリごとのボタンが並び、ブランチと SHA を選ぶだけで出せる。切り戻しも同じ操作で済む
- 検証ロジックの変更は `_deploy.yml` 1 ファイルで済む
- 同一アプリ・同一環境の待ちは 1 件だけ(GitHub の concurrency の仕様)。実行中に続けて投入すると古い待ちは取り消され、最後に投入したものが出る
- commit_id で過去コミットを出すとき、ワークフロー定義はブランチ HEAD、チェックアウトは指定コミットになる。デプロイ処理は古い断面でも通る手順で書く
- 基盤が決まったら `_deploy.yml` の deploy ジョブにビルドと反映を書き、クラウド認証(OIDC)用に `id-token: write` を呼び出し側の permissions に足す

## Open questions
- 切り戻しと DB migration の扱い。過去コミットを出しても migration は戻らないため、migration を常に後方互換で書くか、切り戻せる範囲を migration を挟まない断面に限るかを決める
- prd のデプロイに承認を挟むか(GitHub Environments の required reviewers はプランに依存する)
- migration の適用をデプロイと同じワークフローで行うか、別ワークフローにするか
