# ADR-0005: Web は RPC のルータ型を apps/api から直接 import し、packages/shared は apps に依存しない

- Status: Accepted
- Last updated: 2026-09-17

## Context
Hono RPC の型(`AdminRouter` / `PartnerRouter` / `MemberRouter`)は `apps/api/src/app.ts` で定義される。
当初は `packages/shared/src/rpc.ts` がこれを re-export し、Web は `@jcredit/shared` だけを見ればよい構成にしていた。
その結果 `shared → api → shared`(api は `APP_ENVS` 等の enum を shared から読む)、さらに `db → shared` の
循環が生まれ、turbo は `Circular package dependency detected` を警告するだけで止まらない一方、
`dependsOn: ["^typecheck"]` のような `^` 依存は `Cyclic dependency detected` で使えなかった。
そのため共有パッケージの変更を利用側のキャッシュに伝えるには、`turbo.json` の `inputs` に
`../../packages/*/src/**` のようなパスを手で列挙するしかなかった。

制約:
- 各パッケージは build 工程を持たず `src/*.ts` をそのまま export する(利用側の tsc が依存元のソースを直接読む)
- M1 / 16GB のため tsc の並列実行は避けたい(依存順に直列で回るのはむしろ望ましい)
- Web アプリは互いに独立デプロイで、ブラウザから API を直接 fetch しない(型だけを共有すればよい)

## Decision
1. Web アプリはルータ型を `import type { AdminRouter } from "@jcredit/api/app"` で直接読む。
   `@jcredit/api` は各 Web の **devDependencies**(型のみ。`import type` はビルド時に消えるので成果物には入らない)
2. `packages/shared` は `apps/*` に依存しない。`createApiClient` は hono 汎用のまま shared に残し、ルータ型の re-export は持たない
3. turbo は共有ソースの変更を `transit` タスク(`"transit": { "dependsOn": ["^transit"] }`、
   build / typecheck / test が `transit` に依存)で伝える。パスを列挙する `inputs` は使わない。
   `transit` は **意図的にどの package.json にも script を持たない**。turbo は turbo.json にだけあるタスクを
   transit ノード(dry-run では command が `<NONEXISTENT>`)としてグラフに乗せ、実行せずにハッシュだけ伝える。
   no-op script を足すと turbo がそれを実行してしまうので足さない
4. 機械的な守り:
   - `packages/shared/src/__tests__/no-app-dependency.test.ts` が shared の package.json と src の import を検査する
   - 各 Web の `lib/lane-router.test.ts` が「`@jcredit/api` から読むのは自レーンの Router の type import だけ」を検査する
     (Web 同士はコードを共有できないので 3 アプリに同じテストを置く)

## Consequences
- 共有パッケージ(ui / shared / db)や api を変更すると、依存する Web の typecheck / test / build のキャッシュが正しく無効化される
- Web の tsc が api のソースグラフ(hono / zod-openapi / db)を読む点は従来と同じ(shared 経由でも読んでいた)
- Web が api の型を直接参照するため、レーンをまたいだ型の誤用(admin-console が `MemberRouter` を使う等)や
  値 import(API のランタイムをバンドルに引き込む)を shared では防げない。各 Web の `lib/lane-router.test.ts` で弾く
- `packages/shared` に新しく apps 由来の型を置きたくなったら、それは api 側の `exports` に足すのが正

## Open questions
- 特になし
