# ADR-0006: lib / middleware は技術基盤に限定し、業務ロジックの共通化先にしない

- Status: Accepted
- Last updated: 2026-09-17

## Context
API は routes / services / repositories / schemas をレーン(admin / partner / member)ごとに完全分離し、
処理が同じでも複製する(`lane-isolation.test.ts`)。一方で `env.ts` / `lib/*` / `middleware/*` は
「技術基盤」として全レーンから共有できる。

この構成では `lib/` が唯一の「共有してよい場所」になるため、レーン間で同じ処理を書いたときに
「共通化したいものは `lib/` へ」という判断が自然に起きる。特にコーディングエージェントに実装させると、
DRY を優先して `lib/credit-calc.ts` のような業務ロジックを `lib/` に置き、レーン分離テストを通したまま
「複製する」規約を迂回できてしまう。「ドメイン知識を持たないもの」という条件は文章でしか
書かれておらず、判定はレビューに依存していた。

制約:
- `@jcredit/db` の入口はテーブル定義と client(`createDb` 等)を同じ `index.ts` から `export *` している。
  specifier だけではテーブルの import を区別できない
- 「ドメイン語彙」を grep で弾くのは誤検知が多く、運用に耐えない

## Decision
1. 技術基盤(`env.ts` / `lib/**` / `middleware/**`)は **routes / services / repositories / schemas を import しない**。
   レーンを問わず、`schemas/common.ts` のような非レーンファイルも含めて禁止する。
   技術基盤が必要とする共通の形(エラー形等)は `lib/` 側に置き、レーン層がそれを参照する向きに固定する
2. 技術基盤は **`@jcredit/db` からテーブル定義を読まない**。`@jcredit/db/schema` の import と、
   `@jcredit/db` の namespace / default import を禁止し、名前付き import は client の export
   (`createDb` / `Db` / `DB_DEFAULTS` / `loadRootEnvFiles` / `resolveDatabaseUrl` / `newId`)に限る。
   テーブルを触るコードは必ず `repositories/<lane>/` に置かれる
3. レーン間で共通化したくなった処理は、それが業務ロジックである証拠なので `services/<lane>/` に複製する。
   `lib/` に置けるのは「送る仕組み」「呼ぶ仕組み」(メール送信・外部 API クライアント・ログ・DB 接続)であり、
   「何をいつ送るか」「どの値なら有効か」は置かない
4. 機械的な守り: `apps/api/src/__tests__/lane-isolation.test.ts` の
   `technical infrastructure (env / lib / middleware)` が 1 と 2 を字句解析で検査する。
   client の export 一覧はテスト側に許可リストとして持つ(packages/db に client の export を足したら追随する)

## Consequences
- `lib/` に業務ロジックを置く抜け道が閉じ、「複製する」規約がレビューに頼らず守られる
- `lib/` の機能がテーブルを必要とした時点で設計の見直しを強制される(例: 領収書の生成は `lib/` に
  「PDF を作る」だけを置き、何を載せるかは `services/<lane>/` が組み立てる)
- packages/db の client export を増やしたときに許可リストの更新が必要(テストが赤くなるので気付ける)
- middleware が認可のためにテーブルを読みたくなる場合は、認可判断そのものを技術基盤に置かず、
  レーンごとの `services/` に問い合わせる形にする。その設計はこの ADR を更新して決める

## Open questions
- 認証・認可(セッションとユーザーの紐付け)を技術基盤とレーン層のどちらに置くかは、認証を入れる PR で決める
