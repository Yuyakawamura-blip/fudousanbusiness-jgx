# DB クラスタ一覧

- Last updated: 2026-10-15
- 出典: 要件定義「ER 図 Ver0.2」(drawio)。移行の決まりは [docs/design/README.md](../../README.md) の「DB 設計書」

クラスタは `packages/db/schema/<cluster>.ts` と `db/<cluster>.md` の単位。schema に落とす順に並べる。
クラスタをまたぐ FK は前のクラスタへの片方向だけにする(後ろのクラスタを参照しない)。
こうしないと、クラスタを 1 つずつ migration に落とせない。

| 順 | クラスタ | テーブル | 参照する前のクラスタ | drawio のページ | 移行 |
| --- | --- | --- | --- | --- | --- |
| 1 | `identity` | `members` / `partners` / `partner_branches` / `member_users` / `partner_users` / `admin_users` / `roles` / `member_user_roles` / `partner_user_roles` / `admin_user_roles` | — | 組織・アカウント | 済([identity.md](identity.md)) |
| 2 | `project` | `project_definitions` / `projects` / `recruitment_periods` / `terms_versions` / `document_requirements` / `equipment_types` | identity | プロジェクト・規約(+ 設備の `equipment_types`) | 済([project.md](project.md)) |
| 3 | `invitation` | `member_invitations` / `partner_invitations` / `admin_invitations` | identity / project | 招待・登録申請(招待の 3 表) | 済([invitation.md](invitation.md)) |
| 4 | `application` | `participation_requests` / `project_applications` / `application_confirmations` / `application_submissions` / `consent_records` | identity / project | 参加申請・申込・参加(+ プロジェクト・規約の `consent_records`) | 済([application.md](application.md)) |
| 5 | `review` | `reviews` / `member_basic_info_requests` / `partner_info_requests` | identity / application | 書類・審査の `reviews` + 招待・登録申請の申請 2 表 | 済([review.md](review.md)) |
| 6 | `facility` | `facilities` / `solar_facility_details` / `lighting_facility_details` / `subsidies` / `solar_generation_systems` / `solar_panels` / `power_conditioners` / `power_conditioner_units` / `storage_batteries` / `led_fixtures` / `prior_lighting_fixtures` / `prior_equipment_types` / `document_slots` / `evidence_documents` | project / application | 設備 + 書類・審査の書類 2 表 | 済([facility.md](facility.md)) |
| 7 | `notification` | `notification_types` / `notifications` / `inquiries` / `inquiry_messages` / `faqs` / `site_maintenance_modes` | identity / project | 通知・問い合わせ・その他 | 済([notification.md](notification.md)) |

```mermaid
flowchart RL
  project --> identity
  invitation --> identity
  invitation --> project
  application --> identity
  application --> project
  review --> identity
  review --> application
  facility --> project
  facility --> application
  notification --> identity
  notification --> project
```

## drawio のページと分け方が違うテーブル

drawio のページのままだとクラスタ間の参照が循環する。循環を切るために次の 4 つを動かした。

| テーブル | drawio のページ | クラスタ | 理由 |
| --- | --- | --- | --- |
| `equipment_types` | 設備 | `project` | `project_definitions` が参照するマスタ。設備に置くと project → facility → application → project で循環する |
| `consent_records` | プロジェクト・規約 | `application` | `project_applications` を参照する。project に置くと project ↔ application で循環する |
| `member_basic_info_requests` / `partner_info_requests` | 招待・登録申請 | `review` | `reviews` を参照する。`reviews` は `application_submissions` を参照するので、招待と同じ早い順に置けない |
| `document_slots` / `evidence_documents` | 書類・審査 | `facility` | 施設・対象設備・補助金明細を参照する。用語集の「設備と書類」と同じまとまり |

## 順番の理由

画面設計が固まる順(会員マイページ・創出PTマイページが先、運営者コンソールが後)に合わせ、参照の向きで前後を入れ替えた。

- `identity` → `project` → `invitation`: 全アプリのログインと、会員登録・招待からのアカウント作成が最初に要る。招待は会員の招待でプロジェクトを選ぶので `project` の後
- `application` → `review`: 参加申請・申込の後に運営者の審査。会員登録の基本情報は `member_basic_info_requests` に書くので、運営者の確認で仮会員を外すところは `review` が入ってからになる。仮会員でもポータルの画面は使え、見られないのはプロジェクトの情報などだけなので、会員登録とログインはそれより前のクラスタで作れる
- `facility`: 申込の施設情報入力と証跡書類。申込の入力画面の詳細が決まってから
- `notification`: 他のクラスタを参照するだけで、参照されない。最後でよい
