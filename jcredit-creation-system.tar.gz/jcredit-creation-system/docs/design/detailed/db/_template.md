# <cluster>: <このクラスタが扱う業務領域を一言で>

- Last updated: YYYY-MM-DD
- Schema: `packages/db/schema/<cluster>.ts`

## 概要
<どの業務のどのデータを持つか。他クラスタとの境界(何を持たないか)を含めて 3 行以内>

## ER 図
<業務的に意味のある関係だけを描く。FK を機械的に全部並べない。多重度と関係の意味(動詞)を付ける>

```mermaid
erDiagram
  PARENT_TABLE ||--o{ CHILD_TABLE : "has"
```

## テーブル

### <table_name> — <業務的な意味を一言>
<コードから読めないことだけ書く:
- 1 行が何を表すか、いつ作られ、いつ消えるか(論理削除 / 物理削除 / 保持期間)
- 状態を持つなら遷移(どの状態からどの状態へ、誰が)
- UNIQUE / CHECK の業務上の理由(「なぜその組み合わせで一意か」)
- 型からは読めない値の意味(単位・精度・タイムゾーンの扱い)
カラムごとの説明列は置かない。説明が要るカラムはここに書く>

<!-- generated:start table=<table_name> -->
<!-- 以下の行は出力形式の例(idPk() / timestamps を使ったテーブルの場合)。論理名の列以外は pnpm db:docs が schema から生成する -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| <name> | UNIQUE / INDEX / CHECK / FK | <col, ...> | <式 / 参照先> |
<!-- generated:end -->

## Open questions
- <未決のまま進めること。決まったらこのファイルを更新する>

<!-- 書き方は docs/design/README.md の「DB 設計書」。
     ファイルは docs/design/detailed/db/<cluster>.md(packages/db/schema/<cluster>.ts と 1:1)。
     generated:start table=<table_name> 〜 generated:end のマーカー(HTML コメント)の間は `pnpm db:docs` が schema から書き換える(論理名の列だけ手で書き、それ以外は手で編集しない)。
     上の行は生成結果の形式を示す例で、スクリプトはこの形で出力する。
     それ以外は手書き。変更履歴はここに書かない: git log -p --follow <このファイル> が持っている -->
