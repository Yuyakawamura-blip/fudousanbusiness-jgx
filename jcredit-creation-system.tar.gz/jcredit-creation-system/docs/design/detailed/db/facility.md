# facility: 施設・対象設備・書類

- Last updated: 2026-10-15
- Schema: `packages/db/schema/facility.ts`

## 概要
申込に添える施設情報(施設 → 区分別の詳細 → 機器)と補助金明細、書類枠と証跡書類を持つ。
施設・書類枠は申込([application](application.md))にぶら下がる。設備区分と必要書類定義は [project](project.md)。用語は [domain.md](../../basic/domain.md) の「設備と書類」。

入力項目は入会届(太陽光法人 V3 / 照明設備法人 V3)の別添 2 に合わせる。入会届の項目のうち列で持たないもの:

| 入会届の項目 | どう表すか |
| --- | --- |
| 蓄電池の有無 | `storage_batteries` の行があるか |
| パワコンの導入台数 | `power_conditioner_units` の行数 |
| LED 導入日・稼働開始日 | `facilities.operation_start_date` |
| 補助金の利用有無 | `subsidies` の行があるか |

承認後の設備の変更・処分・滅失の届出は作らない([scope.md](../../basic/scope.md))。

## ER 図

```mermaid
erDiagram
  PROJECT_APPLICATIONS ||--|{ FACILITIES : "施設"
  EQUIPMENT_TYPES ||--o{ FACILITIES : "設備区分"
  FACILITIES ||--o| SOLAR_FACILITY_DETAILS : "太陽光の詳細"
  FACILITIES ||--o| LIGHTING_FACILITY_DETAILS : "LED の詳細"
  FACILITIES ||--o{ SUBSIDIES : "補助金明細"
  SOLAR_FACILITY_DETAILS ||--o{ SOLAR_GENERATION_SYSTEMS : "発電設備"
  SOLAR_GENERATION_SYSTEMS ||--o{ SOLAR_PANELS : "パネル"
  SOLAR_GENERATION_SYSTEMS ||--o{ POWER_CONDITIONERS : "パワコン"
  POWER_CONDITIONERS ||--o{ POWER_CONDITIONER_UNITS : "1 台ごと"
  SOLAR_GENERATION_SYSTEMS ||--o{ STORAGE_BATTERIES : "蓄電池"
  LIGHTING_FACILITY_DETAILS ||--o{ LED_FIXTURES : "更新後 LED"
  LIGHTING_FACILITY_DETAILS ||--o{ PRIOR_LIGHTING_FIXTURES : "更新前照明"
  EQUIPMENT_TYPES ||--o{ PRIOR_EQUIPMENT_TYPES : "区分"
  PRIOR_EQUIPMENT_TYPES ||--o{ PRIOR_LIGHTING_FIXTURES : "種別"
  PROJECT_APPLICATIONS ||--o{ DOCUMENT_SLOTS : "申込書類"
  DOCUMENT_REQUIREMENTS |o--o{ DOCUMENT_SLOTS : "定義から作る"
  FACILITIES |o--o{ DOCUMENT_SLOTS : "対象施設"
  SOLAR_GENERATION_SYSTEMS |o--o{ DOCUMENT_SLOTS : "対象発電設備"
  SUBSIDIES |o--o{ DOCUMENT_SLOTS : "対象補助金"
  DOCUMENT_SLOTS ||--o{ EVIDENCE_DOCUMENTS : "ファイル"
  EVIDENCE_DOCUMENTS |o--o{ EVIDENCE_DOCUMENTS : "差替え元"
```

`PROJECT_APPLICATIONS` は [application](application.md)、`EQUIPMENT_TYPES` / `DOCUMENT_REQUIREMENTS` は [project](project.md)。

## テーブル

### facilities — 施設
1 行が、申込の対象になる設備を置く場所 1 つと、太陽光・LED 共通の項目。申込の入力中に会員(または代理入力の創出PT)が作る。

- 区分別の詳細(`solar_facility_details` / `lighting_facility_details`)は、施設の設備区分と同じほうを 1 行だけ作る。下の複合 FK で、区分の違う詳細は作れない
- `facilities_id_equipment_type_code_unique`: 詳細の複合 FK の参照先。`id` だけで一意だが、FK の参照先に (`id`, `equipment_type_code`) の一意制約が要る
- `equipment_type_code`: 設備区分をコードで持つ(参照は id で行う決まりの例外)。詳細の表が `'SOLAR'` / `'LED'` を CHECK で縛るため
- 施設名・住所は照明の入会届にだけ記入欄があるので、LED は必須・太陽光は任意(drawio の「△」)
- アプリで検証すること:
  - 施設の設備区分は、申込のプロジェクト定義の設備区分と同じ
  - 個人会員は申込 1 件に施設 1 つ、法人会員は複数
  - 稼働開始日は会員規約に同意した日の 2 年前以降(2 年ルール)
  - `prefecture` は 47 都道府県名のどれか。郵便番号からの補完は都道府県・市区町村・町名までで、番地以降と建物名は手入力

<!-- generated:start table=facilities -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト申込・参加ID | project_application_id | text | NOT NULL | | |
| 設備区分コード | equipment_type_code | text | NOT NULL | | |
| 施設名 | facility_name | text | NULL | | |
| 郵便番号 | postal_code | text | NULL | | |
| 都道府県 | prefecture | text | NULL | | |
| 市区町村 | city | text | NULL | | |
| 町名・番地 | street_address | text | NULL | | |
| 建物名・部屋番号 | building_name | text | NULL | | |
| 稼働開始日 | operation_start_date | date | NOT NULL | | |
| 総投資額 | total_investment_amount | numeric(15, 0) | NOT NULL | | |
| 購入電力単価 | purchased_electricity_unit_price | numeric(10, 4) | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| facilities_id_equipment_type_code_unique | UNIQUE | id, equipment_type_code | |
| facilities_project_application_id_index | INDEX | project_application_id | |
| facilities_project_application_id_project_applications_id_fk | FK | project_application_id | project_applications(id) |
| facilities_equipment_type_code_fk | FK | equipment_type_code | equipment_types(equipment_type_code) |
<!-- generated:end -->

### solar_facility_details — 太陽光施設の詳細
1 行が、区分が太陽光の施設 1 つの、太陽光だけの項目(自家消費・売電・メンテナンス費用)。

- `solar_facility_details_facility_fk`: (`facility_id`, `equipment_type_code`) で施設を指し、`solar_facility_details_equipment_type_check` で区分を `'SOLAR'` に縛る。区分が LED の施設には作れず、詳細を作ったあとに施設の区分も変えられない
- 太陽光の機器(`solar_generation_systems`)は施設ではなくこの表の `facility_id` を指す。これで区分が太陽光の施設にしか発電設備を付けられない
- `measurement_device_status`: 測定機器の設置状況。値と、どの条件で必須か(drawio の「△」)が決まっていない(Open questions)

<!-- generated:start table=solar_facility_details -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| 設備区分コード | equipment_type_code | text | NOT NULL | 'SOLAR' | |
| 自家消費電力量 | self_consumption_kwh | numeric(18, 3) | NOT NULL | | |
| 売電量 | sold_electricity_kwh | numeric(18, 3) | NOT NULL | | |
| 売電単価 | sold_electricity_unit_price | numeric(10, 4) | NOT NULL | | |
| メンテナンス費用 | maintenance_cost | numeric(15, 0) | NOT NULL | | |
| 測定機器設置状況 | measurement_device_status | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| solar_facility_details_facility_id_unique | UNIQUE | facility_id | |
| solar_facility_details_equipment_type_check | CHECK | | equipment_type_code = 'SOLAR' |
| solar_facility_details_facility_fk | FK | facility_id, equipment_type_code | facilities(id, equipment_type_code) |
<!-- generated:end -->

### lighting_facility_details — 照明施設の詳細
1 行が、区分が LED の施設 1 つの、照明だけの項目(階数・蛍光灯の導入時期・工事年度)。複合 FK と区分の CHECK は `solar_facility_details` と同じ(区分は `'LED'`)。

- `lighting_facility_details_installed_check`: 蛍光灯の導入時期と建物の竣工時期は、どちらか 1 つ以上が要る(入会届「蛍光灯の導入時期または建物の竣工時期」)
- `lighting_facility_details_construction_range_check`: 工事開始年度 ≦ 工事終了年度。1 年度だけの工事は同じ年度を入れる
- `target_floors`: 対象の階。「1〜3 階」のように書くので文字列で持つ
- アプリで検証すること: 蛍光灯の導入時期(無ければ建物の竣工時期)からの経過年数を、更新前照明機器の更新前設備種別の法定耐用年数と比べ、超えているかを判定する

<!-- generated:start table=lighting_facility_details -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| 設備区分コード | equipment_type_code | text | NOT NULL | 'LED' | |
| 全体の階数 | total_floors | smallint | NOT NULL | | |
| 対象の階 | target_floors | text | NOT NULL | | |
| 蛍光灯の導入時期 | prior_lighting_installed_on | date | NULL | | |
| 建物の竣工時期 | building_completed_on | date | NULL | | |
| 工事開始年度 | construction_start_fiscal_year | smallint | NOT NULL | | |
| 工事終了年度 | construction_end_fiscal_year | smallint | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| lighting_facility_details_facility_id_unique | UNIQUE | facility_id | |
| lighting_facility_details_equipment_type_check | CHECK | | equipment_type_code = 'LED' |
| lighting_facility_details_installed_check | CHECK | | num_nonnulls(prior_lighting_installed_on, building_completed_on) >= 1 |
| lighting_facility_details_construction_range_check | CHECK | | construction_start_fiscal_year <= construction_end_fiscal_year |
| lighting_facility_details_facility_fk | FK | facility_id, equipment_type_code | facilities(id, equipment_type_code) |
<!-- generated:end -->

### subsidies — 補助金明細
1 行が、施設 1 つが受けた補助金 1 件。同じ交付決定が複数の施設にまたがるときは、施設ごとに 1 行ずつ金額を分けて登録する。補助金額 ≦ 総投資額の判定を施設単位で行うため。

- アプリで検証すること: 施設の補助金額の合計 ≦ 施設の総投資額

<!-- generated:start table=subsidies -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| 補助金名称 | subsidy_name | text | NOT NULL | | |
| 補助金額 | amount | numeric(15, 0) | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| subsidies_facility_id_index | INDEX | facility_id | |
| subsidies_facility_id_facilities_id_fk | FK | facility_id | facilities(id) |
<!-- generated:end -->

### solar_generation_systems — 太陽光発電設備
1 行が、太陽光施設の発電設備 1 式。パネル・パワコン・蓄電池がぶら下がる。

- `solar_generation_systems_serial_number_index`: 機器固有番号の重複登録チェックで引く。一意制約にしないのは、否認・期限切れの申込や下書きにも同じ番号の行が残るため
- アプリで検証すること: 機器固有番号が、参加中の申込の設備・進行中の他の申込の設備と一致したら提出させない(`power_conditioner_units` も同じ)

<!-- generated:start table=solar_generation_systems -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| メーカー | manufacturer | text | NOT NULL | | |
| 型式 | model_number | text | NOT NULL | | |
| 機器固有番号 | serial_number | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| solar_generation_systems_facility_id_index | INDEX | facility_id | |
| solar_generation_systems_serial_number_index | INDEX | serial_number | |
| solar_generation_systems_facility_fk | FK | facility_id | solar_facility_details(facility_id) |
<!-- generated:end -->

### solar_panels — 太陽光パネル
1 行が、発電設備のパネル 1 種類と公称最大出力。

<!-- generated:start table=solar_panels -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 太陽光発電設備ID | solar_generation_system_id | text | NOT NULL | | |
| 公称最大出力 | rated_max_output_kw | numeric(12, 3) | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| solar_panels_solar_generation_system_id_index | INDEX | solar_generation_system_id | |
| solar_panels_solar_generation_system_fk | FK | solar_generation_system_id | solar_generation_systems(id) |
<!-- generated:end -->

### power_conditioners — パワーコンディショナー
1 行が、発電設備のパワコン 1 機種。導入台数は列で持たず、この行にぶら下がる `power_conditioner_units` の行数で表す(台数の入力に合わせて機器固有番号の入力行を増減する)。

<!-- generated:start table=power_conditioners -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 太陽光発電設備ID | solar_generation_system_id | text | NOT NULL | | |
| メーカー | manufacturer | text | NOT NULL | | |
| 型式 | model_number | text | NOT NULL | | |
| 夜間待機電力 | night_standby_power_w | numeric(10, 3) | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| power_conditioners_solar_generation_system_id_index | INDEX | solar_generation_system_id | |
| power_conditioners_solar_generation_system_fk | FK | solar_generation_system_id | solar_generation_systems(id) |
<!-- generated:end -->

### power_conditioner_units — パワコン機器
1 行がパワコン 1 台と、その機器固有番号。

- `power_conditioner_units_serial_number_index`: 重複登録チェック用。`solar_generation_systems` と同じ理由で一意制約にしない

<!-- generated:start table=power_conditioner_units -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| パワーコンディショナーID | power_conditioner_id | text | NOT NULL | | |
| 機器固有番号 | serial_number | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| power_conditioner_units_power_conditioner_id_index | INDEX | power_conditioner_id | |
| power_conditioner_units_serial_number_index | INDEX | serial_number | |
| power_conditioner_units_power_conditioner_fk | FK | power_conditioner_id | power_conditioners(id) |
<!-- generated:end -->

### storage_batteries — 蓄電池
1 行が、発電設備の蓄電池 1 機種。蓄電池が無い発電設備は行を作らない。

<!-- generated:start table=storage_batteries -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 太陽光発電設備ID | solar_generation_system_id | text | NOT NULL | | |
| メーカー | manufacturer | text | NOT NULL | | |
| 型式 | model_number | text | NOT NULL | | |
| 容量 | capacity_kw | numeric(12, 3) | NOT NULL | | |
| 効率 | efficiency_rate | numeric(5, 2) | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| storage_batteries_solar_generation_system_id_index | INDEX | solar_generation_system_id | |
| storage_batteries_solar_generation_system_fk | FK | solar_generation_system_id | solar_generation_systems(id) |
<!-- generated:end -->

### led_fixtures — LED 照明機器
1 行が、照明施設に入れる LED 照明 1 種類(設置場所・型番ごと)と設置個数。施設ではなく照明の詳細の `facility_id` を指し、区分が LED の施設にしか付けられない。

<!-- generated:start table=led_fixtures -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| 設置場所 | installation_location | text | NOT NULL | | |
| 型番 | model_number | text | NOT NULL | | |
| 製造番号 | serial_number | text | NULL | | |
| 定格出力 | rated_output_w | numeric(10, 3) | NOT NULL | | |
| 効率 | efficiency_lm_per_w | numeric(12, 3) | NULL | | |
| 設置個数 | quantity | integer | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| led_fixtures_facility_id_index | INDEX | facility_id | |
| led_fixtures_facility_fk | FK | facility_id | lighting_facility_details(facility_id) |
<!-- generated:end -->

### prior_equipment_types — 更新前設備種別
1 行が、更新前の照明機器の種別 1 つ(蛍光灯の種類等)と法定耐用年数。データ投入で入れるマスタ。

- `application_deadline`: その種別で申し込める期限(加入期限)。期限の無い種別は NULL
- アプリで検証すること: 更新前照明機器に付けるのは、設備区分が LED の種別だけ

<!-- generated:start table=prior_equipment_types -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 設備区分ID | equipment_type_id | text | NOT NULL | | |
| 種別名 | type_name | text | NOT NULL | | |
| 法定耐用年数 | legal_useful_life_years | smallint | NOT NULL | | |
| 加入期限 | application_deadline | date | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| prior_equipment_types_equipment_type_id_index | INDEX | equipment_type_id | |
| prior_equipment_types_equipment_type_id_equipment_types_id_fk | FK | equipment_type_id | equipment_types(id) |
<!-- generated:end -->

### prior_lighting_fixtures — 更新前照明機器
1 行が、LED に入れ替える前の照明 1 種類(設置場所・型番ごと)と設置個数。`led_fixtures` と同じく照明の詳細を指す。

<!-- generated:start table=prior_lighting_fixtures -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 施設ID | facility_id | text | NOT NULL | | |
| 更新前設備種別ID | prior_equipment_type_id | text | NOT NULL | | |
| 設置場所 | installation_location | text | NOT NULL | | |
| 型番 | model_number | text | NOT NULL | | |
| 製造番号 | serial_number | text | NULL | | |
| 定格出力 | rated_output_w | numeric(10, 3) | NOT NULL | | |
| 効率 | efficiency_lm_per_w | numeric(12, 3) | NULL | | |
| 設置個数 | quantity | integer | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| prior_lighting_fixtures_facility_id_index | INDEX | facility_id | |
| prior_lighting_fixtures_prior_equipment_type_id_index | INDEX | prior_equipment_type_id | |
| prior_lighting_fixtures_facility_fk | FK | facility_id | lighting_facility_details(facility_id) |
| prior_lighting_fixtures_prior_equipment_type_fk | FK | prior_equipment_type_id | prior_equipment_types(id) |
<!-- generated:end -->

### document_slots — 書類枠
1 行が、申込で出す書類 1 種類分の提出先。申込を作るときに必要書類定義(`document_requirements`)から作り、資料種別・必須区分を写す。必須区分は会員種別・確認事項の回答で変わるので、定義の値から書類枠ごとに決めて持つ。

- `document_slots_target_check`: 書類の対象(施設・発電設備・補助金明細)は 1 つ以下。申込全体の書類はすべて NULL
- 状態遷移(`slot_status`):

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `NOT_SUBMITTED` | 申込を作ったとき(施設・発電設備・補助金明細ごとの書類枠は、それらを作ったとき) |
| `NOT_SUBMITTED` | `SUBMITTED` | 証跡書類を 1 つ以上添付したとき |
| `SUBMITTED` | `NOT_SUBMITTED` | 下書きの間に、添付した証跡書類をすべて削除したとき |
| `NOT_SUBMITTED` | `NOT_APPLICABLE` | 「該当なし」を理由とともに選んだとき |
| `NOT_APPLICABLE` | `NOT_SUBMITTED` | 「該当なし」を取り消したとき |

- `SUBMITTED` は書類枠に添付があること(画面の表示は「添付済」)で、申込を提出したかどうかではない
- `document_slots_not_applicable_check`: 該当なしの理由・選んだ日時・選んだ人(種別 + ID)は、`NOT_APPLICABLE` のときだけ 4 つとも入れる。代理入力・運営者補正があるので、選んだ人は種別 + ID で持つ
- アプリで検証すること:
  - 対象の施設・発電設備・補助金明細は、同じ申込のもの
  - 「該当なし」は、必要書類定義が `is_not_applicable_allowed` のときだけ選べる(無条件の必須書類には選べない)
  - 提出時に、必須の書類枠がすべて `SUBMITTED` か `NOT_APPLICABLE`

<!-- generated:start table=document_slots -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト申込・参加ID | project_application_id | text | NOT NULL | | |
| 必要書類定義ID | document_requirement_id | text | NULL | | |
| 施設ID | facility_id | text | NULL | | |
| 太陽光発電設備ID | solar_generation_system_id | text | NULL | | |
| 補助金明細ID | subsidy_id | text | NULL | | |
| 資料種別 | document_type | text | NOT NULL | | |
| 必須区分 | requirement_type | text | NOT NULL | | |
| 書類状態 | slot_status | text | NOT NULL | 'NOT_SUBMITTED' | |
| 該当なし理由 | not_applicable_reason | text | NULL | | |
| 該当なし選択日時 | not_applicable_selected_at | timestamptz | NULL | | |
| 該当なし選択者種別 | not_applicable_selected_by_user_type | text | NULL | | |
| 該当なし選択者ID | not_applicable_selected_by_user_id | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| document_slots_project_application_id_index | INDEX | project_application_id | |
| document_slots_document_requirement_id_index | INDEX | document_requirement_id | |
| document_slots_facility_id_index | INDEX | facility_id | |
| document_slots_solar_generation_system_id_index | INDEX | solar_generation_system_id | |
| document_slots_subsidy_id_index | INDEX | subsidy_id | |
| document_slots_requirement_type_check | CHECK | | requirement_type in ('REQUIRED', 'OPTIONAL') |
| document_slots_slot_status_check | CHECK | | slot_status in ('NOT_SUBMITTED', 'SUBMITTED', 'NOT_APPLICABLE') |
| document_slots_not_applicable_selected_by_user_type_check | CHECK | | not_applicable_selected_by_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| document_slots_target_check | CHECK | | num_nonnulls(facility_id, solar_generation_system_id, subsidy_id) <= 1 |
| document_slots_not_applicable_check | CHECK | | num_nonnulls(not_applicable_reason, not_applicable_selected_at, not_applicable_selected_by_user_type, not_applicable_selected_by_user_id) = case when slot_status = 'NOT_APPLICABLE' then 4 else 0 end |
| document_slots_facility_id_facilities_id_fk | FK | facility_id | facilities(id) |
| document_slots_subsidy_id_subsidies_id_fk | FK | subsidy_id | subsidies(id) |
| document_slots_project_application_fk | FK | project_application_id | project_applications(id) |
| document_slots_document_requirement_fk | FK | document_requirement_id | document_requirements(id) |
| document_slots_solar_generation_system_fk | FK | solar_generation_system_id | solar_generation_systems(id) |
<!-- generated:end -->

### evidence_documents — 証跡書類
1 行が、書類枠に添付したファイル 1 つ。ファイルの本体はオブジェクトストレージに置き、この表は保存先のキーとメタデータを持つ。

- `evidence_documents_storage_object_key_unique`: 1 つの保存オブジェクトを 2 行から指さない
- 差し替え: 下書きの間は差し替え・削除できる。提出した書類は変えず、差し戻し後の差し替えは新しい行を作り、`replaced_evidence_document_id` に差し替え元を入れる。提出版(`application_submissions`)の中身が差し替え前の書類を指したままになるため
- `verification_status`: 運営者が審査で書類ごとに中身を確認したか。不備の指摘は審査の理由に書く([review](review.md))
- `uploaded_by_user_type` + `uploaded_by_user_id`: 添付した人。代理入力の創出PTユーザー、運営者補正の運営者も添付するので、種別 + ID で持つ
- アプリで検証すること(差し替えと同じトランザクションで): 差し替え元は同じ書類枠の証跡書類

<!-- generated:start table=evidence_documents -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 書類枠ID | document_slot_id | text | NOT NULL | | |
| 差替え元の証跡書類ID | replaced_evidence_document_id | text | NULL | | |
| 保存オブジェクトキー | storage_object_key | text | NOT NULL | | UNIQUE |
| ファイル名 | file_name | text | NOT NULL | | |
| MIMEタイプ | mime_type | text | NOT NULL | | |
| ファイルサイズ | file_size_bytes | bigint | NOT NULL | | |
| ハッシュ値 | file_hash | text | NULL | | |
| 確認資料名・補足 | reference_note | text | NULL | | |
| 確認状態 | verification_status | text | NOT NULL | 'UNVERIFIED' | |
| アップロード日時 | uploaded_at | timestamptz | NOT NULL | now() | |
| アップロード者種別 | uploaded_by_user_type | text | NOT NULL | | |
| アップロード者ID | uploaded_by_user_id | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| evidence_documents_document_slot_id_index | INDEX | document_slot_id | |
| evidence_documents_replaced_evidence_document_id_index | INDEX | replaced_evidence_document_id | |
| evidence_documents_uploaded_by_index | INDEX | uploaded_by_user_type, uploaded_by_user_id | |
| evidence_documents_verification_status_check | CHECK | | verification_status in ('UNVERIFIED', 'VERIFIED') |
| evidence_documents_uploaded_by_user_type_check | CHECK | | uploaded_by_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| evidence_documents_document_slot_id_document_slots_id_fk | FK | document_slot_id | document_slots(id) |
| evidence_documents_replaced_evidence_document_fk | FK | replaced_evidence_document_id | evidence_documents(id) |
<!-- generated:end -->

## Open questions
- `measurement_device_status` の値(設置済・未設置 等)と、必須になる条件
- 証跡書類の確認状態は確認済み・未確認の 2 つにした。drawio には既定値 `'UNVERIFIED'` しか無い。差し戻しで書類ごとに不備を付ける(機能要件一覧の差戻しの「不備箇所(項目・書類)を指定」)なら、不備の状態か書類枠ごとの指摘を持つ必要がある
- 書類枠の状態の値は drawio の既定値 `'NOT_SUBMITTED'` と機能要件一覧の「該当なし」選択・必要書類充足チェックから決めた
- `document_requirement_id` が NULL の書類枠(必要書類定義から作らない書類枠)をいつ作るか。drawio では任意の列だが、作る場面が機能要件に無い
- LED 照明の製造番号(`serial_number`)も重複登録チェックの対象か。任意の列なので今は索引を張っていない
