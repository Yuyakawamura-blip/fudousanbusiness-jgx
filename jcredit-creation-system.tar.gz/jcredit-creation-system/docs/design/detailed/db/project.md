# project: プロジェクト定義・プロジェクト・募集期・規約・必要書類・設備区分

- Last updated: 2026-10-15
- Schema: `packages/db/schema/project.ts`

## 概要
プロジェクト定義(ひな形)と、それを元に創出PTごとに作るプロジェクトを持つ。募集期・規約の版・必要書類はプロジェクト定義に付く。
プロジェクト定義と規約・必要書類・設備区分はデータ投入で入れ、作成する画面は無い。
規約への同意(`consent_records`)は申込を参照するので [application](application.md) が持つ。用語は [domain.md](../../basic/domain.md)。

## ER 図

```mermaid
erDiagram
  EQUIPMENT_TYPES ||--o{ PROJECT_DEFINITIONS : "区分する"
  PROJECT_DEFINITIONS ||--o{ PROJECTS : "元にする"
  PARTNERS ||--o{ PROJECTS : "参画する"
  PROJECT_DEFINITIONS ||--o{ RECRUITMENT_PERIODS : "持つ"
  PROJECT_DEFINITIONS |o--o{ TERMS_VERSIONS : "持つ(NULL は共通)"
  PROJECT_DEFINITIONS ||--o{ DOCUMENT_REQUIREMENTS : "持つ"
```

`PARTNERS` は [identity](identity.md)。

## テーブル

### equipment_types — 設備区分
太陽光(`SOLAR`)と LED(`LED`)の 2 行だけのマスタ。
参照は `id` で行うのが原則だが、設備の表(`facility` クラスタ)は `equipment_type_code` を参照し、太陽光・LED の詳細表の区分を CHECK で縛る。そのためコード列を持ち、一意にする。

<!-- generated:start table=equipment_types -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 設備区分コード | equipment_type_code | text | NOT NULL | | UNIQUE |
| 区分名 | type_name | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| equipment_types_equipment_type_code_check | CHECK | | equipment_type_code in ('SOLAR', 'LED') |
<!-- generated:end -->

### project_definitions — プロジェクト定義
1 行が 1 つのプログラム型プロジェクトのひな形(太陽光・LED 照明等)。画面には出さず、会員・創出PTはプロジェクトを扱う。

募集状態の遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `DRAFT` | プロジェクト定義を入れたとき(準備中) |
| `DRAFT` / `SUSPENDED` | `OPEN` | 運営者が募集を始めたとき |
| `OPEN` | `SUSPENDED` | 運営者が新規の申込の受付を止めたとき |
| `OPEN` / `SUSPENDED` | `CLOSED` | 運営者が募集を終えたとき |

- 申込できるのは、募集状態が `OPEN` で、現在時刻を含む募集期があるとき。`SUSPENDED` の間は新規の申込を受け付けない
- `methodology_code`: J-クレジットの方法論のコード(例: 太陽光・LED の方法論番号)。値の一覧が無いので DB では縛らない(Open questions)

<!-- generated:start table=project_definitions -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 設備区分ID | equipment_type_id | text | NOT NULL | | |
| プロジェクト定義名 | project_definition_name | text | NOT NULL | | |
| 方法論コード | methodology_code | text | NOT NULL | | |
| 募集状態 | recruitment_status | text | NOT NULL | 'DRAFT' | |
| 説明本文 | description | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| project_definitions_equipment_type_id_index | INDEX | equipment_type_id | |
| project_definitions_recruitment_status_check | CHECK | | recruitment_status in ('DRAFT', 'OPEN', 'SUSPENDED', 'CLOSED') |
| project_definitions_equipment_type_id_equipment_types_id_fk | FK | equipment_type_id | equipment_types(id) |
<!-- generated:end -->

### projects — プロジェクト
1 行が 1 つの創出PTの、1 つのプロジェクト定義への参画。運営者が創出PTを登録するときに一緒に作る。

- `projects_partner_definition_unique`: 1 つの創出PTは同じ定義から 1 つだけ作る
- `project_code`: 会員が画面で入力してプロジェクトを指定するコード。このコードで創出PTとプロジェクト定義が一意に決まる。アプリが採番する
- `display_name`: 会員・創出PTの画面に出す名前。プロジェクト定義名とは別に持つ

<!-- generated:start table=projects -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTID | partner_id | text | NOT NULL | | |
| プロジェクト定義ID | project_definition_id | text | NOT NULL | | |
| プロジェクトコード | project_code | text | NOT NULL | | UNIQUE |
| 表示名 | display_name | text | NOT NULL | | |
| ステータス | status | text | NOT NULL | 'ACTIVE' | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| projects_partner_definition_unique | UNIQUE | partner_id, project_definition_id | |
| projects_project_definition_id_index | INDEX | project_definition_id | |
| projects_status_check | CHECK | | status in ('ACTIVE', 'CLOSED') |
| projects_partner_id_partners_id_fk | FK | partner_id | partners(id) |
| projects_project_definition_id_project_definitions_id_fk | FK | project_definition_id | project_definitions(id) |
<!-- generated:end -->

### recruitment_periods — 募集期
1 行がプロジェクト定義の 1 回分の申込の受付期間(第 N 期)。

- 状態(予定・募集中・締切)は列で持たず、募集開始・締切日時と現在時刻から判定する
- 同じプロジェクト定義で期間が重ならないことはアプリで検証する
- 申込は、そのときに募集中の期に紐づける(`application` クラスタ)

<!-- generated:start table=recruitment_periods -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト定義ID | project_definition_id | text | NOT NULL | | |
| 期名 | period_name | text | NOT NULL | | |
| 募集開始日時 | recruitment_start_at | timestamptz | NOT NULL | | |
| 募集締切日時 | recruitment_end_at | timestamptz | NOT NULL | | |
| 対象年度 | target_fiscal_year | smallint | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| recruitment_periods_project_definition_id_index | INDEX | project_definition_id | |
| recruitment_periods_range_check | CHECK | | recruitment_start_at < recruitment_end_at |
| recruitment_periods_project_definition_fk | FK | project_definition_id | project_definitions(id) |
<!-- generated:end -->

### terms_versions — 規約・同意項目の版
1 行が規約 1 本、または同意・申告の項目 1 つの 1 つの版。改訂は新しい版の行を足し、古い行は同意の記録が指すので消さない。

| `terms_type` | 中身 | `project_definition_id` |
| --- | --- | --- |
| `TERMS_OF_USE` | システム利用規約 | NULL(共通) |
| `PRIVACY_POLICY` | プライバシーポリシー | NULL(共通) |
| `MEMBER_AGREEMENT` | 会員規約 | プロジェクト定義 |
| `SERVICE_CONSENT` | サービス利用同意(4 項目) | プロジェクト定義 |
| `DECLARATION` | 申告事項(5 項目) | プロジェクト定義 |

- `terms_versions_scope_check`: 共通の種別だけ `project_definition_id` が NULL。上の表の対応を DB で縛る
- `terms_versions_item_version_unique`: 共通規約は `project_definition_id` が NULL なので、NULLS NOT DISTINCT にして同じ版の重複を防ぐ
- `item_code`: 同じ種別の中の項目を分けるコード。本文 1 本だけの種別(利用規約・プライバシーポリシー・会員規約)は `MAIN` にする。値はデータ投入で決め、DB では縛らない
- 今の版は、同じ (`terms_type`, `item_code`, `project_definition_id`) のうち `effective_from` が今日以前で最新の行。新しい版が施行されたら、会員ユーザーに再同意を求める(どの画面で求めるかは [api-usecases/member.md](../../basic/api-usecases/member.md) の「規約の再同意」)

<!-- generated:start table=terms_versions -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト定義ID | project_definition_id | text | NULL | | |
| 規約種別 | terms_type | text | NOT NULL | | |
| 同意項目コード | item_code | text | NOT NULL | | |
| 版数 | version | text | NOT NULL | | |
| 本文・文言 | content | text | NOT NULL | | |
| 施行日 | effective_from | date | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| terms_versions_item_version_unique | UNIQUE | terms_type, item_code, project_definition_id, version | NULLS NOT DISTINCT |
| terms_versions_project_definition_id_index | INDEX | project_definition_id | |
| terms_versions_terms_type_check | CHECK | | terms_type in ('TERMS_OF_USE', 'PRIVACY_POLICY', 'MEMBER_AGREEMENT', 'SERVICE_CONSENT', 'DECLARATION') |
| terms_versions_scope_check | CHECK | | (project_definition_id is null) = (terms_type in ('TERMS_OF_USE', 'PRIVACY_POLICY')) |
| terms_versions_project_definition_id_project_definitions_id_fk | FK | project_definition_id | project_definitions(id) |
<!-- generated:end -->

### document_requirements — 必要書類定義
1 行がプロジェクト定義の申込で出す書類 1 種類。申込のときにこの表から書類枠(`document_slots`、`facility` クラスタ)を作り、資料種別・必須区分を写す。

- `document_requirements_definition_document_type_unique`: 同じ定義に同じ資料種別を 2 行持たない
- `requirement_type`: 必須(`REQUIRED`)か任意(`OPTIONAL`)か。提出時に、必須の書類がすべて添付済みか「該当なし」になっていることをアプリで検証する
- `is_not_applicable_allowed`: 「該当なし」を選べるか

<!-- generated:start table=document_requirements -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト定義ID | project_definition_id | text | NOT NULL | | |
| 資料種別 | document_type | text | NOT NULL | | |
| 必須区分 | requirement_type | text | NOT NULL | | |
| 説明文 | description | text | NULL | | |
| 該当なし可否 | is_not_applicable_allowed | boolean | NOT NULL | false | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| document_requirements_definition_document_type_unique | UNIQUE | project_definition_id, document_type | |
| document_requirements_requirement_type_check | CHECK | | requirement_type in ('REQUIRED', 'OPTIONAL') |
| document_requirements_project_definition_fk | FK | project_definition_id | project_definitions(id) |
<!-- generated:end -->

## Open questions
- `recruitment_status` の値は機能要件一覧のステータス定義「プロジェクト募集状態」(準備中・募集中・募集停止・終了)から決めた。drawio には既定値 `'DRAFT'` しか無い。プロジェクト定義の作成画面は無いが、募集状態を変える画面(機能要件一覧のプロジェクト編集)を運営者コンソールに置くかは画面設計で決める
- `projects.status` の値(`ACTIVE` / `CLOSED`)は推定。drawio には既定値 `'ACTIVE'` しか無い。創出PTの利用終了でプロジェクトを閉じるのか、どの画面で変えるのかが決まっていない
- `project_code` の採番規則(桁数・文字種)が決まっていない
- `document_type` の値は CHECK で縛っていない。機能要件一覧の必要書類定義は太陽光の書類(設置日確認資料・パネル容量資料・パワコン保証書等)だけで、LED の書類が決まっていない
- 機能要件一覧にあるプロジェクトの「対象会員種別」(個人・法人)と、必要書類の「許可拡張子・容量」の列は drawio に無い。入会届が個人・法人で分かれるので、プロジェクト定義を会員種別ごとに分けるのか列で持つのかを決める
- `methodology_code` に入れる方法論の一覧が無い。プロジェクト定義はデータ投入で入れるので当面は表記をそろえて入れ、一覧が決まったら `@jcredit/shared/enums` の CHECK かマスタにする
