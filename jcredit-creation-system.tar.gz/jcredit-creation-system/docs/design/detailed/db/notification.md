# notification: 通知・問い合わせ・FAQ・メンテナンス

- Last updated: 2026-10-15
- Schema: `packages/db/schema/notification.ts`

## 概要
ユーザーへの通知(システム内通知とメール)とその既読、ユーザーと運営者の問い合わせ、FAQ、サイトごとのメンテナンスモードを持つ。
他のクラスタを参照するだけで、参照されない。通知・問い合わせが何の業務の件かは本文に書き、対象データを指す列は持たない。用語は [domain.md](../../basic/domain.md)。

## ER 図

```mermaid
erDiagram
  NOTIFICATION_TYPES ||--o{ NOTIFICATIONS : "種別"
  ADMIN_USERS |o--o{ NOTIFICATIONS : "作成者"
  PROJECTS |o--o{ NOTIFICATIONS : "配信対象プロジェクト"
  PROJECT_DEFINITIONS |o--o{ NOTIFICATIONS : "配信対象プロジェクト定義"
  MEMBERS |o--o{ INQUIRIES : "相手先会員"
  PARTNERS |o--o{ INQUIRIES : "相手先創出PT"
  ADMIN_USERS |o--o{ INQUIRIES : "担当"
  INQUIRIES ||--o{ INQUIRY_MESSAGES : "回答・返信"
  NOTIFICATIONS ||--o{ NOTIFICATION_READS : "既読"
  ADMIN_USERS |o--o{ SITE_MAINTENANCE_MODES : "切替者"
```

`ADMIN_USERS` / `MEMBERS` / `PARTNERS` は [identity](identity.md)、`PROJECTS` / `PROJECT_DEFINITIONS` は [project](project.md)。宛先・起票者・投稿者・既読にしたユーザーは種別 + ID で持つ(FK なし)。

## テーブル

### notification_types — 通知種別
1 行が、機能要件一覧の通知一覧の 1 通知(差戻し・承認・問い合わせ回答 等)。マスタで、運営者は画面から変えない。

- `delivery_destination`: メールも送るか(`EMAIL_AND_SYSTEM`)、システム内通知だけか(`SYSTEM_ONLY`)。通知ごとではなく種別で決まる。メールだけの連絡(認証 URL・パスワード再設定 等)は通知の行を作らないので種別も作らない。全体・プロジェクト参加者向けの通知はメールを送らないので、その種別は `SYSTEM_ONLY` にする([architecture.md](../../basic/architecture.md) の「メールと通知」)
- `category`: 通知一覧の分類。分類列と絞り込みに使い、3 つの Web で同じ値にする。機能要件一覧の通知一覧の分類(8 種)は絞り込みには細かいので、
  機能要件で創出PT の通知一覧のフィルターに挙がっている 4 グループにまとめる。お知らせに並べて出す問い合わせは通知種別を持たないので、画面では「問い合わせ」として扱う

| 値 | 画面の表示 | 通知一覧の分類 |
| --- | --- | --- |
| `APPLICATION` | 申請・審査 | 会員登録 / 申請 / 退会(プロジェクト退会) |
| `INQUIRY` | 問い合わせ | 問い合わせ |
| `ACCOUNT` | アカウント | 招待 / アカウント変更 / 退会(アカウント削除)/ 認証・アカウント |
| `ANNOUNCEMENT` | お知らせ | 運用(運営者が作る全体・プロジェクト参加者向けの通知を含む) |

- `notification_types_type_name_unique`: 同じ名前の種別を作らない

<!-- generated:start table=notification_types -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 分類 | category | text | NOT NULL | | |
| 通知名 | type_name | text | NOT NULL | | UNIQUE |
| 配信先 | delivery_destination | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| notification_types_category_check | CHECK | | category in ('APPLICATION', 'INQUIRY', 'ACCOUNT', 'ANNOUNCEMENT') |
| notification_types_delivery_destination_check | CHECK | | delivery_destination in ('EMAIL_AND_SYSTEM', 'SYSTEM_ONLY') |
<!-- generated:end -->

### notifications — 通知
1 行が、1 回の配信。個人向けは宛先 1 人につき 1 行作る(宛先の表は持たない)。通知には返答できない(返答が要る連絡は問い合わせで送る)。既読は個人向けなら `read_at`、全体・プロジェクト参加者向けなら `notification_reads` で持つ。メールの送信結果・エラーは AWS 側で扱い、この表には持たない。

| `audience_type` | 宛先(`recipient_user_type` + `recipient_user_id`) | `project_id` / `project_definition_id` | 誰が作るか |
| --- | --- | --- | --- |
| `ALL` | NULL | どちらも NULL | 運営者(通知作成) |
| `PROJECT` | NULL | どちらか 1 つ。創出PT ごとのプロジェクトか、創出PT をまたいだプロジェクト定義全体か | 運営者(通知作成) |
| `INDIVIDUAL` | 宛先ユーザー | どちらも NULL | システム(審査結果等)。運営者が個別に送る連絡は通知ではなく問い合わせ(`inquiries`)で作る |

- `notifications_recipient_check` / `notifications_project_check`: 上の表の組み合わせ以外を作らない
- `read_at`: 個人向けの既読日時。宛先が開いたときに入れる(`notifications_read_at_check` で個人向けだけ)。既読かどうかは NULL かで判定し、フラグは持たない
- `admin_user_id`: 運営者が作った通知はその運営ユーザー、システムの自動通知は NULL。自動か手作業かはこの列で分かるので、配信区分は持たない
- 関連する画面へのリンクは本文に書く。公開期間は持たず、配信予定日時(`scheduled_at`)になったら配信する

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `DRAFT` | 運営者が下書き保存したとき |
| — / `DRAFT` | `SCHEDULED` | 運営者が配信日時を指定して予約したとき |
| `SCHEDULED` | `DRAFT` | 運営者が予約を取り消したとき |
| `SCHEDULED` | `SENT` | 配信予定日時になって配信したとき(全体・プロジェクト参加者向けなのでメールは送らない) |
| — | `SENT` | システムが自動通知を作ったとき(`scheduled_at` は作った日時) |
| `SENT` | `WITHDRAWN` | 運営者が全体・プロジェクト参加者向けの通知の掲載をやめたとき |

- `notifications_scheduled_at_check`: 下書き以外は配信予定日時を持つ
- `notifications_withdrawn_check`: 取り下げるのは全体・プロジェクト参加者向けだけ。個人向けは配信したら取り下げない
- アプリで検証すること:
  - 下書き・予約は運営者だけが作る(`admin_user_id` が入る)。作成・編集できるのは [auth.md](../../basic/auth.md) の通知の権限を持つ運営者
  - 宛先ユーザーは、`recipient_user_type` の表に `recipient_user_id` の行がある

<!-- generated:start table=notifications -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 通知種別ID | notification_type_id | text | NOT NULL | | |
| 運営ユーザーID | admin_user_id | text | NULL | | |
| プロジェクトID | project_id | text | NULL | | |
| プロジェクト定義ID | project_definition_id | text | NULL | | |
| 件名 | subject | text | NOT NULL | | |
| 本文 | body | text | NOT NULL | | |
| 配信対象区分 | audience_type | text | NOT NULL | | |
| 宛先ユーザー種別 | recipient_user_type | text | NULL | | |
| 宛先ユーザーID | recipient_user_id | text | NULL | | |
| 状態 | status | text | NOT NULL | | |
| 配信予定日時 | scheduled_at | timestamptz | NULL | | |
| 既読日時 | read_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| notifications_notification_type_id_index | INDEX | notification_type_id | |
| notifications_admin_user_id_index | INDEX | admin_user_id | |
| notifications_project_id_index | INDEX | project_id | |
| notifications_project_definition_id_index | INDEX | project_definition_id | |
| notifications_recipient_index | INDEX | recipient_user_type, recipient_user_id | |
| notifications_audience_type_check | CHECK | | audience_type in ('ALL', 'PROJECT', 'INDIVIDUAL') |
| notifications_recipient_user_type_check | CHECK | | recipient_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| notifications_status_check | CHECK | | status in ('DRAFT', 'SCHEDULED', 'SENT', 'WITHDRAWN') |
| notifications_recipient_check | CHECK | | num_nonnulls(recipient_user_type, recipient_user_id) = case when audience_type = 'INDIVIDUAL' then 2 else 0 end |
| notifications_project_check | CHECK | | num_nonnulls(project_id, project_definition_id) = case when audience_type = 'PROJECT' then 1 else 0 end |
| notifications_scheduled_at_check | CHECK | | status = 'DRAFT' or scheduled_at is not null |
| notifications_withdrawn_check | CHECK | | status <> 'WITHDRAWN' or audience_type <> 'INDIVIDUAL' |
| notifications_read_at_check | CHECK | | audience_type = 'INDIVIDUAL' or read_at is null |
| notifications_notification_type_id_notification_types_id_fk | FK | notification_type_id | notification_types(id) |
| notifications_admin_user_id_admin_users_id_fk | FK | admin_user_id | admin_users(id) |
| notifications_project_id_projects_id_fk | FK | project_id | projects(id) |
| notifications_project_definition_id_project_definitions_id_fk | FK | project_definition_id | project_definitions(id) |
<!-- generated:end -->

### notification_reads — 通知の既読
1 行が、1 ユーザーが全体・プロジェクト参加者向けの通知を 1 件開いたこと。個人向けの通知は `notifications.read_at` で持つので、この表に行を作らない(アプリで検証)。

既読の持ち方は宛先の持ち方で分ける。個人向けの通知・問い合わせは宛先 1 人に 1 行なので、その行の列で持つ。全体・プロジェクト参加者向けは 1 行を大勢で共有するので列では持てず、ユーザー数が多いため配信のたびに全員分の行を作ることもしない。開いた人の分だけこの表に行を作る。

| 操作 | 個人向けの通知 | 全体・プロジェクト参加者向けの通知 | 問い合わせ |
| --- | --- | --- | --- |
| 開いたとき | `notifications.read_at` を入れる | この表に 1 行足す | `inquiries.recipient_last_read_at` を今にする |
| 一括既読 | そのユーザーの未読の行に `read_at` を入れる | 見えている未読の通知の分だけ行を足す | 未読の問い合わせの `recipient_last_read_at` を今にする |

- 未読:
  - 個人向けの通知: `read_at` が NULL
  - 全体・プロジェクト参加者向けの通知: 宛先に見える配信済み(`SENT`)の通知のうち、配信予定日時がそのユーザーのアカウント作成より後で、この表に行が無いもの(アカウント作成より前の通知は既読扱いにし、新しいユーザーに過去の通知を未読で出さない)
  - 問い合わせ: 運営者が投稿した最新のメッセージ(運営者の起票なら、無ければ起票)の日時が `recipient_last_read_at` より後か、`recipient_last_read_at` が NULL
- `notification_reads_user_notification_unique`: 同じ通知を同じユーザーが既読にするのは 1 回。ユーザーを先頭の列にし、未読の判定(通知ごとに行があるか)にも、ユーザー単位の削除にも効くようにする
- 全体・プロジェクト参加者向けは運営者が手で出すもので本数が少ないので、一括既読で足す行も少ない。行が増えすぎたら、表示しなくなった古い通知の行を消す

<!-- generated:start table=notification_reads -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 通知ID | notification_id | text | NOT NULL | | |
| 利用者種別 | user_type | text | NOT NULL | | |
| 利用者ID | user_id | text | NOT NULL | | |
| 既読日時 | read_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| notification_reads_user_notification_unique | UNIQUE | user_type, user_id, notification_id | |
| notification_reads_user_type_check | CHECK | | user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| notification_reads_notification_id_notifications_id_fk | FK | notification_id | notifications(id) |
<!-- generated:end -->

### inquiries — 問い合わせ
1 行が、ユーザーと運営者の個別のやり取り 1 件。会員・創出PTが起票するか、運営者が会員詳細・創出PT詳細から相手を指定して起票する。添付ファイルは付けられない(問い合わせ・回答・返信とも)。
問い合わせは利用者側の宛先の会員マイページ・創出PTマイページのお知らせ(通知一覧)に通知と並べて出し、宛先はそこから返信する。運営者が起票したものは起票したときから、利用者が起票したものは運営者が回答したときから出す。

| 起票者(`opened_by_user_type`) | 相手先(`member_id` / `partner_id`) | 宛先(`recipient_user_type` + `recipient_user_id`) |
| --- | --- | --- |
| `MEMBER` / `PARTNER` | 起票者の所属の会員・創出PT | 起票者本人(運営者の回答を受け取る人) |
| `ADMIN` | 指定した会員・創出PT | 指定した会員ユーザー・創出PTユーザー |

- `inquiries_counterpart_check`: 相手先は会員・創出PTの 1 つ以下
- `inquiries_recipient_check`: 利用者が起票したときは、宛先を起票者と同じにする。お知らせへの表示・返信・既読を、起票者が運営者か利用者かで分けず宛先(`recipient_user_type` + `recipient_user_id`)で扱うため。
  宛先はどの行にもあるので、宛先の無い行で `recipient_last_read_at` を持たせない check は要らない
- `recipient_last_read_at`: 宛先が最後に問い合わせを見た日時。お知らせの未読に使う(`notification_reads` の表)。運営者側の未対応は問い合わせ状態で見るので、運営者の既読は持たない
- `inquiry_number`: 受付番号。画面とメールでユーザーに見せる。採番規則は決めていない(Open questions)
- `inquiry_type`: 問い合わせ種別。利用者が起票するときに選び、問い合わせ履歴・一覧の絞り込みに使う。会員・創出PTで同じ値にする。
  機能要件一覧は 8 区分とするが値が無いので、このシステムの業務に合わせて決めた。運営者が起票するとき(会員詳細・創出PT詳細から送る)は選ばないので NULL

| 値 | 画面の表示 | 含むもの |
| --- | --- | --- |
| `ACCOUNT` | アカウント・ログイン | ログイン・二段階認証・パスワード・メールアドレス・ユーザーの招待 |
| `REGISTRATION` | 登録情報 | 会員登録・会員基本情報・創出PT情報 |
| `PROJECT` | プロジェクト・募集 | プロジェクトの内容・募集期・参加申請 |
| `APPLICATION` | 申込・審査 | 申込の入力・証跡書類・設備・審査結果・代理入力 |
| `WITHDRAWAL` | 退会 | 会員退会・プロジェクト退会・ユーザーの削除 |
| `SYSTEM` | システムの操作・不具合 | 画面の使い方・エラー |
| `OTHER` | その他 | 上のどれにも当たらないもの |

- `inquiries_inquiry_type_required_check`: 利用者が起票したときは問い合わせ種別を必須にする
- `assigned_admin_user_id`: 担当の運営者。受付のときは NULL

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `OPEN` | 起票したとき |
| `OPEN` | `IN_PROGRESS` | 運営者が担当を割り当てたとき |
| `IN_PROGRESS` | `ANSWERED` | 運営者が回答を送ったとき |
| `ANSWERED` | `IN_PROGRESS` | 宛先が返信したとき(運営者の対応待ちに戻す) |
| `ANSWERED` | `COMPLETED` | 運営者がクローズしたとき、または一定期間が経ったとき |

- 完了したかどうかは状態(`COMPLETED`)で表し、完了日時の列は持たない
- アプリで検証すること:
  - 相手先は起票者・宛先の所属と同じ(会員ユーザーなら `member_id`、創出PTユーザーなら `partner_id`)
  - 担当者を割り当てられるのは運営者だけ

<!-- generated:start table=inquiries -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 受付番号 | inquiry_number | text | NOT NULL | | UNIQUE |
| 相手先会員ID | member_id | text | NULL | | |
| 相手先創出PT ID | partner_id | text | NULL | | |
| 担当者ID | assigned_admin_user_id | text | NULL | | |
| 問い合わせ種別 | inquiry_type | text | NULL | | |
| 件名 | subject | text | NOT NULL | | |
| 本文 | body | text | NOT NULL | | |
| 問い合わせ状態 | inquiry_status | text | NOT NULL | 'OPEN' | |
| 起票者種別 | opened_by_user_type | text | NOT NULL | | |
| 起票者ID | opened_by_user_id | text | NOT NULL | | |
| 宛先ユーザー種別 | recipient_user_type | text | NOT NULL | | |
| 宛先ユーザーID | recipient_user_id | text | NOT NULL | | |
| 宛先の最終既読日時 | recipient_last_read_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| inquiries_member_id_index | INDEX | member_id | |
| inquiries_partner_id_index | INDEX | partner_id | |
| inquiries_assigned_admin_user_id_index | INDEX | assigned_admin_user_id | |
| inquiries_opened_by_index | INDEX | opened_by_user_type, opened_by_user_id | |
| inquiries_recipient_index | INDEX | recipient_user_type, recipient_user_id | |
| inquiries_inquiry_type_check | CHECK | | inquiry_type in ('ACCOUNT', 'REGISTRATION', 'PROJECT', 'APPLICATION', 'WITHDRAWAL', 'SYSTEM', 'OTHER') |
| inquiries_inquiry_status_check | CHECK | | inquiry_status in ('OPEN', 'IN_PROGRESS', 'ANSWERED', 'COMPLETED') |
| inquiries_opened_by_user_type_check | CHECK | | opened_by_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| inquiries_recipient_user_type_check | CHECK | | recipient_user_type in ('MEMBER', 'PARTNER') |
| inquiries_counterpart_check | CHECK | | num_nonnulls(member_id, partner_id) <= 1 |
| inquiries_inquiry_type_required_check | CHECK | | opened_by_user_type = 'ADMIN' or inquiry_type is not null |
| inquiries_recipient_check | CHECK | | opened_by_user_type = 'ADMIN' or (recipient_user_type = opened_by_user_type and recipient_user_id = opened_by_user_id) |
| inquiries_member_id_members_id_fk | FK | member_id | members(id) |
| inquiries_partner_id_partners_id_fk | FK | partner_id | partners(id) |
| inquiries_assigned_admin_user_id_admin_users_id_fk | FK | assigned_admin_user_id | admin_users(id) |
<!-- generated:end -->

### inquiry_messages — 問い合わせメッセージ
1 行が、問い合わせへの 1 回の回答・返信。追記だけで、送信後に編集・削除しない。起票時の本文は `inquiries.body` に持ち、この表には 2 通目から積む。

- `posted_by_user_type` + `posted_by_user_id`: 投稿した人。運営者の回答と、起票者・宛先の返信が同じ表に並ぶ
- `posted_at`: 投稿日時。並び順はこの列で決める
- アプリで検証すること: 運営者以外が投稿できるのは、問い合わせの起票者か宛先、またはその所属の会員管理者(会員管理者は会員全体の問い合わせを見られる)

<!-- generated:start table=inquiry_messages -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 問い合わせID | inquiry_id | text | NOT NULL | | |
| 投稿者種別 | posted_by_user_type | text | NOT NULL | | |
| 投稿者ID | posted_by_user_id | text | NOT NULL | | |
| 本文 | body | text | NOT NULL | | |
| 投稿日時 | posted_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| inquiry_messages_inquiry_id_posted_at_index | INDEX | inquiry_id, posted_at | |
| inquiry_messages_posted_by_user_type_check | CHECK | | posted_by_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| inquiry_messages_inquiry_id_inquiries_id_fk | FK | inquiry_id | inquiries(id) |
<!-- generated:end -->

### faqs — FAQ
1 行が、質問と回答 1 組。内容はシステム固定で、運営者が画面から編集する機能は無い。カテゴリは持たない(FAQ の画面はキーワード検索と質問の一覧だけで、件数も少ない)。

- `audience_scope`: どのサイトに出すか。`COMMON` は会員マイページ・創出PTマイページの両方、`MEMBER` / `PARTNER` は片方だけ

<!-- generated:start table=faqs -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 質問 | question | text | NOT NULL | | |
| 回答 | answer | text | NOT NULL | | |
| 公開先区分 | audience_scope | text | NOT NULL | 'COMMON' | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| faqs_audience_scope_check | CHECK | | audience_scope in ('COMMON', 'MEMBER', 'PARTNER') |
<!-- generated:end -->

### site_maintenance_modes — メンテナンスモード
1 行が、1 つのサイトの今のメンテナンス状態。会員マイページと創出PTマイページの 2 行だけで、運営者コンソールは対象外。運営管理者が手動で ON / OFF し、予定による自動切替はしない。

- `site_maintenance_modes_target_site_unique`: サイトごとに 1 行。切り替えるときは行を足さず更新する
- `site_maintenance_modes_starts_at_check`: メンテナンス中は開始日時を持つ
- `site_maintenance_modes_period_check`: 終了予定は開始より後。どちらかが NULL(未設定)のときは比べない
- `ends_at`: 終了予定日時。メンテナンス画面に出すだけで、過ぎても自動で OFF にしない
- `display_text`: メンテナンス画面に出す告知文
- `switched_by_admin_user_id`: 最後に切り替えた運営者。切替履歴は持たない(AWS のログで追う)

<!-- generated:start table=site_maintenance_modes -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 対象サイト | target_site | text | NOT NULL | | |
| メンテナンス中フラグ | is_under_maintenance | boolean | NOT NULL | false | |
| 表示テキスト | display_text | text | NULL | | |
| 開始日時 | starts_at | timestamptz | NULL | | |
| 終了日時 | ends_at | timestamptz | NULL | | |
| 切替者ID | switched_by_admin_user_id | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| site_maintenance_modes_target_site_unique | UNIQUE | target_site | |
| site_maintenance_modes_switched_by_admin_user_id_index | INDEX | switched_by_admin_user_id | |
| site_maintenance_modes_target_site_check | CHECK | | target_site in ('MEMBER_PORTAL', 'PARTNER_CONSOLE') |
| site_maintenance_modes_starts_at_check | CHECK | | not is_under_maintenance or starts_at is not null |
| site_maintenance_modes_period_check | CHECK | | ends_at > starts_at |
| site_maintenance_modes_switched_by_fk | FK | switched_by_admin_user_id | admin_users(id) |
<!-- generated:end -->

## Open questions
- 全体向け(`ALL`)が全会員か、全会員と創出PT の両方か。機能要件一覧の通知作成は「全会員／プロジェクト単位／創出PT／個別」を挙げており、創出PT 全体向けを区分で分けられない
- 自動通知を送るとき、通知種別をどう引くか。drawio の命名ルールでコード列を持たないので、通知一覧の通知 ID を列に持つか、通知名の一意で引くかを決める
- 通知の分類・問い合わせ種別の値と、FAQ をカテゴリで分けないこと(機能要件では「カテゴリ別」)は、先方に確認していない
- 問い合わせの受付番号の採番規則
- 回答に付ける内部メモを持つか
- FAQ の表示順・関連 FAQ・退会申請への導線のモードを持つ列が無い
- メンテナンス予定の登録(開始 / 終了日時・告知文の登録・更新・削除)を、今の 1 サイト 1 行で足りるとするか
