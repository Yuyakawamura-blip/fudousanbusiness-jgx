# identity: 組織(会員・創出PT)と創出PTの支部、ユーザー・ロール

- Last updated: 2026-10-15
- Schema: `packages/db/schema/identity.ts`

## 概要
3 種類の利用者区分(会員・創出PT・運営者)の組織と、区分ごとのユーザー表、ロールを持つ。
運営者の組織の表は無い(運営組織ごとに閲覧・操作範囲を分けないため)。商工会議所の創出PTの支部のマスタもここに置く(`partners` を参照し、参加申請 `participation_requests` から参照されるため)。招待は `invitation`、会員基本情報申請・創出PT情報申請は `review` クラスタが持つ。
誰が何をできるかは [auth.md](../../basic/auth.md)、用語は [domain.md](../../basic/domain.md)。

## ER 図

```mermaid
erDiagram
  PARTNERS ||--o{ PARTNER_BRANCHES : "支部を持つ(商工会議所)"
  PARTNERS ||--o{ PARTNER_USERS : "所属する"
  MEMBERS ||--|{ MEMBER_USERS : "所属する"
  MEMBER_USERS ||--o{ MEMBER_USER_ROLES : "持つ"
  PARTNER_USERS ||--o{ PARTNER_USER_ROLES : "持つ"
  ADMIN_USERS ||--o{ ADMIN_USER_ROLES : "持つ"
  ROLES ||--o{ MEMBER_USER_ROLES : "付与される"
  ROLES ||--o{ PARTNER_USER_ROLES : "付与される"
  ROLES ||--o{ ADMIN_USER_ROLES : "付与される"
```

## テーブル

### members — 会員
1 行が 1 会員(法人または個人)。会員募集の流れでは、メールアドレス登録(仮登録)の時点で、`member_status = 'PRE_REGISTERED'` の行と、メールアドレスだけを入れた会員ユーザーを作る。仮登録用の表は持たない。
確認 URL のトークン・有効期限・再送回数は認証基盤が持つ。仮登録のまま 7 日過ぎた行は、日次バッチで会員ユーザーごと物理削除する。

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `PRE_REGISTERED` | 会員募集からメールアドレスを登録したとき |
| `PRE_REGISTERED` / —(招待から登録) | `PROVISIONAL` | アカウント作成・基本情報登録を終えたとき |
| `PROVISIONAL` | `ACTIVE` | 運営者が登録内容を確認したとき(承認待ちの参加申請を同じトランザクションでプロジェクトに紐づける。[application](application.md)) |
| `PROVISIONAL` / `ACTIVE` | `WITHDRAWN` | 会員管理者が会員退会したとき |

仮会員(`PROVISIONAL`)でも会員マイページの画面は使える。見られないのはプロジェクトの情報などだけで、その判定はアプリ側で行う。

- `members_registered_fields_check`: 仮登録の間はメールアドレスしか無いので、会員種別・住所・電話番号・代表者の氏名(フリガナを含む)を NULL のまま許す。仮登録を抜けたら必須。代表者の氏名は個人会員にも要る(本人の氏名を入れる)
- `members_corporate_name_check`: 法人会員は法人名が必須。個人会員は法人名・代表者役職を持たない。一覧・検索で使う「会員名」は、法人名または代表者の姓 + 名から組み立てる
- `brand_type`: どの会員募集(一般・東京商工会議所・日本商工会議所)から登録したか。画面の表示ブランドを切り替える
- `acquisition_channel`: 流入経路。本人には入力させず、登録の経路(どの会員募集・誰の招待から来たか)からアプリが決める。仮登録の時点で決まるので必須
- `prefecture`: 47 都道府県名のどれかであることはアプリで検証する。郵便番号から都道府県・市区町村・町名までを補完し、番地以降と建物名は手入力

<!-- generated:start table=members -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員種別 | member_type | text | NULL | | |
| 会員状態 | member_status | text | NOT NULL | 'PRE_REGISTERED' | |
| 法人名 | corporate_name | text | NULL | | |
| 法人名フリガナ | corporate_name_kana | text | NULL | | |
| 代表者役職 | representative_title | text | NULL | | |
| 代表者の姓 | representative_last_name | text | NULL | | |
| 代表者の名 | representative_first_name | text | NULL | | |
| 代表者の姓フリガナ | representative_last_name_kana | text | NULL | | |
| 代表者の名フリガナ | representative_first_name_kana | text | NULL | | |
| 法人番号 | corporate_number | text | NULL | | |
| 郵便番号 | postal_code | text | NULL | | |
| 都道府県 | prefecture | text | NULL | | |
| 市区町村 | city | text | NULL | | |
| 町名・番地 | street_address | text | NULL | | |
| 建物名・部屋番号 | building_name | text | NULL | | |
| 代表電話番号 | representative_phone_number | text | NULL | | |
| 代表メールアドレス | representative_contact_email | text | NULL | | |
| FAX番号 | fax_number | text | NULL | | |
| 表示ブランド区分 | brand_type | text | NOT NULL | 'GENERAL' | |
| 流入経路 | acquisition_channel | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| members_member_type_check | CHECK | | member_type in ('INDIVIDUAL', 'CORPORATE') |
| members_member_status_check | CHECK | | member_status in ('PRE_REGISTERED', 'PROVISIONAL', 'ACTIVE', 'WITHDRAWN') |
| members_brand_type_check | CHECK | | brand_type in ('GENERAL', 'TOKYO_CCI', 'JCCI') |
| members_registered_fields_check | CHECK | | member_status = 'PRE_REGISTERED' or (member_type is not null and postal_code is not null and prefecture is not null and city is not null and street_address is not null and representative_phone_number is not null and representative_last_name is not null and representative_first_name is not null and representative_last_name_kana is not null and representative_first_name_kana is not null) |
| members_corporate_name_check | CHECK | | (member_type is distinct from 'CORPORATE' or member_status = 'PRE_REGISTERED' or corporate_name is not null) and (member_type is distinct from 'INDIVIDUAL' or (corporate_name is null and representative_title is null)) |
<!-- generated:end -->

### partners — 創出PT
1 行が 1 創出PT。運営者が登録し、その管理者を `partner_invitations` で招待する。

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `INVITED` | 運営者が登録し、管理者を招待したとき |
| `INVITED` | `ACTIVE` | 管理者が招待を受けてアカウントを作ったとき |
| `ACTIVE` | `TERMINATED` | 運営者が利用を終了したとき |

- `partners_termination_check`: 利用終了日時・利用終了理由は、利用終了(`TERMINATED`)のときだけ両方入る

<!-- generated:start table=partners -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 組織名 | name | text | NULL | | |
| 組織名フリガナ | name_kana | text | NULL | | |
| 郵便番号 | postal_code | text | NULL | | |
| 都道府県 | prefecture | text | NULL | | |
| 市区町村 | city | text | NULL | | |
| 町名・番地 | street_address | text | NULL | | |
| 建物名・部屋番号 | building_name | text | NULL | | |
| 代表電話番号 | representative_phone_number | text | NULL | | |
| 代表メールアドレス | representative_contact_email | text | NULL | | |
| 担当者名 | contact_person_name | text | NULL | | |
| 創出PT利用状態 | partner_status | text | NOT NULL | 'ACTIVE' | |
| 利用終了日時 | terminated_at | timestamptz | NULL | | |
| 利用終了理由 | termination_reason | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partners_partner_status_check | CHECK | | partner_status in ('INVITED', 'ACTIVE', 'TERMINATED') |
| partners_termination_check | CHECK | | (partner_status = 'TERMINATED') = (terminated_at is not null and termination_reason is not null) |
<!-- generated:end -->

### partner_branches — 創出PTの支部
1 行が、商工会議所の創出PTの 1 つの支部(区・支部)。画面は持たず、データ投入で入れる。支部の行がある創出PTが商工会議所の創出PTで、普通の創出PTは行を持たない。
その創出PTのプロジェクトへ参加申請する会員が、支部を一覧から選ぶ([application](application.md) の `participation_requests.partner_branch_id`)。自由入力にしない(創出PTが支部ごとに並べ替え・絞り込みするので、表記を揃えるため)。

- 1 つの商工会議所で数百、全体で数千行を想定する。どれも `partner_id` で絞って引くので、一意制約 `(partner_id, branch_name)` のインデックスで足りる(商工会議所ごとに表を分けない)
- 選択肢と絞り込みは `id` の順に並べる。`id` は UUIDv7 なので、データ投入で入れた順になる(並び順の列は持たない)
- `partner_branches_partner_branch_name_unique`: 同じ創出PTに同じ名前の支部を 2 つ作らない

<!-- generated:start table=partner_branches -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTID | partner_id | text | NOT NULL | | |
| 支部名 | branch_name | text | NOT NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partner_branches_partner_branch_name_unique | UNIQUE | partner_id, branch_name | |
| partner_branches_partner_id_partners_id_fk | FK | partner_id | partners(id) |
<!-- generated:end -->

### member_users / partner_users / admin_users — ユーザー
1 行が 1 ユーザー。3 表は同じ列を持ち、所属先の列だけが違う(運営ユーザーは所属先を持たない)。
会員ユーザー以外は招待を受けてアカウントを作るときに行を作るので、`auth_subject_id`(認証基盤のユーザー ID)は必須。
会員ユーザーは仮登録の時点で行を作り、パスワードを設定するまで `auth_subject_id` が NULL になる。

- 削除は論理削除(`deleted_at`)。削除したら `email` を NULL にして、同じメールアドレスで登録し直せるようにする。`email` の一意制約は NULL を重複とみなさない
- `pending_email`: メールアドレス変更の確認が済むまでの新しいアドレス。確認が済んだら `email` に移す
- ロック中は `account_status` に持たず、`locked_until` が現在時刻より後かどうかで判定する(時間が経てば自動で解除されるため)。`failed_login_count` はロックの判定に使う連続失敗回数
- `is_email_undeliverable`: メールが届かなかったとき立てる。メールの送信結果自体は AWS 側で持つ

<!-- generated:start table=member_users -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員ID | member_id | text | NOT NULL | | |
| 認証サブジェクトID | auth_subject_id | text | NULL | | UNIQUE |
| メールアドレス | email | text | NULL | | UNIQUE |
| 変更確認中の新メールアドレス | pending_email | text | NULL | | |
| 電話番号 | phone_number | text | NULL | | |
| 姓 | last_name | text | NULL | | |
| 名 | first_name | text | NULL | | |
| 姓フリガナ | last_name_kana | text | NULL | | |
| 名フリガナ | first_name_kana | text | NULL | | |
| 所属 | department | text | NULL | | |
| アカウント状態 | account_status | text | NOT NULL | 'ACTIVE' | |
| メール不達フラグ | is_email_undeliverable | boolean | NOT NULL | false | |
| ログイン連続失敗回数 | failed_login_count | integer | NOT NULL | 0 | |
| ロック解除日時 | locked_until | timestamptz | NULL | | |
| 最終ログイン日時 | last_login_at | timestamptz | NULL | | |
| 有効化日時 | activated_at | timestamptz | NULL | | |
| 削除日時 | deleted_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| member_users_member_id_index | INDEX | member_id | |
| member_users_account_status_check | CHECK | | account_status in ('ACTIVE', 'DISABLED') |
| member_users_member_id_members_id_fk | FK | member_id | members(id) |
<!-- generated:end -->

<!-- generated:start table=partner_users -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTID | partner_id | text | NOT NULL | | |
| 認証サブジェクトID | auth_subject_id | text | NOT NULL | | UNIQUE |
| メールアドレス | email | text | NULL | | UNIQUE |
| 変更確認中の新メールアドレス | pending_email | text | NULL | | |
| 電話番号 | phone_number | text | NULL | | |
| 姓 | last_name | text | NULL | | |
| 名 | first_name | text | NULL | | |
| 姓フリガナ | last_name_kana | text | NULL | | |
| 名フリガナ | first_name_kana | text | NULL | | |
| 所属 | department | text | NULL | | |
| アカウント状態 | account_status | text | NOT NULL | 'ACTIVE' | |
| メール不達フラグ | is_email_undeliverable | boolean | NOT NULL | false | |
| ログイン連続失敗回数 | failed_login_count | integer | NOT NULL | 0 | |
| ロック解除日時 | locked_until | timestamptz | NULL | | |
| 最終ログイン日時 | last_login_at | timestamptz | NULL | | |
| 有効化日時 | activated_at | timestamptz | NULL | | |
| 削除日時 | deleted_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partner_users_partner_id_index | INDEX | partner_id | |
| partner_users_account_status_check | CHECK | | account_status in ('ACTIVE', 'DISABLED') |
| partner_users_partner_id_partners_id_fk | FK | partner_id | partners(id) |
<!-- generated:end -->

<!-- generated:start table=admin_users -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 認証サブジェクトID | auth_subject_id | text | NOT NULL | | UNIQUE |
| メールアドレス | email | text | NULL | | UNIQUE |
| 変更確認中の新メールアドレス | pending_email | text | NULL | | |
| 電話番号 | phone_number | text | NULL | | |
| 姓 | last_name | text | NULL | | |
| 名 | first_name | text | NULL | | |
| 姓フリガナ | last_name_kana | text | NULL | | |
| 名フリガナ | first_name_kana | text | NULL | | |
| 所属 | department | text | NULL | | |
| アカウント状態 | account_status | text | NOT NULL | 'ACTIVE' | |
| メール不達フラグ | is_email_undeliverable | boolean | NOT NULL | false | |
| ログイン連続失敗回数 | failed_login_count | integer | NOT NULL | 0 | |
| ロック解除日時 | locked_until | timestamptz | NULL | | |
| 最終ログイン日時 | last_login_at | timestamptz | NULL | | |
| 有効化日時 | activated_at | timestamptz | NULL | | |
| 削除日時 | deleted_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| admin_users_account_status_check | CHECK | | account_status in ('ACTIVE', 'DISABLED') |
<!-- generated:end -->

### roles — ロール
`MANAGER`(管理者)と `STAFF`(担当者)の 2 行だけのマスタ。利用者区分で共通。

<!-- generated:start table=roles -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| ロール名 | role_name | text | NOT NULL | | UNIQUE |
| 説明 | description | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| roles_role_name_check | CHECK | | role_name in ('MANAGER', 'STAFF') |
<!-- generated:end -->

### member_user_roles / partner_user_roles / admin_user_roles — ユーザーのロール
1 行がユーザー 1 人へのロール 1 つの付与。1 人 1 ロールで、ロールを変えるときは `role_id` を書き換えて `assigned_at` を更新する。
運営者の一次チェック・二次チェックの担当を分ける必要が出たら、ロールを足して表す。

<!-- generated:start table=member_user_roles -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員ユーザーID | member_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| 付与日時 | assigned_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| member_user_roles_user_role_unique | UNIQUE | member_user_id, role_id | |
| member_user_roles_member_user_id_member_users_id_fk | FK | member_user_id | member_users(id) |
| member_user_roles_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

<!-- generated:start table=partner_user_roles -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTユーザーID | partner_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| 付与日時 | assigned_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partner_user_roles_user_role_unique | UNIQUE | partner_user_id, role_id | |
| partner_user_roles_partner_user_id_partner_users_id_fk | FK | partner_user_id | partner_users(id) |
| partner_user_roles_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

<!-- generated:start table=admin_user_roles -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 運営ユーザーID | admin_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| 付与日時 | assigned_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| admin_user_roles_user_role_unique | UNIQUE | admin_user_id, role_id | |
| admin_user_roles_admin_user_id_admin_users_id_fk | FK | admin_user_id | admin_users(id) |
| admin_user_roles_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

## Open questions
- `members.corporate_number` に一意制約が無い。同じ法人番号は 2 回登録できず、退会した会員の番号では登録し直せる([api-usecases/member.md](../../basic/api-usecases/member.md) の「法人番号での重複の確認」)ので、退会(`WITHDRAWN`)を除く部分一意制約を schema に足す(DB の変更なので別の PR で行う)
- `brand_type` の値(`GENERAL` / `TOKYO_CCI` / `JCCI`)は会員募集の 3 種から決めた。drawio には既定値 `'GENERAL'` しか無い
- 創出PTの組織名・住所などは NULL を許している(drawio の「条件付き必須」)。どの状態から必須にするかは、運営者コンソールの登録画面の設計で決める
- 支部はプロジェクトの創出PTだけで決め、`brand_type`(どの会員募集から来たか)は見ない。東京商工会議所の会員募集から来てプロジェクトコードを入れなかった人は支部を持たないが、それでよいか
- 支部が廃止・統合されたときの扱い(選択肢から外す列を足すか、その支部の参加申請を付け替えるか)。今は消さずに残す前提で、選択肢から外す手段が無い
- 商工会議所に創出PTが 2 つ以上あるときは、創出PTごとに同じ支部の行を入れる(商工会議所という区分は持たない)。商工会議所ごとに会員を集計する画面が要るなら、商工会議所の表を足す
- 1 人 1 ロールは DB では縛らず(一意制約は (ユーザー, ロール))、アプリで守る。ロール表の `role_id` がそのユーザー区分に使えるロールかも、アプリで検証する
