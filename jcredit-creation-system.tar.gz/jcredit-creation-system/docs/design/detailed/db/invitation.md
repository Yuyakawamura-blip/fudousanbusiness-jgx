# invitation: 招待

- Last updated: 2026-10-15
- Schema: `packages/db/schema/invitation.ts`

## 概要
ユーザーになる人をメールで招く招待を、招く相手の種類ごとに 3 表で持つ。誰が誰を招待できるかは [auth.md](../../basic/auth.md) の「招待」、用語は [domain.md](../../basic/domain.md)。
招待を受けて作るユーザー・組織は [identity](identity.md)、会員の招待から作る参加申請は [application](application.md) が持つ。

## ER 図

```mermaid
erDiagram
  MEMBERS |o--o{ MEMBER_INVITATIONS : "招待先(担当者)・登録で作成"
  PROJECTS |o--o{ MEMBER_INVITATIONS : "参加先(新規会員)"
  PARTNERS ||--o{ PARTNER_INVITATIONS : "招待先"
  ADMIN_USERS ||--o{ ADMIN_INVITATIONS : "招待元"
  ROLES ||--o{ MEMBER_INVITATIONS : "付与する"
  ROLES ||--o{ PARTNER_INVITATIONS : "付与する"
  ROLES ||--o{ ADMIN_INVITATIONS : "付与する"
```

`PROJECTS` は [project](project.md)、招待以外のほかの表は [identity](identity.md)。

## 3 表に共通の決まり

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `INVITED` | 招待したとき |
| `INVITED` | `REGISTERED` | 招かれた人がアカウントを作ったとき(`registration_completed_at` を入れる) |
| `INVITED` | `CANCELLED` | 招待元が取り消したとき |

- 期限切れは状態に持たず、`expires_at` が現在時刻より前かどうかで判定する(時間が経てば何もしなくても期限切れになるため。ユーザーのロック中と同じ)
- `expires_at` は招待日時 + 14 日をアプリで入れる
- 再送は同じ行の `token_hash` を新しいトークンで上書きし、`invited_at` と `expires_at` を入れ直す。期限切れの招待も再送で `INVITED` のまま使える
- `token_hash`: 招待 URL のトークンのハッシュ。トークンそのものは持たない
- `*_registration_check`: 登録完了日時は `REGISTERED` のときだけ入る
- `role_id` が招待の種類に合うユーザー用のロールかは、アプリで検証する
- `invited_by_user_type` + `invited_by_user_id`: 招待元のユーザー。ユーザー表が種別ごとに分かれていて FK を張れないので、種別 + ID で持つ。招待元になれる種別を表ごとに CHECK で縛る

## テーブル

### member_invitations — 会員招待
1 行が 1 人の会員ユーザーになる人の招待。2 種類ある。

| 招待 | 招待元 | `member_id` | `project_id` |
| --- | --- | --- | --- |
| 担当者の招待 | 会員ユーザー(会員管理者) | 招待元の会員(必須) | NULL |
| プロジェクトへの招待 | 創出PTユーザー | 受け入れまでは NULL。新規登録なら作った会員、既存会員のログインならその会員を入れる | 参加先のプロジェクト(必須) |

- `member_invitations_target_check`: 上の表の必須・NULL を DB で縛る。運営者は会員を招待しない(`member_invitations_invited_by_user_type_check`)
- 招待元が創出PTユーザーのとき、参加先のプロジェクトは所属する創出PTのものであることをアプリで検証する。招待元が会員ユーザーのときは、`member_id` がその会員であること
- プロジェクトへの招待は、招待した人には新規会員か既存会員かを選ばせない。招待先のメールアドレスの会員ユーザーが既にいるかをシステムが確かめ、いればログインへのリンク、いなければアカウント作成へのリンクを送る
  - 新規登録: 登録完了と同じトランザクションで、会員・会員ユーザーと承認待ち(`PENDING`)の参加申請を作る。会員は仮会員なので、運営者が会員登録を承認するまで創出PTには見えない。`role_id`(会員管理者)はこのとき使う
  - 既存会員のログイン: ログインへのリンクからログインした会員ユーザーの会員から参加申請を作る。本会員ならその場で紐づき(`LINKED`)、仮会員なら承認待ち(`PENDING`)。会員ユーザーは作らないので `role_id` は使わない。
    ログインした会員ユーザーのメールアドレスが `invitee_email` と同じときだけ受け入れる(ロールは問わず、会員担当者でもよい)
- プロジェクトへの招待を `REGISTERED` にするときに `member_id` を入れることは、DB では縛らずアプリで守る(受け入れと同じトランザクションで入れる)

<!-- generated:start table=member_invitations -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員ID | member_id | text | NULL | | |
| プロジェクトID | project_id | text | NULL | | |
| 招待元ユーザー種別 | invited_by_user_type | text | NOT NULL | | |
| 招待元ユーザーID | invited_by_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| URLトークン | token_hash | text | NOT NULL | | |
| 招待先メールアドレス | invitee_email | text | NOT NULL | | |
| 招待先の姓 | invitee_last_name | text | NULL | | |
| 招待先の名 | invitee_first_name | text | NULL | | |
| 招待先の姓フリガナ | invitee_last_name_kana | text | NULL | | |
| 招待先の名フリガナ | invitee_first_name_kana | text | NULL | | |
| 招待日時 | invited_at | timestamptz | NOT NULL | now() | |
| 有効期限 | expires_at | timestamptz | NOT NULL | | |
| ステータス | status | text | NOT NULL | 'INVITED' | |
| 登録完了日時 | registration_completed_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| member_invitations_token_hash_unique | UNIQUE | token_hash | |
| member_invitations_member_id_index | INDEX | member_id | |
| member_invitations_project_id_index | INDEX | project_id | |
| member_invitations_invited_by_user_type_check | CHECK | | invited_by_user_type in ('MEMBER', 'PARTNER') |
| member_invitations_status_check | CHECK | | status in ('INVITED', 'REGISTERED', 'CANCELLED') |
| member_invitations_registration_check | CHECK | | (status = 'REGISTERED') = (registration_completed_at is not null) |
| member_invitations_target_check | CHECK | | case when invited_by_user_type = 'MEMBER' then member_id is not null and project_id is null else project_id is not null end |
| member_invitations_member_id_members_id_fk | FK | member_id | members(id) |
| member_invitations_project_id_projects_id_fk | FK | project_id | projects(id) |
| member_invitations_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

### partner_invitations — 創出PT招待
1 行が 1 人の創出PTユーザーになる人の招待。

- 招待元が運営者のときは、創出PTを登録したときの創出PT管理者の招待
- 招待元が創出PTユーザーのときは、所属する創出PTであることをアプリで検証する

<!-- generated:start table=partner_invitations -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTID | partner_id | text | NOT NULL | | |
| 招待元ユーザー種別 | invited_by_user_type | text | NOT NULL | | |
| 招待元ユーザーID | invited_by_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| URLトークン | token_hash | text | NOT NULL | | |
| 招待先メールアドレス | invitee_email | text | NOT NULL | | |
| 招待先の姓 | invitee_last_name | text | NULL | | |
| 招待先の名 | invitee_first_name | text | NULL | | |
| 招待先の姓フリガナ | invitee_last_name_kana | text | NULL | | |
| 招待先の名フリガナ | invitee_first_name_kana | text | NULL | | |
| 招待日時 | invited_at | timestamptz | NOT NULL | now() | |
| 有効期限 | expires_at | timestamptz | NOT NULL | | |
| ステータス | status | text | NOT NULL | 'INVITED' | |
| 登録完了日時 | registration_completed_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partner_invitations_token_hash_unique | UNIQUE | token_hash | |
| partner_invitations_partner_id_index | INDEX | partner_id | |
| partner_invitations_invited_by_user_type_check | CHECK | | invited_by_user_type in ('PARTNER', 'ADMIN') |
| partner_invitations_status_check | CHECK | | status in ('INVITED', 'REGISTERED', 'CANCELLED') |
| partner_invitations_registration_check | CHECK | | (status = 'REGISTERED') = (registration_completed_at is not null) |
| partner_invitations_partner_id_partners_id_fk | FK | partner_id | partners(id) |
| partner_invitations_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

### admin_invitations — 運営者招待
1 行が 1 人の運営ユーザーになる人の招待。`admin_user_id` は招待元の運営ユーザー(運営管理者)で、招待先ではない。運営ユーザーだけが招待元なので種別は持たない。

<!-- generated:start table=admin_invitations -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 運営ユーザーID | admin_user_id | text | NOT NULL | | |
| ロールID | role_id | text | NOT NULL | | |
| URLトークン | token_hash | text | NOT NULL | | |
| 招待先メールアドレス | invitee_email | text | NOT NULL | | |
| 招待先の姓 | invitee_last_name | text | NULL | | |
| 招待先の名 | invitee_first_name | text | NULL | | |
| 招待先の姓フリガナ | invitee_last_name_kana | text | NULL | | |
| 招待先の名フリガナ | invitee_first_name_kana | text | NULL | | |
| 招待日時 | invited_at | timestamptz | NOT NULL | now() | |
| 有効期限 | expires_at | timestamptz | NOT NULL | | |
| ステータス | status | text | NOT NULL | 'INVITED' | |
| 登録完了日時 | registration_completed_at | timestamptz | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| admin_invitations_token_hash_unique | UNIQUE | token_hash | |
| admin_invitations_admin_user_id_index | INDEX | admin_user_id | |
| admin_invitations_status_check | CHECK | | status in ('INVITED', 'REGISTERED', 'CANCELLED') |
| admin_invitations_registration_check | CHECK | | (status = 'REGISTERED') = (registration_completed_at is not null) |
| admin_invitations_admin_user_id_admin_users_id_fk | FK | admin_user_id | admin_users(id) |
| admin_invitations_role_id_roles_id_fk | FK | role_id | roles(id) |
<!-- generated:end -->

## Open questions
- 同じメールアドレスに有効な招待が複数ある状態を許すか(同じ人を別の創出PTから招待する等)。DB では縛っていない。許さないなら `status = 'INVITED'` の部分一意インデックスを API の実装前に足す
- 招待元(`invited_by_user_type`, `invited_by_user_id`)のインデックスは張っていない。「自分が出した招待の一覧」が要るかは画面設計で決める
