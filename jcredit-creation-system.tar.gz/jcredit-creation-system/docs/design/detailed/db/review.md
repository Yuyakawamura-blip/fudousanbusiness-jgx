# review: 審査・登録内容の申請

- Last updated: 2026-10-15
- Schema: `packages/db/schema/review.ts`

## 概要
運営者の審査(`reviews`)と、運営者が確認する登録内容の申請 2 つ(会員基本情報申請・創出PT情報申請)を持つ。審査は申込の提出版と、2 つの申請の両方を判定する。
申込そのもの・提出版は [application](application.md)、会員・創出PT の今の登録内容は [identity](identity.md) が持つ。用語は [domain.md](../../basic/domain.md)。

## ER 図

```mermaid
erDiagram
  APPLICATION_SUBMISSIONS |o--o{ REVIEWS : "一次・二次の審査"
  ADMIN_USERS ||--o{ REVIEWS : "審査者"
  MEMBERS ||--o{ MEMBER_BASIC_INFO_REQUESTS : "申請対象"
  MEMBER_USERS ||--o{ MEMBER_BASIC_INFO_REQUESTS : "申請者"
  REVIEWS |o--o| MEMBER_BASIC_INFO_REQUESTS : "確認結果"
  PARTNERS ||--o{ PARTNER_INFO_REQUESTS : "申請対象"
  PARTNER_USERS ||--o{ PARTNER_INFO_REQUESTS : "申請者"
  REVIEWS |o--o| PARTNER_INFO_REQUESTS : "判定結果"
```

`APPLICATION_SUBMISSIONS` は [application](application.md)、`ADMIN_USERS` / `MEMBERS` / `MEMBER_USERS` / `PARTNERS` / `PARTNER_USERS` は [identity](identity.md)。

## テーブル

### reviews — 審査
1 行が、運営者の 1 回の判定(承認・否認・差し戻し)。判定したときに作る。追記だけで、更新・削除しない。
審査の記録はこの表だけで持つ。一次・二次の進み具合は審査段階、判定は審査結果、差し戻し・否認の理由と確認した内容は理由・コメントに書く(観点ごとのチェック結果の表は持たない)。

| 審査するもの | `application_submission_id` | `review_stage` | 指し方 |
| --- | --- | --- | --- |
| 申込の提出版 | 提出版 | `FIRST` / `SECOND` | 審査が提出版を指す。1 つの提出版に一次・二次の 2 行がつく |
| 会員基本情報申請・創出PT情報申請 | NULL | NULL | 申請が審査を指す(申請側の `review_id`)。申請 1 件に審査 1 件 |

- `reviews_stage_check`: 審査段階は申込の審査だけが持つ(上の表)
- `reviews_submission_stage_unique`: 1 つの提出版に、同じ段階の審査は 1 件だけ。差し戻し後の再提出は新しい提出版になるので、提出版ごとに一次・二次が 1 件ずつで足りる(二次の差し戻し後の提出版は二次だけ)。申込の審査でない行は両方 NULL で、一意の判定から外れる
- `reviews_review_reason_check`: 差し戻し・否認のときだけ理由(`review_reason`)が要る。理由は申請者に見せ、審査コメント(`review_comment`)は運営者の中だけで見る
- 申込の審査での審査結果と申込の状態([application](application.md))の対応:

| 審査段階 | 審査結果 | 申込の状態 |
| --- | --- | --- |
| `FIRST` | `APPROVED` | `UNDER_REVIEW` のまま(二次チェック待ち) |
| `FIRST` / `SECOND` | `RETURNED` | `RETURNED` |
| `SECOND` | `APPROVED` | `PARTICIPATING` |
| `SECOND` | `REJECTED` | `REJECTED` |

- アプリで検証すること:
  - 否認は二次チェックだけ。一次チェックでは否認しない
  - 二次チェックは、同じ申込で一次チェックの承認があるときだけ。二次で差し戻した申込の再提出は、一次を飛ばして二次から審査する
  - 申込の審査でない行(`application_submission_id` が NULL)は、どちらかの申請から指されている。審査と申請の更新は同じトランザクションで行う

<!-- generated:start table=reviews -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 提出版ID | application_submission_id | text | NULL | | |
| 審査者ID | reviewer_admin_user_id | text | NOT NULL | | |
| 審査段階 | review_stage | text | NULL | | |
| 審査結果 | review_result | text | NOT NULL | | |
| 差戻し・否認理由 | review_reason | text | NULL | | |
| 審査コメント | review_comment | text | NULL | | |
| 審査日時 | reviewed_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| reviews_submission_stage_unique | UNIQUE | application_submission_id, review_stage | |
| reviews_reviewer_admin_user_id_index | INDEX | reviewer_admin_user_id | |
| reviews_review_stage_check | CHECK | | review_stage in ('FIRST', 'SECOND') |
| reviews_review_result_check | CHECK | | review_result in ('APPROVED', 'REJECTED', 'RETURNED') |
| reviews_stage_check | CHECK | | (application_submission_id is null) = (review_stage is null) |
| reviews_review_reason_check | CHECK | | (review_result = 'APPROVED') = (review_reason is null) |
| reviews_reviewer_admin_user_id_admin_users_id_fk | FK | reviewer_admin_user_id | admin_users(id) |
| reviews_application_submission_fk | FK | application_submission_id | application_submissions(id) |
<!-- generated:end -->

### member_basic_info_requests — 会員基本情報申請
1 行が、会員ユーザーが会員の基本情報(住所・電話番号・代表者 等)を運営者に確認してもらう 1 回の申請。会員種別と法人番号は申請では変えない(運営者だけが変える。[api-usecases/member.md](../../basic/api-usecases/member.md) の「会員種別の変更」「法人番号の変更」)。差し戻し後の再提出は新しい行を作る。

| `request_type` | いつ作るか | 承認したとき |
| --- | --- | --- |
| `REGISTRATION` | 会員登録で基本情報を登録したとき(会員は仮会員 `PROVISIONAL` になる) | 会員を `ACTIVE` にし、承認待ちの参加申請をすべてプロジェクトに紐づける(`LINKED`。[application](application.md))。基本情報は登録時に `members` へ書いてあるので、写さない(差し戻し後の出し直しで `members` を直接書き換える。[api-usecases/member.md](../../basic/api-usecases/member.md) の「会員登録の差し戻し」) |
| `CHANGE` | 会員管理者が基本情報の修正を申請したとき | `submitted_content` を `members` に写す。承認までは `members` を変えない |

状態遷移(`partner_info_requests` も同じ):

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `SUBMITTED` | 上の表のとき |
| `SUBMITTED` | `APPROVED` / `REJECTED` / `RETURNED` | 運営者が判定したとき(審査の行を作り、`review_id` に入れる。状態は審査結果と同じ値にする) |

- `member_basic_info_requests_submitted_unique`: 申請中(`SUBMITTED`)の申請は会員ごとに 1 件だけ
- `member_basic_info_requests_review_check`: 申請中の間だけ `review_id` が NULL。1 つの審査を 2 つの申請から指さない(`member_basic_info_requests_review_id_unique`)
- `submitted_content`: 申請したときの基本情報をそのまま残す。運営者は申請の時点の内容をこの列で見る
- アプリで検証すること:
  - 判定した申請の `request_status` は、`review_id` の審査の `review_result` と同じ値
  - `member_user_id`(申請者)は `member_id` の会員に所属する。`CHANGE` は会員管理者だけが出せる([auth.md](../../basic/auth.md))

<!-- generated:start table=member_basic_info_requests -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員ID | member_id | text | NOT NULL | | |
| 審査・確認ID | review_id | text | NULL | | UNIQUE |
| 会員ユーザーID | member_user_id | text | NOT NULL | | |
| 申請種別 | request_type | text | NOT NULL | | |
| 申請状態 | request_status | text | NOT NULL | 'SUBMITTED' | |
| 提出内容 | submitted_content | jsonb | NOT NULL | | |
| 提出日時 | submitted_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| member_basic_info_requests_submitted_unique | UNIQUE INDEX | member_id | WHERE request_status = 'SUBMITTED' |
| member_basic_info_requests_member_id_index | INDEX | member_id | |
| member_basic_info_requests_member_user_id_index | INDEX | member_user_id | |
| member_basic_info_requests_request_type_check | CHECK | | request_type in ('REGISTRATION', 'CHANGE') |
| member_basic_info_requests_request_status_check | CHECK | | request_status in ('SUBMITTED', 'APPROVED', 'REJECTED', 'RETURNED') |
| member_basic_info_requests_review_check | CHECK | | (request_status = 'SUBMITTED') = (review_id is null) |
| member_basic_info_requests_member_id_members_id_fk | FK | member_id | members(id) |
| member_basic_info_requests_review_id_reviews_id_fk | FK | review_id | reviews(id) |
| member_basic_info_requests_member_user_id_member_users_id_fk | FK | member_user_id | member_users(id) |
<!-- generated:end -->

### partner_info_requests — 創出PT情報申請
1 行が、創出PT情報(会社名・所在地・連絡先 等)の変更の 1 回の申請。承認したら `submitted_content` を `partners` に写し、承認までは `partners` を変えない。差し戻し後の再提出は新しい行を作る。
創出PT は運営者が登録するので、登録の申請は無い(変更だけ)。

- 状態遷移と、判定後の `request_status` を審査結果と同じ値にすることは `member_basic_info_requests` と同じ。取下げは作らない([scope.md](../../basic/scope.md))
- `partner_info_requests_submitted_unique`: 申請中の申請は創出PT ごとに 1 件だけ(申請中は再申請できない)
- `partner_user_id`: 申請した人。`partner_id` の創出PT の管理者であることをアプリで検証する
- `change_reason`: 申請者が書く変更理由(任意)

<!-- generated:start table=partner_info_requests -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 創出PTID | partner_id | text | NOT NULL | | |
| 審査・確認ID | review_id | text | NULL | | UNIQUE |
| 創出PTユーザーID | partner_user_id | text | NOT NULL | | |
| 申請状態 | request_status | text | NOT NULL | 'SUBMITTED' | |
| 提出内容 | submitted_content | jsonb | NOT NULL | | |
| 変更理由 | change_reason | text | NULL | | |
| 提出日時 | submitted_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| partner_info_requests_submitted_unique | UNIQUE INDEX | partner_id | WHERE request_status = 'SUBMITTED' |
| partner_info_requests_partner_id_index | INDEX | partner_id | |
| partner_info_requests_partner_user_id_index | INDEX | partner_user_id | |
| partner_info_requests_request_status_check | CHECK | | request_status in ('SUBMITTED', 'APPROVED', 'REJECTED', 'RETURNED') |
| partner_info_requests_review_check | CHECK | | (request_status = 'SUBMITTED') = (review_id is null) |
| partner_info_requests_partner_id_partners_id_fk | FK | partner_id | partners(id) |
| partner_info_requests_review_id_reviews_id_fk | FK | review_id | reviews(id) |
| partner_info_requests_partner_user_id_partner_users_id_fk | FK | partner_user_id | partner_users(id) |
<!-- generated:end -->

## Open questions
- 会員基本情報申請・創出PT情報申請に否認があるか。ステータス定義では創出PTは「否認・差戻し」が 1 つ、会員は差し戻しだけ。審査結果に合わせて否認・差し戻しの両方を持たせた
- 会員登録の申請を否認したときに会員をどうするか(仮会員のままか、退会にするか)
- 申込の一次・二次を運営組織(一次 TSGX・二次 JGX)で分けて検証するか。運営者の組織を持っていないので、今はどの運営ユーザーでもどちらの段階も審査できる([auth.md](../../basic/auth.md) の Open questions)
