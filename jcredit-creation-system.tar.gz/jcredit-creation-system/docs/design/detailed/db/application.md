# application: 参加申請・申込・同意

- Last updated: 2026-10-15
- Schema: `packages/db/schema/application.ts`

## 概要
会員がプロジェクトに参加するまでの、参加申請(会員が本会員なら紐づく)→ 申込(運営者が審査)→ 参加中 → 退会 を持つ。申込から退会までは `project_applications` の 1 行の状態で表す。
規約への同意の記録(`consent_records`)もここに置く。審査の記録は `review`、施設・対象設備・証跡書類は `facility` クラスタが持つ。用語は [domain.md](../../basic/domain.md)。

## ER 図

```mermaid
erDiagram
  MEMBERS ||--o{ PARTICIPATION_REQUESTS : "申請する"
  PROJECTS ||--o{ PARTICIPATION_REQUESTS : "申請先"
  MEMBER_USERS ||--o{ PARTICIPATION_REQUESTS : "申請者"
  PARTICIPATION_REQUESTS ||--o{ PROJECT_APPLICATIONS : "紐づいた後に申し込む(再申込を含む)"
  ADMIN_USERS |o--o{ PARTICIPATION_REQUESTS : "紐づきを外す"
  PARTNER_BRANCHES |o--o{ PARTICIPATION_REQUESTS : "支部"
  RECRUITMENT_PERIODS |o--o{ PROJECT_APPLICATIONS : "受付期"
  MEMBER_USERS ||--o{ PROJECT_APPLICATIONS : "申込者"
  PROJECT_APPLICATIONS ||--o| APPLICATION_CONFIRMATIONS : "確認事項"
  PROJECT_APPLICATIONS ||--o{ APPLICATION_SUBMISSIONS : "提出・再提出ごとに残す"
  MEMBER_USERS ||--o{ APPLICATION_SUBMISSIONS : "提出者"
  TERMS_VERSIONS ||--o{ CONSENT_RECORDS : "同意した版"
  MEMBERS |o--o{ CONSENT_RECORDS : "同意した会員"
  PROJECT_APPLICATIONS |o--o{ CONSENT_RECORDS : "申込時の同意"
```

`PROJECTS` / `RECRUITMENT_PERIODS` / `TERMS_VERSIONS` は [project](project.md)、`MEMBERS` / `MEMBER_USERS` / `ADMIN_USERS` / `PARTNER_BRANCHES` は [identity](identity.md)。

## テーブル

### participation_requests — 参加申請
1 行が、1 つの会員から 1 つのプロジェクトへの参加申請 1 回と、その後の紐づき。創出PTは承諾・否認しない。会員が本会員(`ACTIVE`)ならその場で紐づき(`LINKED`)、仮会員(`PROVISIONAL`)なら運営者が会員登録を承認するまで承認待ち(`PENDING`)で置く。

| 経路 | 作るとき |
| --- | --- |
| 会員がプロジェクトコードを入力(基本情報登録の画面・プロジェクトの画面) | 入力したとき |
| 新規会員の招待([invitation](invitation.md)) | 登録完了時。会員・会員ユーザーと同じトランザクション |
| 既存会員の招待([invitation](invitation.md)) | 招待 URL からログインしたとき |

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `PENDING` | 仮会員の会員が上の表の経路で申請したとき |
| — | `LINKED` | 本会員の会員が上の表の経路で申請したとき |
| `PENDING` | `LINKED` | 運営者が会員登録(`member_basic_info_requests` の `REGISTRATION`)を承認したとき。その会員の承認待ちをすべて同じトランザクションで紐づける |
| `LINKED` | `REMOVED` | 違う会員が紐づいたなどで、運営者がプロジェクト詳細から紐づきを外したとき |

- 紐づき(`LINKED`)の行があると、会員はそのプロジェクトのプロジェクト詳細を見られ、申込ができる。紐づきを表す別の表は持たない
- 承認待ち(`PENDING`)の間は、創出PTに通知せず、紹介会員の一覧にも出さない。会員には、申請したプロジェクトのプロジェクトコード・プロジェクト名・創出PT名だけを見せる
- 紐づいたとき(`LINKED` になったとき)に、会員ユーザーと、そのプロジェクトの創出PTの創出PTユーザーに通知する
- 外した(`REMOVED`)あとは、同じ会員が同じプロジェクトに新しい行で再申請できる
- `participation_requests_active_unique`: 承認待ち・紐づきは会員 × プロジェクトで 1 件だけ(同じプロジェクトへの二重申請を防ぐ)
- `participation_requests_linked_check`: 紐づいた日時(`linked_at`)は承認待ちの間だけ NULL。外したあとも、いつ紐づいたかは残す
- `participation_requests_removed_check`: 外した運営ユーザーと日時は、外したときだけ 2 つとも入る
- `member_user_id`(申請者)は `member_id` の会員に所属することをアプリで検証する
- `partner_branch_id`: 商工会議所の支部。プロジェクトの創出PTが支部(`partner_branches`)を持つとき、会員が申請で選ぶ。普通の創出PTのプロジェクトは NULL。会員ごとではなく参加申請ごとに持つので、
  東京商工会議所と日本商工会議所の両方のプロジェクトに参加した会員も、それぞれの創出PTが自分の支部で絞り込める。同じ創出PTの 2 つ目のプロジェクトでも聞く(前に選んだ支部を初めの値にする)。
  創出PTの会員一覧・プロジェクト一覧の支部での並べ替え・絞り込みに使う([api-usecases/partner.md](../../basic/api-usecases/partner.md) の「支部での並べ替え・絞り込み」)
- アプリで検証すること(どれも別の表の値を見るので CHECK に書けない):
  - 支部はプロジェクトの創出PTの支部(`partner_branches.partner_id` がプロジェクトの `partner_id`)
  - 支部を持たない創出PTのプロジェクトへの申請は支部を持たない。支部を持つ創出PTのプロジェクトへの申請は支部が必須。
    例外は既存会員の招待の受け入れで、確認の画面を挟まないので NULL で作り、受け入れたあとのポップアップで選ばせる([api-usecases/member.md](../../basic/api-usecases/member.md) の「支部」)

<!-- generated:start table=participation_requests -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 会員ID | member_id | text | NOT NULL | | |
| プロジェクトID | project_id | text | NOT NULL | | |
| 会員ユーザーID | member_user_id | text | NOT NULL | | |
| ステータス | status | text | NOT NULL | 'PENDING' | |
| 申請日時 | requested_at | timestamptz | NOT NULL | now() | |
| 紐づいた日時 | linked_at | timestamptz | NULL | | |
| 外した運営ユーザーID | removed_by_admin_user_id | text | NULL | | |
| 外した日時 | removed_at | timestamptz | NULL | | |
| 創出PT支部ID | partner_branch_id | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| participation_requests_active_unique | UNIQUE INDEX | member_id, project_id | WHERE status in ('PENDING', 'LINKED') |
| participation_requests_member_id_index | INDEX | member_id | |
| participation_requests_project_id_index | INDEX | project_id | |
| participation_requests_member_user_id_index | INDEX | member_user_id | |
| participation_requests_removed_by_admin_user_id_index | INDEX | removed_by_admin_user_id | |
| participation_requests_partner_branch_id_index | INDEX | partner_branch_id | |
| participation_requests_status_check | CHECK | | status in ('PENDING', 'LINKED', 'REMOVED') |
| participation_requests_linked_check | CHECK | | (status = 'PENDING') = (linked_at is null) |
| participation_requests_removed_check | CHECK | | num_nonnulls(removed_by_admin_user_id, removed_at) = case when status = 'REMOVED' then 2 else 0 end |
| participation_requests_member_id_members_id_fk | FK | member_id | members(id) |
| participation_requests_project_id_projects_id_fk | FK | project_id | projects(id) |
| participation_requests_member_user_id_member_users_id_fk | FK | member_user_id | member_users(id) |
| participation_requests_partner_branch_id_partner_branches_id_fk | FK | partner_branch_id | partner_branches(id) |
| participation_requests_removed_by_fk | FK | removed_by_admin_user_id | admin_users(id) |
<!-- generated:end -->

### project_applications — 申込・参加
1 行が 1 回の申込と、承認後の参加。申込から参加中・退会までをこの 1 行の状態で表す。否認・期限切れ取消の後の再申込は新しい行を作る。

状態遷移:

| from | to | 誰が・いつ |
| --- | --- | --- |
| — | `DRAFT` | 会員ユーザー(代理入力では創出PTユーザー)が申込を始めたとき |
| `DRAFT` / `RETURNED` | `UNDER_REVIEW` | 提出・再提出したとき(提出版を 1 行作る) |
| `UNDER_REVIEW` | `RETURNED` | 運営者が差し戻したとき(一次・二次のどちらでも) |
| `UNDER_REVIEW` | `PARTICIPATING` | 運営者が二次チェックで承認したとき(`joined_on` に承認日を入れる) |
| `UNDER_REVIEW` | `REJECTED` | 運営者が否認したとき |
| `RETURNED` | `EXPIRED` | 再提出の期限を過ぎたとき(日次バッチ) |
| `PARTICIPATING` | `WITHDRAWN` | 運営者がプロジェクト退会にしたとき |

- 一次・二次のどちらの審査中か、一次を通ったかは状態に持たず、審査(`reviews`)の審査段階と結果で表す。審査の記録を 2 か所に持たないため
- 会員からの取下げと、プロジェクト退会の申請は作らない([scope.md](../../basic/scope.md))。取下げ・退会申請中・退会予約の状態は持たず、退会は運営者が状態を変えるだけ
- `project_applications_submitted_check`: 下書きの間だけ `submitted_at`(初回の提出日時)が NULL。提出したら `recruitment_period_id` も必須(提出時に募集中の期を入れる)
- `project_applications_joined_check`: `joined_on`(本入会日 = 承認日)は参加中・退会のときだけ入る。`effective_to`(有効終了日)はプロジェクトへの参加が終わる日。両方入っているときは `effective_to` が `joined_on` 以降(`project_applications_effective_range_check`)
- `application_number`: 会員・運営者が画面で見る申込番号。採番規則は Open questions
- アプリで検証すること:
  - `participation_request_id` は紐づき(`LINKED`)の参加申請(作成時と提出・再提出時)
  - 同じ会員が、同じプロジェクト定義への申込を、否認・期限切れ取消・退会 以外の状態で 2 件持たない(会員・プロジェクト定義は参加申請 → プロジェクトでたどる。同じ定義への二重申込と、別の創出PT経由の二重参加を防ぐ)
  - 募集期は、参加申請のプロジェクトと同じプロジェクト定義のもの
  - `member_user_id`(申込者)は、参加申請の会員に所属する

<!-- generated:start table=project_applications -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 参加申請ID | participation_request_id | text | NOT NULL | | |
| 募集期ID | recruitment_period_id | text | NULL | | |
| 会員ユーザーID | member_user_id | text | NOT NULL | | |
| 申込番号 | application_number | text | NOT NULL | | UNIQUE |
| 申込・参加状態 | application_status | text | NOT NULL | 'DRAFT' | |
| 申込日時 | submitted_at | timestamptz | NULL | | |
| 本入会日 | joined_on | date | NULL | | |
| 有効終了日 | effective_to | date | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| project_applications_participation_request_id_index | INDEX | participation_request_id | |
| project_applications_recruitment_period_id_index | INDEX | recruitment_period_id | |
| project_applications_member_user_id_index | INDEX | member_user_id | |
| project_applications_application_status_check | CHECK | | application_status in ('DRAFT', 'UNDER_REVIEW', 'RETURNED', 'PARTICIPATING', 'REJECTED', 'EXPIRED', 'WITHDRAWN') |
| project_applications_submitted_check | CHECK | | (application_status = 'DRAFT') = (submitted_at is null) and (application_status = 'DRAFT' or recruitment_period_id is not null) |
| project_applications_joined_check | CHECK | | (application_status in ('PARTICIPATING', 'WITHDRAWN')) = (joined_on is not null) |
| project_applications_effective_range_check | CHECK | | joined_on <= effective_to |
| project_applications_member_user_id_member_users_id_fk | FK | member_user_id | member_users(id) |
| project_applications_participation_request_fk | FK | participation_request_id | participation_requests(id) |
| project_applications_recruitment_period_fk | FK | recruitment_period_id | recruitment_periods(id) |
<!-- generated:end -->

### application_confirmations — 確認事項
1 行が 1 つの申込の確認事項への回答。申込 1 件に 1 行(`application_confirmations_project_application_id_unique`)。

- 下書きの間に少しずつ保存するので、条件付きで必須の列(特定排出者コード・省エネ法の事業者番号・指定工場番号など)は DB で縛らず、提出時にアプリで検証する
- `has_agreed_all_terms`: その申込で要る同意(会員規約、サービス利用同意 4 項目、申告事項 5 項目)が同意ログ(`consent_records`)に揃ったら TRUE にする。明細は同意ログが正。TRUE でない申込は提出できない
- 補助金の利用有無・中古設備・自己所有・撤去した蛍光灯の適正処理・調整後排出量への加算の同意は列に持たない。どれも「申込できる答え」を選ばないと先へ進めない設問なので、提出されていること自体が回答の記録になる。補助金の有無は補助金明細(`facility` クラスタ)の行の有無で分かる
- `energy_conservation_status`(省エネ法の対象区分)は値が決まっていないので DB では縛らない(Open questions)

<!-- generated:start table=application_confirmations -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト申込・参加ID | project_application_id | text | NOT NULL | | |
| 規約・同意事項すべてに同意済み | has_agreed_all_terms | boolean | NOT NULL | false | |
| 経団連CN行動計画参加 | is_keidanren_cn_plan_participant | boolean | NULL | | |
| 特定排出者該当 | is_specified_emitter | boolean | NULL | | |
| 特定排出者コード | specified_emitter_code | text | NULL | | |
| 省エネ法対象区分 | energy_conservation_status | text | NULL | | |
| 省エネ法事業者番号 | energy_business_number | text | NULL | | |
| 省エネ法指定工場番号 | energy_factory_number | text | NULL | | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| application_confirmations_project_application_id_unique | UNIQUE | project_application_id | |
| application_confirmations_project_application_fk | FK | project_application_id | project_applications(id) |
<!-- generated:end -->

### application_submissions — 申込の提出版
1 行が 1 回の提出・再提出。提出したときの申込内容(確認事項・施設・対象設備・書類枠)を `submitted_content` にそのまま残す。差し戻し後に申込を直しても、運営者は審査した時点の内容をこの行で見られる。審査(`reviews`)は提出版を指す。

- 行は追記だけで、更新・削除しない
- `member_user_id` は申込者で、申込時の規約・同意事項に同意した会員ユーザー。代理入力で創出PTユーザーが提出したときも同じ

<!-- generated:start table=application_submissions -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| プロジェクト申込・参加ID | project_application_id | text | NOT NULL | | |
| 会員ユーザーID | member_user_id | text | NOT NULL | | |
| 提出内容 | submitted_content | jsonb | NOT NULL | | |
| 提出日時 | submitted_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| application_submissions_project_application_id_index | INDEX | project_application_id | |
| application_submissions_member_user_id_index | INDEX | member_user_id | |
| application_submissions_member_user_id_member_users_id_fk | FK | member_user_id | member_users(id) |
| application_submissions_project_application_fk | FK | project_application_id | project_applications(id) |
<!-- generated:end -->

### consent_records — 同意ログ
1 行が、1 人のユーザーが規約・同意項目の 1 つの版に同意した事実。同意しなかった記録は持たない。追記だけで、更新・削除しない。

| 同意 | `terms_type`([project](project.md)) | `member_id` | `project_application_id` |
| --- | --- | --- | --- |
| システム利用規約・プライバシーポリシー | `TERMS_OF_USE` / `PRIVACY_POLICY` | 会員ユーザーなら所属する会員。ほかのユーザーは NULL | NULL |
| 申込時の同意 | `MEMBER_AGREEMENT` / `SERVICE_CONSENT` / `DECLARATION` | 申込の会員 | 申込 |

- `consented_by_user_type` + `consented_by_user_id`: 同意したユーザー。システム利用規約・プライバシーポリシーには会員ユーザー以外も同意するので、種別 + ID で持つ。
  申込時の同意は会員ユーザーだけがする(代理入力でも創出PTユーザーは代わりに同意しない)。種別が規約の版の表にあるので、アプリで守る
- 上の表の対応(規約種別ごとに申込を入れるか)はアプリで守る。種別は規約の版の表にあり、CHECK では見られない
- 同意が揃った日時は、その申込の同意ログの最新の `agreed_at` で分かる

<!-- generated:start table=consent_records -->
| 論理名 | カラム | 型 | NULL | 既定値 | 制約 |
| --- | --- | --- | --- | --- | --- |
| ID | id | text | NOT NULL | (app: UUIDv7) | PK |
| 規約版ID | terms_version_id | text | NOT NULL | | |
| 会員ID | member_id | text | NULL | | |
| プロジェクト申込・参加ID | project_application_id | text | NULL | | |
| 同意者種別 | consented_by_user_type | text | NOT NULL | | |
| 同意者ID | consented_by_user_id | text | NOT NULL | | |
| 同意日時 | agreed_at | timestamptz | NOT NULL | now() | |
| 作成日時 | created_at | timestamptz | NOT NULL | now() | |
| 更新日時 | updated_at | timestamptz | NOT NULL | now() | |

| 名前 | 種別 | カラム | 定義 |
| --- | --- | --- | --- |
| consent_records_terms_version_id_index | INDEX | terms_version_id | |
| consent_records_member_id_index | INDEX | member_id | |
| consent_records_project_application_id_index | INDEX | project_application_id | |
| consent_records_consented_by_index | INDEX | consented_by_user_type, consented_by_user_id | |
| consent_records_consented_by_user_type_check | CHECK | | consented_by_user_type in ('MEMBER', 'PARTNER', 'ADMIN') |
| consent_records_terms_version_id_terms_versions_id_fk | FK | terms_version_id | terms_versions(id) |
| consent_records_member_id_members_id_fk | FK | member_id | members(id) |
| consent_records_project_application_fk | FK | project_application_id | project_applications(id) |
<!-- generated:end -->

## Open questions
- 仮会員のうちに申請したプロジェクトが、運営者が会員登録を承認するまでに閉じた・創出PTが利用終了になったときに、そのまま紐づけるか、承認待ちのまま残すか
- 審査中・差し戻し・参加中の申込がある紐づきを外すか。今は外すのを断り(申込は先に否認・プロジェクト退会にする)、下書きの申込は残して提出できなくする
- 差し戻しから期限切れ取消になるまでの再提出期限(日数と、どこに持つか)が決まっていない
- `application_number` の採番規則(桁数・文字種・プロジェクトごとの連番か)が決まっていない
- `energy_conservation_status` の値(省エネ法の特定事業者・特定連鎖化事業者・対象外 など)が決まっていない
- `effective_to` を誰がいつ入れるか(承認時にプロジェクトの期間から決めるのか、退会時に入れるのか)と、期間満了で自動的に退会にするか
