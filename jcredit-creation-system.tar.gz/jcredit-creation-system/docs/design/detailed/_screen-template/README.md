# <app> / <feature>: <この機能を一言で>

- Last updated: YYYY-MM-DD
- App: `apps/<app>`(利用者: 運営者 | 創出PT | 会員)
- Routes: `/<path>`, `/<path>/[id]`, …

## 概要
<誰が、何のために使う機能か。3 行以内>

## 利用者と権限
<この機能を開けるのは誰か。auth.md の表を参照し、画面固有の条件だけを書く。同じ利用者区分の中でロールや所属で見え方が変わるなら、その条件>

| 画面 | 開ける人 | 条件 |
| --- | --- | --- |
| | | |

## 画面遷移
<どこから来て、どこへ行くか。この機能の画面と、隣接する他機能への出入りだけ>

```mermaid
flowchart LR
  list["/projects 一覧"] --> detail["/projects/[id] 詳細"]
  detail --> edit["/projects/[id]/edit 編集"]
  edit -->|保存| detail
```

## 画面

| 画面 | パス | 設計書 |
| --- | --- | --- |
| <画面名> | `/<path>` | [<screen>.md](<screen>.md) |

## 画面をまたぐ決まり
<この機能の 2 つ以上の画面に効く業務ルールだけ。1 画面だけの決まりは画面の設計書に書く。
3 アプリ・複数機能にまたがるものは基本設計(auth.md / error-handling.md / api-usecases)に書いてリンクする>

## Open questions
- <未決のまま進めること。決まったらこのファイルを更新する。画面の Open questions もここに集める>
- <DB に無くて要るデータ項目(ADR-0008): 項目・使う画面・理由と、データ項目の追加を申請する PR。マージされたら画面項目定義に足してここから消す>

<!-- 書き方は docs/design/README.md の「画面設計」、手順は /add-screen-design。
     1 機能 = 1 ディレクトリ(docs/design/detailed/<app>/<feature>/)。このファイルが入口で、画面は 1 パス 1 ファイル。
     変更履歴はここに書かない: git log -p --follow <このファイル> が持っている -->
