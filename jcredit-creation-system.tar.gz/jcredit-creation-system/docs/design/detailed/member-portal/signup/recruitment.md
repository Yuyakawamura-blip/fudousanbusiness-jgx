# member-portal / 会員登録 / 会員募集の案内

- Last updated: 2026-10-13
- Route: `/recruitment`, `/recruitment/tokyo-cci`, `/recruitment/jcci`
- 機能: [README.md](README.md)(利用者と権限・画面遷移・画面をまたぐ決まり・Open questions)
- Figma: [一般・日本商工会議所](https://www.figma.com/design/uBLmZYdtFyY1DHEU3wktN6/%E6%9D%B1%E4%BA%AC%E3%83%9E%E3%83%AA%E3%83%B3-web?node-id=490-14675) / [東京商工会議所](https://www.figma.com/design/uBLmZYdtFyY1DHEU3wktN6/%E6%9D%B1%E4%BA%AC%E3%83%9E%E3%83%AA%E3%83%B3-web?node-id=647-16843)

| 一般・日本商工会議所 | 東京商工会議所 |
| --- | --- |
| ![会員募集(一般)](images/recruitment-general.webp) | ![会員募集(東京商工会議所)](images/recruitment-tokyo-cci.webp) |

デザインは未確定(README の Open questions)。

未ログインで開く、会員募集の案内。「会員アカウント作成」からメールアドレス登録へ、「会員ログイン」からログインへ進む。

## 業務ルール
- 3 つはパスで分け、表示ブランド(一般・東京商工会議所・日本商工会議所)ごとに案内の中身が違う(東京商工会議所は還元のシミュレーションを載せる等)。日本商工会議所は今は一般と同じ中身
- どの会員募集から来たかを、メールアドレス登録に引き継ぐ(README の「表示ブランドと流入経路」)
- プロジェクトの概要・参加のメリット・登録の流れ・スケジュール・お知らせ・よくある質問は、画面に持つ文面で出す。
  お知らせを通知から引かないのは、通知はログインした利用者に向けたもので、未ログインに見せてよい通知の区分が無いため。よくある質問も同じ理由で FAQ の表から引かない
- 未ログイン向けの問い合わせフォームは置かない(問い合わせ先はフッターに文面で出す)。フッターの個人情報保護方針はプライバシーポリシー(`/privacy`)を開く

## 空・エラー・権限なし
- ログインしていても開ける(README の「利用者と権限」)
- メンテナンス中はこの画面もメンテナンス画面に切り替わる

## 呼ぶ API
- なし
