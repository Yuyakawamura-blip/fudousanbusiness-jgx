# <lane> / <usecase>: <このユースケースを一言で>

- Last updated: YYYY-MM-DD
- Lane: `admin` | `partner` | `member`
- Endpoints: `POST /api/<lane>/<resource>`, … (仕様は Scalar `/docs`)

## 概要
<どの業務のどの処理か。単一エンドポイントで完結するなら、このファイルは要らない(OpenAPI が仕様)。
書くのは複数エンドポイント・複数テーブル・外部連携をまたぐ処理だけ>

## 権限
<このユースケースを実行できるのは誰か。レーン内のロール・所属・対象データの状態による制限>

## シーケンス
<Web(RSC / Server Action)→ API → DB / 外部サービス の順に。分岐は主要なものだけ>

```mermaid
sequenceDiagram
  participant W as partner-console (Server Action)
  participant A as API (partner)
  participant D as DB
  W->>A: POST /api/partner/projects
  A->>D: projects に INSERT、project_events に INSERT
  A-->>W: 201
```

## トランザクションと失敗時
<コードから読めないことだけ:
- トランザクション境界(どこからどこまでを 1 トランザクションにするか、なぜ)
- 冪等性(同じリクエストが 2 回来たらどうなるか。キーは何か)
- 外部連携の失敗・タイムアウト時にどこまで巻き戻すか、リトライするか(回数と根拠)
- 競合(同じデータを同時に更新されたとき)>

## Open questions
- <未決のまま進めること。決まったらこのファイルを更新する>

<!-- 書き方は docs/design/README.md の「API 設計」。
     ファイルは docs/design/detailed/api/<lane>/<usecase>.md(ユースケース単位。エンドポイント単位には作らない)。
     変更履歴はここに書かない: git log -p --follow <このファイル> が持っている -->
