# 基本設計 — 画面遷移・機能一覧(会員マイページ)

> 会員マイページ(`apps/member-portal`)の画面遷移・機能一覧・URL パス。創出PTマイページは [partner-console.md](partner-console.md)、運営者コンソールは [admin-console.md](admin-console.md)。
> 出典は要件定義「画面遷移図 Ver.0.3」で、画面名は用語集([domain.md](../domain.md))に読み替えている。
> 本書は **L1(画面同士の大まかな遷移)**。機能ごとの画面設計(表示条件・業務ルール・呼ぶ API)は `detailed/member-portal/<feature>/`(入口の `README.md` と 1 画面 1 ファイル)。
> 利用規約・プライバシーポリシー(全画面のフッターから)とメンテナンス(メンテナンス中は全画面から)は、図に描かず機能一覧にだけ載せる。
> ログアウトは画面を持たず、図ではログインへの遷移として描く。
> 未ログイン・権限なし・エラーのときの行き先(ログイン画面・404 画面・共通エラー画面)は 3 アプリ共通なので図に描かず、[error-handling.md](../error-handling.md) に書く。
>
> **現状**: 実装済みは `/` のみ。それ以外は未実装で、実装時は本書のパスでルートを作る。

会員ユーザーが、会員登録からプロジェクトへの参加申請・申込、会員基本情報の修正の申請、会員退会までを行う。
見えるデータは自分が所属する会員の分だけ。会員の基本情報は直接書き換えず、運営者への申請(会員基本情報申請)として出す。申込後の施設情報は修正できない。
ロールごとにできる操作は [auth.md](../auth.md)。

## 機能一覧

| 機能 | 概要 | 画面 |
| --- | --- | --- |
| 認証 | 会員ユーザーのログイン・二段階認証・パスワード再設定 | `/login`, `/two-factor`, `/two-factor/complete`, `/password-reset`, `/password-reset/confirm`, `/password-reset/complete` |
| 会員登録 | 会員募集の案内から、メールアドレス登録(仮登録)・アカウント作成と基本情報登録。基本情報登録でプロジェクトコードを入力でき、プロジェクトコード・プロジェクト名・創出PT名を確かめて参加申請する。会員募集は一般・東京商工会議所・日本商工会議所の 3 種。招待メールのリンクから開くアカウント作成(創出PTからのプロジェクトへの招待・会員管理者からの会員担当者の招待)も含む | `/recruitment`, `/recruitment/tokyo-cci`, `/recruitment/jcci`, `/signup`, `/signup/account`, `/signup/invitation` |
| TOP | 各機能への入口 | `/`(実装済み) |
| プロジェクト | プロジェクトの一覧と、プロジェクトコードを入力しての参加(参加申請。仮会員は本会員になってから紐づく)。施設情報を含む詳細の閲覧(紐づいてから) | `/projects`, `/projects/[id]` |
| 申込 | 会員規約への同意、プロジェクトの確認事項のチェック、施設情報の入力と証跡書類のアップロードで、プロジェクトに申し込む | `/projects/[id]/apply/terms`, `/projects/[id]/apply/confirmations`, `/projects/[id]/apply/facilities`, `/projects/[id]/apply/complete` |
| 会員基本情報 | 会員の基本情報の確認と、修正の申請(会員基本情報申請) | `/basic-info`, `/basic-info/edit` |
| 会員ユーザー管理 | 会員ユーザーの一覧・招待・編集。招待は法人会員だけ(個人会員の会員ユーザーは会員管理者 1 人) | `/users`, `/users/[id]/edit` |
| 通知 | 通知と問い合わせの一覧・詳細。運営者が起票した問い合わせと、運営者が回答した自分の問い合わせが届き、その画面から返信できる | `/notifications`, `/notifications/[id]` |
| FAQ・問い合わせ | FAQ の一覧・詳細の閲覧と、運営者への問い合わせ | `/faqs`, `/faqs/[id]`, `/inquiries/new`, `/inquiries/new/complete` |
| マイアカウント | 自分のアカウントの確認・編集 | `/account`, `/account/edit` |
| 会員退会 | 会員退会。FAQ「会員退会について」の詳細から入り、完了後は会員募集に戻る | `/withdraw`, `/withdraw/complete` |
| 利用規約・プライバシーポリシー | 閲覧専用。全画面のフッターと、メールアドレス登録・招待からのアカウント作成の同意リンクから開く | `/terms`, `/privacy` |
| メンテナンス | メンテナンス中は全画面からこの画面に切り替わる | `/maintenance` |

## 画面遷移(会員登録・認証)

```mermaid
flowchart TD
  recruitment["/recruitment 会員募集(一般)"] --> signup["/signup メールアドレス登録"]
  recruitmentTokyoCci["/recruitment/tokyo-cci 会員募集(東京商工会議所)"] --> signup
  recruitmentJcci["/recruitment/jcci 会員募集(日本商工会議所)"] --> signup
  signup --> signupAccount["/signup/account アカウント作成・基本情報登録"]
  signupAccount --> twoFactor["/two-factor 二段階認証"]
  invitationMail(["招待メールのリンク"]) --> signupInvitation["/signup/invitation 招待からのアカウント作成"]
  signupInvitation --> twoFactor
  existingInvitationMail(["既存会員への招待メールのリンク"]) --> login
  login["/login ログイン"] --> twoFactor
  recruitment --> login
  recruitmentTokyoCci --> login
  recruitmentJcci --> login
  twoFactor --> twoFactorComplete["/two-factor/complete 二段階認証完了"]
  twoFactorComplete --> top["/ TOP"]
  login --> passwordReset["/password-reset パスワード再設定申請"]
  passwordReset --> passwordResetConfirm["/password-reset/confirm パスワード再設定"]
  passwordResetConfirm --> passwordResetComplete["/password-reset/complete パスワード再設定完了"]
  passwordResetComplete --> login
```

## 画面遷移(各機能)

```mermaid
flowchart TD
  top["/ TOP"] --> projects["/projects プロジェクト一覧・参加(プロジェクトコード入力)"]
  projects --> projectDetail["/projects/[id] プロジェクト詳細・施設情報詳細"]
  projectDetail --> applyTerms["/projects/[id]/apply/terms 申込(会員規約)"]
  applyTerms --> applyConfirmations["/projects/[id]/apply/confirmations 申込(確認事項)"]
  applyConfirmations --> applyFacilities["/projects/[id]/apply/facilities 申込(施設情報・証跡書類)"]
  applyFacilities --> applyComplete["/projects/[id]/apply/complete 申込完了"]
  applyComplete --> top
  top --> basicInfo["/basic-info 基本情報確認"]
  basicInfo --> basicInfoEdit["/basic-info/edit 基本情報修正の申請"]
  basicInfoEdit --> basicInfo
  top --> users["/users 会員ユーザー一覧・招待(法人会員のみ)"]
  users --> userEdit["/users/[id]/edit 会員ユーザー編集"]
  userEdit --> users
  top --> notifications["/notifications 通知一覧"]
  notifications --> notificationDetail["/notifications/[id] 通知詳細・返信"]
  notificationDetail --> notifications
  top --> faqs["/faqs FAQ"]
  faqs --> faqDetail["/faqs/[id] FAQ 詳細"]
  faqDetail --> faqs
  faqs --> inquiryNew["/inquiries/new 問い合わせ"]
  inquiryNew --> inquiryComplete["/inquiries/new/complete 問い合わせ完了"]
  inquiryComplete --> faqs
  faqDetail -->|会員退会について| withdraw["/withdraw 会員退会"]
  withdraw --> withdrawComplete["/withdraw/complete 会員退会完了"]
  withdrawComplete --> recruitment["/recruitment 会員募集"]
  top --> account["/account マイアカウント管理"]
  account --> accountEdit["/account/edit マイアカウント編集"]
  accountEdit --> account
  top -->|ログアウト| login["/login ログイン"]
```
