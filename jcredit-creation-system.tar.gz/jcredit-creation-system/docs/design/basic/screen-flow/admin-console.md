# 基本設計 — 画面遷移・機能一覧(運営者コンソール)

> 運営者コンソール(`apps/admin-console`)の画面遷移・機能一覧・URL パス。会員マイページは [member-portal.md](member-portal.md)、創出PTマイページは [partner-console.md](partner-console.md)。
> 出典は要件定義「画面遷移図 Ver.0.3」で、画面名は用語集([domain.md](../domain.md))に読み替えている。
> 本書は **L1(画面同士の大まかな遷移)**。機能ごとの画面設計(表示条件・業務ルール・呼ぶ API)は `detailed/admin-console/<feature>/`(入口の `README.md` と 1 画面 1 ファイル)。
> 利用規約・プライバシーポリシー(全画面のフッターから)は、図に描かず機能一覧にだけ載せる。
> ログアウトは画面を持たず、図ではログインへの遷移として描く。
> 未ログイン・権限なし・エラーのときの行き先(ログイン画面・404 画面・共通エラー画面)は 3 アプリ共通なので図に描かず、[error-handling.md](../error-handling.md) に書く。
>
> **現状**: 実装済みは `/` のみ。それ以外は未実装で、実装時は本書のパスでルートを作る。

運営ユーザーが、会員・創出PT・プロジェクト・申込・申請・通知・問い合わせ・FAQ・メンテナンスを全体横断で管理する。
審査(承認・否認・差し戻し)、創出PTの登録、通知の作成はこのアプリでだけ行う。プロジェクト定義はデータ投入で入れるため、作成する画面は無い。運営者は会員を招待しない。
ロールごとにできる操作は [auth.md](../auth.md)。

## 機能一覧

| 機能 | 概要 | 画面 |
| --- | --- | --- |
| 認証 | 運営ユーザーのログイン・二段階認証・パスワード再設定 | `/login`, `/two-factor`, `/two-factor/complete`, `/password-reset`, `/password-reset/confirm`, `/password-reset/complete` |
| アカウント作成 | 招待された運営ユーザーのアカウント作成。招待メールのリンクから開く | `/signup` |
| TOP | 各機能への入口 | `/`(実装済み) |
| 会員管理 | 全会員の一覧・詳細・編集と、会員ユーザーの編集。会員が参加申請で選んだ支部も出し、編集できる | `/members`, `/members/[memberId]`, `/members/[memberId]/edit`, `/members/[memberId]/users/[userId]/edit` |
| 会員の申込 | 会員の、申込中から参加中までの申込の一覧と編集 | `/members/[memberId]/applications`, `/members/[memberId]/applications/[applicationId]/edit` |
| プロジェクト管理 | プロジェクトの一覧・詳細・編集。詳細に紐づいた会員を出し、違う会員が紐づいたときはそこから外す | `/projects`, `/projects/[id]`, `/projects/[id]/edit` |
| 申込審査 | 申込の一覧・詳細と、審査(承認・否認・差し戻し) | `/applications`, `/applications/[id]` |
| 申請 | 会員基本情報申請・創出PT情報申請の一覧・詳細と、承認・否認・差し戻し | `/requests`, `/requests/[id]` |
| 創出PT管理 | 創出PTの一覧・登録・詳細・編集。登録時に、その創出PTが参画するプロジェクトも一緒に作り、創出PT管理者を招待する | `/partners`, `/partners/new`, `/partners/new/complete`, `/partners/[partnerId]`, `/partners/[partnerId]/edit` |
| 創出PTユーザー管理 | 創出PTごとの創出PTユーザーの一覧・編集 | `/partners/[partnerId]/users`, `/partners/[partnerId]/users/[userId]/edit` |
| 運営ユーザー管理 | 運営ユーザーの一覧・招待・編集 | `/users`, `/users/[id]/edit` |
| 通知 | 全体・プロジェクト参加者向けの通知の一覧・詳細・作成・編集 | `/notifications`, `/notifications/[id]`, `/notifications/new`, `/notifications/[id]/edit` |
| 問い合わせ | 問い合わせの一覧・詳細と返答。会員詳細・創出PT詳細から運営者が起票でき、相手が返信すると一覧に入る | `/inquiries`, `/inquiries/[id]`, `/members/[memberId]/inquiries/new`, `/partners/[partnerId]/inquiries/new` |
| FAQ | FAQ の一覧・詳細 | `/faqs`, `/faqs/[id]` |
| メンテナンス管理 | 会員マイページ・創出PTマイページのメンテナンスの切り替え | `/maintenance` |
| マイアカウント | 自分のアカウントの確認・編集 | `/account`, `/account/edit` |
| 利用規約・プライバシーポリシー | 閲覧専用。全画面のフッターから開く | `/terms`, `/privacy` |

## 画面遷移(アカウント登録・認証)

```mermaid
flowchart TD
  invitationMail(["招待メールのリンク"]) --> signup["/signup アカウント作成"]
  signup --> twoFactor["/two-factor 二段階認証"]
  login["/login ログイン"] --> twoFactor
  twoFactor --> twoFactorComplete["/two-factor/complete 二段階認証完了"]
  twoFactorComplete --> top["/ TOP"]
  login --> passwordReset["/password-reset パスワード再設定申請"]
  passwordReset --> passwordResetConfirm["/password-reset/confirm パスワード再設定"]
  passwordResetConfirm --> passwordResetComplete["/password-reset/complete パスワード再設定完了"]
  passwordResetComplete --> login
```

## 画面遷移(各機能)

```mermaid
flowchart TD
  top["/ TOP"] --> members["/members 会員一覧"]
  members --> memberDetail["/members/[memberId] 会員詳細"]
  memberDetail --> memberEdit["/members/[memberId]/edit 会員編集"]
  memberEdit --> memberDetail
  memberDetail --> memberUserEdit["/members/[memberId]/users/[userId]/edit 会員ユーザー編集"]
  memberUserEdit --> memberDetail
  memberDetail --> memberApplications["/members/[memberId]/applications 会員の申込"]
  memberApplications --> memberApplicationEdit["/members/[memberId]/applications/[applicationId]/edit 会員の申込編集"]
  memberApplicationEdit --> memberDetail
  memberDetail --> memberInquiryNew["/members/[memberId]/inquiries/new 問い合わせ作成"]
  memberInquiryNew --> inquiries
  top --> projects["/projects プロジェクト一覧"]
  projects --> projectDetail["/projects/[id] プロジェクト詳細"]
  projectDetail --> projectEdit["/projects/[id]/edit プロジェクト編集"]
  projectEdit --> projectDetail
  top --> applications["/applications 申込一覧"]
  applications --> applicationDetail["/applications/[id] 申込詳細 承認/否認/差し戻し"]
  applicationDetail --> applications
  top --> requests["/requests 申請一覧"]
  requests --> requestDetail["/requests/[id] 申請詳細 承認/否認/差し戻し"]
  requestDetail --> requests
  top --> partners["/partners 創出PT一覧"]
  partners --> partnerNew["/partners/new 創出PT登録・参画プロジェクトの作成・創出PT管理者の招待"]
  partnerNew --> partnerNewComplete["/partners/new/complete 創出PT登録完了"]
  partnerNewComplete --> partnerDetail
  partners --> partnerDetail["/partners/[partnerId] 創出PT詳細"]
  partnerDetail --> partnerEdit["/partners/[partnerId]/edit 創出PT編集"]
  partnerEdit --> partnerDetail
  partnerDetail --> partnerInquiryNew["/partners/[partnerId]/inquiries/new 問い合わせ作成"]
  partnerInquiryNew --> inquiries
  partnerDetail --> partnerUsers["/partners/[partnerId]/users 創出PTユーザー一覧"]
  partnerUsers --> partnerUserEdit["/partners/[partnerId]/users/[userId]/edit 創出PTユーザー編集"]
  partnerUserEdit --> partnerUsers
  top --> users["/users 運営ユーザー一覧・招待"]
  users --> userEdit["/users/[id]/edit 運営ユーザー編集"]
  userEdit --> users
  top --> notifications["/notifications 通知一覧"]
  notifications --> notificationDetail["/notifications/[id] 通知詳細"]
  notificationDetail --> notifications
  notifications --> notificationNew["/notifications/new 通知作成"]
  notificationNew --> notifications
  notifications --> notificationEdit["/notifications/[id]/edit 通知編集"]
  notificationEdit --> notifications
  top --> inquiries["/inquiries 問い合わせ一覧"]
  inquiries --> inquiryDetail["/inquiries/[id] 問い合わせ詳細・返答"]
  inquiryDetail --> inquiries
  top --> faqs["/faqs FAQ 一覧"]
  faqs --> faqDetail["/faqs/[id] FAQ 詳細"]
  faqDetail --> faqs
  top --> maintenance["/maintenance メンテナンス管理"]
  maintenance --> top
  top --> account["/account マイアカウント管理"]
  account --> accountEdit["/account/edit マイアカウント編集"]
  accountEdit --> account
  top -->|ログアウト| login["/login ログイン"]
```
