# 基本設計 — 画面遷移・機能一覧(創出PTマイページ)

> 創出PTマイページ(`apps/partner-console`)の画面遷移・機能一覧・URL パス。会員マイページは [member-portal.md](member-portal.md)、運営者コンソールは [admin-console.md](admin-console.md)。
> 出典は要件定義「画面遷移図 Ver.0.3」で、画面名は用語集([domain.md](../domain.md))に読み替えている。
> 本書は **L1(画面同士の大まかな遷移)**。機能ごとの画面設計(表示条件・業務ルール・呼ぶ API)は `detailed/partner-console/<feature>/`(入口の `README.md` と 1 画面 1 ファイル)。
> 利用規約・プライバシーポリシー(全画面のフッターから)とメンテナンス(メンテナンス中は全画面から)は、図に描かず機能一覧にだけ載せる。
> ログアウトは画面を持たず、図ではログインへの遷移として描く。
> 未ログイン・権限なし・エラーのときの行き先(ログイン画面・404 画面・共通エラー画面)は 3 アプリ共通なので図に描かず、[error-handling.md](../error-handling.md) に書く。
>
> **現状**: 実装済みは `/` のみ。それ以外は未実装で、実装時は本書のパスでルートを作る。

創出PTユーザーが、自組織の紹介会員とプロジェクトの状況を確認し、会員情報・会員の申込を編集する。
見えるデータは自組織の分だけ。商工会議所の創出PTは、会員一覧・プロジェクト一覧を、会員が参加申請で選んだ支部で並べ替え・絞り込みして、支部ごとの会員とプロジェクトを見る。
ロールごとにできる操作は [auth.md](../auth.md)。
創出PT情報は直接書き換えず、運営者への申請(創出PT情報申請)として出す。

## 機能一覧

| 機能 | 概要 | 画面 |
| --- | --- | --- |
| 認証 | 創出PTユーザーのログイン・二段階認証・パスワード再設定 | `/login`, `/two-factor`, `/two-factor/complete`, `/password-reset`, `/password-reset/confirm`, `/password-reset/complete` |
| アカウント作成 | 招待された創出PTユーザーのアカウント作成。招待メールのリンクから開く | `/signup` |
| TOP | 各機能への入口 | `/`(実装済み) |
| プロジェクト | 自組織のプロジェクトの一覧・詳細。閲覧専用。一覧は支部で絞り込める(その支部を選んだ会員がいるプロジェクトと、その支部の会員の数を出す) | `/projects`, `/projects/[id]` |
| 会員管理 | 紹介会員(自創出PTのプロジェクトに紐づいた会員)の一覧・招待・詳細・編集。参加申請の承諾・否認は無い(会員が本会員になると自動で紐づき、通知が届く)。会員情報は運営者への申請を通さず直接編集できる(会員本人の修正は会員基本情報申請)。一覧は会員の支部を出し、支部で並べ替え・絞り込みできる | `/members`, `/members/[memberId]`, `/members/[memberId]/edit` |
| 会員の申込 | 紹介会員の、申込中から参加中までの申込の一覧と編集(代理入力) | `/members/[memberId]/applications`, `/members/[memberId]/applications/[applicationId]/edit` |
| 創出PTユーザー管理 | 創出PTユーザーの一覧・招待・編集 | `/users`, `/users/[id]/edit` |
| 創出PT情報 | 創出PT情報の確認と、変更の申請(創出PT情報申請) | `/partner-info`, `/partner-info/edit` |
| 通知 | 通知と問い合わせの一覧・詳細。運営者が起票した問い合わせと、運営者が回答した自分の問い合わせが届き、その画面から返信できる | `/notifications`, `/notifications/[id]` |
| FAQ・問い合わせ | FAQ の一覧・詳細の閲覧と、運営者への問い合わせ | `/faqs`, `/faqs/[id]`, `/inquiries/new`, `/inquiries/new/complete` |
| マイアカウント | 自分のアカウントの確認・編集 | `/account`, `/account/edit` |
| ユーザー削除 | 自分のユーザーの削除。FAQ「ユーザー削除について」の詳細から入り、完了後はログインに戻る | `/account/delete`, `/account/delete/complete` |
| 利用規約・プライバシーポリシー | 閲覧専用。全画面のフッターから開く | `/terms`, `/privacy` |
| メンテナンス | メンテナンス中は全画面からこの画面に切り替わる | `/maintenance` |

## 画面遷移(アカウント登録・認証)

```mermaid
flowchart TD
  invitationMail(["招待メールのリンク"]) --> signup["/signup アカウント作成"]
  signup --> twoFactor["/two-factor 二段階認証"]
  login["/login ログイン"] --> twoFactor
  twoFactor --> twoFactorComplete["/two-factor/complete 二段階認証完了"]
  twoFactorComplete --> top["/ TOP"]
  login --> passwordReset["/password-reset パスワード再設定申請"]
  passwordReset --> passwordResetConfirm["/password-reset/confirm パスワード再設定"]
  passwordResetConfirm --> passwordResetComplete["/password-reset/complete パスワード再設定完了"]
  passwordResetComplete --> login
```

## 画面遷移(各機能)

```mermaid
flowchart TD
  top["/ TOP"] --> projects["/projects プロジェクト一覧"]
  projects --> projectDetail["/projects/[id] プロジェクト詳細"]
  projectDetail --> projects
  top --> members["/members 会員一覧・招待"]
  members --> memberDetail["/members/[memberId] 会員詳細"]
  memberDetail --> memberEdit["/members/[memberId]/edit 会員編集"]
  memberEdit --> members
  memberDetail --> memberApplications["/members/[memberId]/applications 会員の申込"]
  memberApplications --> memberApplicationEdit["/members/[memberId]/applications/[applicationId]/edit 会員の申込編集"]
  memberApplicationEdit --> members
  top --> users["/users 創出PTユーザー一覧・招待"]
  users --> userEdit["/users/[id]/edit 創出PTユーザー編集"]
  userEdit --> users
  top --> partnerInfo["/partner-info 創出PT情報"]
  partnerInfo --> partnerInfoEdit["/partner-info/edit 創出PT情報変更の申請"]
  partnerInfoEdit --> partnerInfo
  top --> notifications["/notifications 通知一覧"]
  notifications --> notificationDetail["/notifications/[id] 通知詳細・返信"]
  notificationDetail --> notifications
  top --> faqs["/faqs FAQ"]
  faqs --> faqDetail["/faqs/[id] FAQ 詳細"]
  faqDetail --> faqs
  faqDetail --> inquiryNew["/inquiries/new 問い合わせ"]
  inquiryNew --> inquiryComplete["/inquiries/new/complete 問い合わせ完了"]
  inquiryComplete --> faqs
  faqDetail -->|ユーザー削除について| accountDelete["/account/delete ユーザー削除"]
  accountDelete --> accountDeleteComplete["/account/delete/complete ユーザー削除完了"]
  accountDeleteComplete --> login["/login ログイン"]
  top --> account["/account マイアカウント管理"]
  account --> accountEdit["/account/edit マイアカウント編集"]
  accountEdit --> account
  top -->|ログアウト| login
```
