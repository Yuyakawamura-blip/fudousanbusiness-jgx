# ブランチと環境の運用

| ブランチ | 環境 | 役割 | 入り方 |
| --- | --- | --- | --- |
| `main` | prd(本番) | リリース済みの断面 | `staging` からの promotion PR のみ |
| `staging` | stg(ステージング) | 受け入れ確認 | `develop` からの promotion PR のみ |
| `develop` | dev(開発) | 日常の統合先。**通常の PR はここへ** | feature ブランチからの PR |

- 作業ブランチは **`develop` から切る**: `git switch -c feat/<topic> develop`(`fix/` / `chore/` / `docs/` も同様)。
  作業ブランチの上にさらに作業ブランチを積むときは下の「Stacked PR」
- **保護ブランチ(`main` / `staging` / `develop`)へ直接 push しない**。GitHub のブランチ保護(ruleset)で PR 必須・CI 必須にする
- promotion(develop → staging → main)は「ブランチ間の PR」で行う。cherry-pick で環境を跨がない
- hotfix は `staging` または `main` から切って PR を出し、マージ後に **下流(`develop`)へも必ず戻す**(main → staging → develop の順に promotion PR、または同じ修正の PR を `develop` へ)
- `APP_ENV`(`local` / `dev` / `stg` / `prd`)は環境名で、ブランチ名とは別(`develop` → dev / `staging` → stg / `main` → prd)。デプロイは Actions の `Deploy <app>` を手動実行し、選んだブランチの環境へ出す(commit_id で過去コミットも可。ADR-0007)。デプロイ基盤の選定は未決で、今は何もデプロイしない(ADR-0001 の Open questions)

## 運用設計(`operations`)

運用設計書・業務マニュアル(`docs/operations/`)は、開発とは別の担当が長く生きる `operations` ブランチ 1 本で書く。
開発の範囲を変えないことはブランチではなくパスで守る(下の「ガード」の Operations Scope)。

- `operations` は develop から 1 度だけ切る。保護ブランチにはせず、担当が直接コミット・push する
- **着手のたびに最新の develop を merge する**(手順は `/start-operations`)。force push はしない
- 変えてよいのは `docs/operations/` の中だけ。開発の設計書との食い違いは直さず Issue(`area: operations`)で開発へ渡す
- 章の初稿・レビュー依頼などの区切りで `operations` → `develop` の PR を出す。開発チームはここで整合を見る
- この PR は **merge コミットでマージ**する(squash だと次の PR で同じ差分が再び出て、`operations` で衝突しやすい)
- ruleset で `operations` の**削除と強制 push を禁止**する(head ブランチの自動削除が有効なのでマージで消えるのを防ぐ。強制 push で develop から取り込んだ分や履歴を消さない)
- develop の ruleset の必須チェックに `operations-scope` を入れる(入れないと範囲外の変更があってもマージできる)

## Stacked PR(作業ブランチを base にする PR)

1 本の変更が大きくなるとき(例: DB migration → API → 画面)、レビュー単位を分けるために作業ブランチの上に作業ブランチを積む。
命名・本文・ラベルの約束と、ガードの緩和で運用する。GitHub のスタック表示(stacked pull requests)には `gh stack link` だけを使い、
ローカルでスタックを管理するコマンド(`gh stack init` / `sync` / `rebase` / `push` 等)は使わない(載せ替えで強制 push になるため)。

- **命名**: 最初のブランチは通常どおり `feat/<topic>`、その上は `feat/<topic>-2`、`feat/<topic>-3`(末尾に説明を足してよい: `feat/<topic>-2-api`)。
  `feat/<topic>/2` のような入れ子は git の ref 制約で作れない(`feat/<topic>` が既にあるため)
- **作る**: `git switch -c feat/<topic>-2 feat/<topic>` → `gh pr create --base feat/<topic> ...`。
  base に open な PR が無いとフック / CI が弾くので、**下から順に PR を作る**。`stacked` ラベルは CI が付ける(手で付けない)
- **スタックにつなぐ**: PR を作ったら `gh stack link <下の PR 番号> <この PR 番号>` で GitHub のスタックに入れる。
  下の PR が既にスタックにあれば、そのスタックの上に足される。branch は push 済みなので、link は push も PR 作成もしない。
  拡張は `gh extension install github/gh-stack` で入れる
- **本文**: `## Summary` の 1 行目に `Stack: #10 → **#11** → #12`(太字 = この PR、左からマージ順)。上の PR ができたら下の PR の行も更新する
- **スクリーンショット**: 変更前は親ブランチ断面と比べる: `node scripts/screenshots/cli.mjs plan --base feat/<topic>`
- **レビューで下を直したら上を順に載せ替える**。`--force-with-lease` の push は **人が行う**(Claude Code は強制 push を deny しており、
  `--force-with-lease` も前方一致で同じ扱いになる。保護ブランチは ruleset が弾く):
  ```bash
  git rebase feat/<topic> feat/<topic>-2 && git push --force-with-lease
  git rebase feat/<topic>-2 feat/<topic>-3 && git push --force-with-lease
  ```
- **マージは下から順**。`stacked` が付いている PR はマージしない(base がまだ open)
- **下の PR がマージされたら**: head ブランチが削除されると GitHub が上の PR の base を自動で `develop` に付け替える
  (リポジトリ設定 "Automatically delete head branches" が前提)。squash では下の PR のコミットが develop に残らないので、
  付け替え後に必ず載せ替える(**ローカルの `feat/<topic>` を消す前に**実行):
  ```bash
  git fetch origin
  git rebase --onto origin/develop feat/<topic> feat/<topic>-2
  git push --force-with-lease
  git branch -D feat/<topic>
  ```
  ローカルの `feat/<topic>` を先に消してしまったら `gh pr view <PR-1> --json headRefOid --jq .headRefOid` で旧 tip の SHA を取り、
  `feat/<topic>` の代わりに渡す
- head ブランチが削除されず base の付け替えが起きないと、上の PR はマージ済みの作業ブランチに入ってしまう。
  マージ前に base が `develop` になっているか(= `stacked` が外れているか)必ず見る

## ガード

| 場所 | 内容 |
| --- | --- |
| `.claude/hooks/pr-guard.sh` | Claude Code から PR を作るとき、base が develop / promotion の組合せ / open な PR を持つ作業ブランチ(stacked)のいずれでもなければブロック。stacked の確認に gh が使えないとき(フックの gh には Bash ツールの `GH_TOKEN` が渡らない)は警告だけ出して通し、CI に任せる |
| `.github/workflows/pr-base-branch.yml` | 同じ検査を GitHub 側で実施(人手の PR も対象)。stacked なら `stacked` ラベルを付け、develop に付け替わったら外す |
| `.github/workflows/operations-scope.yml` | `operations` への push と head が `operations` の PR で、develop との merge-base からの差分に `docs/operations/` の外があれば失敗 |
| `.claude/hooks/operations-scope.sh` / `inject-context.sh` | `operations` で `docs/operations/` の外を編集しようとしたら警告(止めない)。`operations` が origin/develop より遅れていたらセッション開始時に警告 |
| `.github/workflows/labels-sync.yml` | `.github/labels.yml` を GitHub のラベルへ同期(develop への push で反映、PR は dry-run) |
| GitHub ruleset / 設定 | `main` / `staging` / `develop` への直 push 禁止・PR 必須・CI 必須(`operations-scope` を含む)。`operations` の削除・強制 push 禁止。head ブランチの自動削除(stacked PR の base 付け替えに必要) |
